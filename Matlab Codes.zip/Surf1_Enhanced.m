function [Grid2, plt1, plt2] = Surf1_Enhanced(Grid, numberoffeatures, sigma2)
    % Enhanced Surf1 function with individual dataset color scaling
    
    plt1 = ceil(numberoffeatures^0.5);
    plt2 = plt1;   
    global XI
    global YI
    global YI_Real_Ratio
    global xv
    global yv
    global OriginalDataRanges

    % Grid_ = Grid(:);
    % Grid_Min = min(Grid_)
    % Grid_Max = max(Grid_)

    if exist('xv', 'var') && exist('yv', 'var')
        in = inpolygon(XI,YI,xv,yv);
    else
        in = true(size(XI));
    end

    for tttt6 = 1:numberoffeatures
        Grid0 = Grid(:,:,tttt6);
        Grid2(:,:,tttt6) = FilterB(Grid0, sigma2);
        
        % Get original data range for this specific dataset
        originalRange = [0, 1]; % Will be overwritten below
        
        if exist('OriginalDataRanges', 'var')
            % Use the same sequential indexing as nDstrb2D
            field_name = sprintf('dataset_%d', tttt6);
            if isfield(OriginalDataRanges, field_name)
                originalRange = OriginalDataRanges.(field_name);
            end
        end
        
        % If no stored range found, use the actual data's range
        if originalRange(1) == 0 && originalRange(2) == 1
            validData = Grid2(:,:,tttt6);
            validData = validData(~isnan(validData));
            if ~isempty(validData)
                originalRange = [min(validData), max(validData)];
            end
        end
        
        % CRITICAL: Scale data back to original range for display
        original_min = originalRange(1);
        original_max = originalRange(2);
        original_range = original_max - original_min;
        
        % Scale normalized data back to original range
        Grid2_scaled = Grid2(:,:,tttt6);
        valid_mask = ~isnan(Grid2_scaled);
        Grid2_scaled(valid_mask) = Grid2_scaled(valid_mask) * original_range + original_min;
        
        subplot(plt1, plt2, tttt6);
        surf(XI, YI, Grid2_scaled);
        
        title(['# ', num2str(tttt6), '']);
        box on
        set(gca, 'TickDir', 'out', 'linewidth', 1, 'Layer', 'top');
        colormap jet;
        axis equal
        shading interp
        view(0, 90)
        grid off
        daspect([YI_Real_Ratio 1 1]);
        
        % CRITICAL: Set color axis to original data range for this dataset
        caxis([originalRange(1), originalRange(2)]);
        
        % Add colorbar with original range
        h = colorbar;
        h.Label.String = 'Original Data Range';
        h.Label.FontSize = 10;
        h.Label.FontWeight = 'bold';
        
        % % Add text showing the range
        % text(0.02, 0.98, ['Range: [', num2str(originalRange(1), '%.3f'), ', ', num2str(originalRange(2), '%.3f'), ']'], ...
        %      'Units', 'normalized', 'FontSize', 8, 'FontWeight', 'bold', ...
        %      'BackgroundColor', 'white', 'EdgeColor', 'black');
    end 
end