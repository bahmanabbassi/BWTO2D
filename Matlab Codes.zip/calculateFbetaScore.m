function [fbeta_score, precision, recall, tp, fp, fn] = calculateFbetaScore(real_faults, detected_faults, XI, YI, beta, tolerance_arcsec, use_bidirectional, use_length_weighted, verbose)
%calculateFbetaScore - Improved F-beta score calculation using distance transform
%
% This function implements an improved F-beta score calculation that:
% 1. Uses distance transform for accurate proximity matching
% 2. Handles high-resolution data efficiently
% 3. Provides more meaningful scores than simple dilation
%
% Inputs:
%   real_faults (2D binary matrix): Ground truth lineaments
%   detected_faults (2D binary matrix): Detected lineaments
%   XI, YI (2D matrices): Coordinate grids in arc-seconds
%   beta (double): F-beta parameter (typically 0.2 for geological features)
%   tolerance_arcsec (double): Tolerance distance in arc-seconds (default: 15 arc-sec)
%   use_bidirectional (logical): If true, use bidirectional matching (default: true)
%   use_length_weighted (logical): If true, weight by lineament length (default: false)
%   verbose (logical, optional): If true, display metrics to console (default: true)
%
% Outputs:
%   fbeta_score (double): F-beta score
%   precision (double): Precision metric
%   recall (double): Recall metric
%   tp (double): True positives
%   fp (double): False positives
%   fn (double): False negatives

% Set defaults
if nargin < 9
    verbose = true;
end



% Ensure inputs are binary
real_faults = logical(real_faults);
detected_faults = logical(detected_faults);

%% Calculate Grid Spacing and Tolerance in Pixels
% Calculate actual pixel spacing (not total extent)
[grid_rows, grid_cols] = size(XI);
if grid_cols > 1
    dx = abs(XI(1,2) - XI(1,1));  % Distance between adjacent columns
else
    dx = abs(max(XI(:)) - min(XI(:))) / max(grid_cols - 1, 1);
end
if grid_rows > 1
    dy = abs(YI(2,1) - YI(1,1));  % Distance between adjacent rows
else
    dy = abs(max(YI(:)) - min(YI(:))) / max(grid_rows - 1, 1);
end
pixel_size_arcsec = mean([dx, dy]);

% if pixel_size_arcsec < 0.001 || isnan(pixel_size_arcsec) || isinf(pixel_size_arcsec)
%     pixel_size_arcsec = 5
%     warning('Could not determine pixel size. Using default: %.1f arc-sec/pixel', pixel_size_arcsec);
% end

% Convert tolerance from arc-seconds to pixels
tolerance_pixels = tolerance_arcsec / pixel_size_arcsec;

% Get image dimensions
[img_rows, img_cols] = size(real_faults);
total_pixels = img_rows * img_cols;

% Use tolerance_arcsec directly - no capping
% Distance transform is memory-efficient regardless of tolerance value
% The tolerance only affects thresholding, not memory usage
% Warn if tolerance is very large relative to image (may give unrealistic scores)
tolerance_pixels = round(tolerance_pixels);
tolerance_percent = tolerance_pixels / min(img_rows, img_cols) * 100;

if tolerance_percent > 50
    warning('Tolerance (%.1f pixels, %.1f%% of image) is very large. This may result in unrealistic perfect scores.', ...
        tolerance_pixels, tolerance_percent);
end

% Ensure minimum tolerance of 1 pixel
tolerance_pixels = max(1, tolerance_pixels);

if verbose
    fprintf('\n=== F-beta Calculation Parameters ===\n');
    fprintf('  Coordinate system: Arc-seconds\n');
    fprintf('  Grid spacing: %.6f arc-sec/pixel\n', pixel_size_arcsec);
    fprintf('  Tolerance: %.1f arc-sec = %.1f pixels\n', tolerance_arcsec, tolerance_pixels);
    fprintf('  Image size: %d x %d pixels\n', img_rows, img_cols);
    fprintf('  Method: Distance transform-based matching\n');
    fprintf('========================================\n\n');
end

%% Method: Improved Distance Transform-Based Matching
% Uses distance transforms for accurate proximity matching
% Implements a more sophisticated matching strategy to avoid unrealistic perfect scores

% Calculate distance transform from ground truth lineaments
dist_to_truth = bwdist(real_faults);

% Calculate distance transform from detected lineaments  
dist_to_detected = bwdist(detected_faults);

% Count pixels
gt_pixels = sum(real_faults(:));
det_pixels = sum(detected_faults(:));

% Improved matching strategy using distance transforms
% This is more accurate and efficient than dilation-based methods

if use_bidirectional
    % Bidirectional matching:
    % - TP: Detected pixels within tolerance of ground truth
    % - FN: Ground truth pixels NOT within tolerance of detected
    
    % True Positives: Detected pixels within tolerance of ground truth
    tp_mask = detected_faults & (dist_to_truth <= tolerance_pixels);
    tp = sum(tp_mask(:));
    
    % False Positives: Detected pixels NOT within tolerance of ground truth
    fp_mask = detected_faults & (dist_to_truth > tolerance_pixels);
    fp = sum(fp_mask(:));
    
    % False Negatives: Ground truth pixels NOT within tolerance of detected
    fn_mask = real_faults & (dist_to_detected > tolerance_pixels);
    fn = sum(fn_mask(:));
    
else
    % Unidirectional matching: Only check detected pixels against ground truth
    tp_mask = detected_faults & (dist_to_truth <= tolerance_pixels);
    tp = sum(tp_mask(:));
    
    fp_mask = detected_faults & (dist_to_truth > tolerance_pixels);
    fp = sum(fp_mask(:));
    
    % False Negatives: Ground truth pixels NOT within tolerance of detected
    fn_mask = real_faults & (dist_to_detected > tolerance_pixels);
    fn = sum(fn_mask(:));
end

% Check if tolerance is too large relative to image size
tolerance_percent = tolerance_pixels / min(img_rows, img_cols) * 100;
if tolerance_percent > 10 && verbose
    warning('Tolerance (%.1f%% of smallest dimension) is large. Consider reducing tolerance_arcsec for more sensitive scoring.', tolerance_percent);
end

%% Optional: Length-Weighted Scoring
if use_length_weighted
    % Get connected components
    CC_truth = bwconncomp(real_faults);
    CC_detected = bwconncomp(detected_faults);
    
    % Calculate lengths (perimeter or major axis length)
    stats_truth = regionprops(CC_truth, 'Perimeter', 'MajorAxisLength');
    stats_detected = regionprops(CC_detected, 'Perimeter', 'MajorAxisLength');
    
    % Use major axis length as weight (more stable than perimeter)
    weight_map_truth = zeros(size(real_faults));
    weight_map_detected = zeros(size(detected_faults));
    
    for i = 1:CC_truth.NumObjects
        if ~isempty(stats_truth(i).MajorAxisLength)
            weight_map_truth(CC_truth.PixelIdxList{i}) = stats_truth(i).MajorAxisLength;
        end
    end
    
    for i = 1:CC_detected.NumObjects
        if ~isempty(stats_detected(i).MajorAxisLength)
            weight_map_detected(CC_detected.PixelIdxList{i}) = stats_detected(i).MajorAxisLength;
        end
    end
    
    % Normalize weights
    if max(weight_map_truth(:)) > 0
        weight_map_truth = weight_map_truth / max(weight_map_truth(:));
    end
    if max(weight_map_detected(:)) > 0
        weight_map_detected = weight_map_detected / max(weight_map_detected(:));
    end
    
    % Apply weights
    tp = sum(weight_map_detected(tp_mask));
    fp = sum(weight_map_detected(fp_mask));
    fn = sum(weight_map_truth(fn_mask));
end

%% Calculate Precision, Recall, and F-beta Score
if (tp + fp) == 0
    precision = 0;
    if verbose
        warning('No detected lineaments - precision is undefined, set to 0');
    end
else
    precision = tp / (tp + fp);
end

if (tp + fn) == 0
    recall = 0;
    if verbose
        warning('No ground truth lineaments - recall is undefined, set to 0');
    end
else
    recall = tp / (tp + fn);
end

% F-beta Score
if (precision == 0 && recall == 0)
    fbeta_score = 0;
else
    fbeta_score = (1 + beta^2) * ((precision * recall) / ((beta^2 * precision) + recall));
end

%% Display Results (only if verbose is true)
if verbose
    fprintf('=== F-beta Score Results ===\n');
    fprintf('  Ground truth pixels: %.0f (%.2f%% of image)\n', gt_pixels, gt_pixels/total_pixels*100);
    fprintf('  Detected pixels: %.0f (%.2f%% of image)\n', det_pixels, det_pixels/total_pixels*100);
    fprintf('  Tolerance: %.1f arc-sec = %.1f pixels (%.1f%% of smallest dimension)\n', ...
        tolerance_arcsec, tolerance_pixels, tolerance_pixels/min(img_rows, img_cols)*100);
    fprintf('  True Positives: %.0f\n', tp);
    fprintf('  False Positives: %.0f\n', fp);
    fprintf('  False Negatives: %.0f\n', fn);
    fprintf('  Precision: %.4f\n', precision);
    fprintf('  Recall: %.4f\n', recall);
    fprintf('  F-beta Score (beta=%.2f): %.4f\n', beta, fbeta_score);

    % Diagnostic warnings
    if precision == 1.0 && recall == 1.0 && (gt_pixels > 0 && det_pixels > 0)
        fprintf('  *** WARNING: Perfect score detected ***\n');
        fprintf('     This may indicate:\n');
        fprintf('     - Tolerance (%.1f%%) is too large for image size\n', tolerance_percent);
        fprintf('     - Try reducing tolerance_arcsec to get more realistic scores\n');
    elseif tolerance_percent > 10
        fprintf('  *** NOTE: Large tolerance (%.1f%%) - consider reducing for more sensitive scoring\n', tolerance_percent);
    end
    fprintf('=============================\n\n');
end

end
