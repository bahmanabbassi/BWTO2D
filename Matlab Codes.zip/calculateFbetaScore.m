function [fbeta_score, precision, recall, tp, fp, fn] = calculateFbetaScore(real_faults, detected_faults, XI, YI, beta, tolerance_arcsec, use_bidirectional, use_length_weighted, verbose)
%calculateFbetaScore - Spatially tolerant F-beta score, Eq. (22) of Section 1.4.
%
% A detected pixel is counted as correct when it lies within a tolerance tau of
% the reference network, and vice versa. Exact pixel agreement would be the
% wrong test here, since an extracted trace marks a magnetic discontinuity that
% need not fall exactly where a geologist drew the corresponding structure.
%
% Proximity is measured with a distance transform rather than by dilating the
% masks. The two are equivalent in effect, but the distance transform is
% computed once per network and its cost does not grow with the tolerance,
% which matters when the score is evaluated at every Bayesian iteration.
%
% Inputs:
%   real_faults (2D binary matrix): Reference network.
%   detected_faults (2D binary matrix): Extracted network.
%   XI, YI (2D matrices): Coordinate grids in arc-seconds.
%   beta (double) [beta]: Relative weight of recall against precision. The
%                 paper uses 0.2, well below 1, which makes the score reward
%                 traces that are correctly placed rather than traces that
%                 cover the whole reference network.
%   tolerance_arcsec (double) [tau]: Matching tolerance in arc-seconds. The
%                 paper uses 0.0176 degrees, about 63 arc-seconds.
%   use_bidirectional (logical): Evaluate misses as well as false alarms.
%                 The pipeline passes true.
%   use_length_weighted (logical): Weight each pixel by the length of the trace
%                 it belongs to, so long structures count for more. The
%                 pipeline passes false, giving every pixel equal weight.
%   verbose (logical, optional): Print to the console. Default true; the BTO
%                 loop passes false.
%
% Outputs:
%   fbeta_score (double): F-beta of Eq. (22)
%   precision (double): tp / (tp + fp)
%   recall (double): tp / (tp + fn)
%   tp, fp, fn (double): Matched, unmatched detected, and missed reference
%                 pixels, or their weighted equivalents

% Set defaults
if nargin < 9
    verbose = true;
end



% Ensure inputs are binary
real_faults = logical(real_faults);
detected_faults = logical(detected_faults);

%% Calculate Grid Spacing and Tolerance in Pixels
% Calculate actual pixel spacing (not total extent)
[grid_rows, grid_cols] = size(XI);
if grid_cols > 1
    dx = abs(XI(1,2) - XI(1,1));  % Distance between adjacent columns
else
    dx = abs(max(XI(:)) - min(XI(:))) / max(grid_cols - 1, 1);
end
if grid_rows > 1
    dy = abs(YI(2,1) - YI(1,1));  % Distance between adjacent rows
else
    dy = abs(max(YI(:)) - min(YI(:))) / max(grid_rows - 1, 1);
end
pixel_size_arcsec = mean([dx, dy]);

% if pixel_size_arcsec < 0.001 || isnan(pixel_size_arcsec) || isinf(pixel_size_arcsec)
%     pixel_size_arcsec = 5
%     warning('Could not determine pixel size. Using default: %.1f arc-sec/pixel', pixel_size_arcsec);
% end

% The tolerance is specified in arc-seconds so that it means the same distance
% on the ground regardless of the grid resolution, then converted to pixels.
tolerance_pixels = tolerance_arcsec / pixel_size_arcsec;

% Get image dimensions
[img_rows, img_cols] = size(real_faults);
total_pixels = img_rows * img_cols;

% The tolerance is not capped: it only sets a threshold on an already computed
% distance map, so a large value costs nothing extra. It can, however, make the
% score meaningless, since a tolerance approaching the image size lets any
% detection match anything. The warning below flags that case.
tolerance_pixels = round(tolerance_pixels);
tolerance_percent = tolerance_pixels / min(img_rows, img_cols) * 100;

if tolerance_percent > 50
    warning('Tolerance (%.1f pixels, %.1f%% of image) is very large. This may result in unrealistic perfect scores.', ...
        tolerance_pixels, tolerance_percent);
end

tolerance_pixels = max(1, tolerance_pixels); % At least one pixel

if verbose
    fprintf('\n=== F-beta Calculation Parameters ===\n');
    fprintf('  Coordinate system: Arc-seconds\n');
    fprintf('  Grid spacing: %.6f arc-sec/pixel\n', pixel_size_arcsec);
    fprintf('  Tolerance: %.1f arc-sec = %.1f pixels\n', tolerance_arcsec, tolerance_pixels);
    fprintf('  Image size: %d x %d pixels\n', img_rows, img_cols);
    fprintf('  Method: Distance transform-based matching\n');
    fprintf('========================================\n\n');
end

%% Proximity matching by distance transform
% Each map gives, at every pixel, the distance to the nearest pixel of that
% network. Thresholding these at tolerance_pixels is what implements the
% tolerant match.
dist_to_truth = bwdist(real_faults);
dist_to_detected = bwdist(detected_faults);

gt_pixels = sum(real_faults(:));
det_pixels = sum(detected_faults(:));

if use_bidirectional
    % Both error types are counted: detections with no reference nearby, and
    % reference traces with no detection nearby.
    
    tp_mask = detected_faults & (dist_to_truth <= tolerance_pixels);
    tp = sum(tp_mask(:));
    
    fp_mask = detected_faults & (dist_to_truth > tolerance_pixels);
    fp = sum(fp_mask(:));
    
    fn_mask = real_faults & (dist_to_detected > tolerance_pixels);
    fn = sum(fn_mask(:));
    
else
    tp_mask = detected_faults & (dist_to_truth <= tolerance_pixels);
    tp = sum(tp_mask(:));
    
    fp_mask = detected_faults & (dist_to_truth > tolerance_pixels);
    fp = sum(fp_mask(:));
    
    % False Negatives: Ground truth pixels NOT within tolerance of detected
    fn_mask = real_faults & (dist_to_detected > tolerance_pixels);
    fn = sum(fn_mask(:));
end

% Check if tolerance is too large relative to image size
tolerance_percent = tolerance_pixels / min(img_rows, img_cols) * 100;
if tolerance_percent > 10 && verbose
    warning('Tolerance (%.1f%% of smallest dimension) is large. Consider reducing tolerance_arcsec for more sensitive scoring.', tolerance_percent);
end

%% Optional length weighting
% When enabled, every pixel counts in proportion to the length of the trace it
% belongs to, so that a long structure outweighs a short fragment. Disabled in
% the published runs, which count all pixels equally.
if use_length_weighted
    CC_truth = bwconncomp(real_faults);
    CC_detected = bwconncomp(detected_faults);
    
    stats_truth = regionprops(CC_truth, 'Perimeter', 'MajorAxisLength');
    stats_detected = regionprops(CC_detected, 'Perimeter', 'MajorAxisLength');
    
    % Major axis length is used rather than perimeter, which on a thin trace
    % counts each side and is sensitive to small kinks.
    weight_map_truth = zeros(size(real_faults));
    weight_map_detected = zeros(size(detected_faults));
    
    for i = 1:CC_truth.NumObjects
        if ~isempty(stats_truth(i).MajorAxisLength)
            weight_map_truth(CC_truth.PixelIdxList{i}) = stats_truth(i).MajorAxisLength;
        end
    end
    
    for i = 1:CC_detected.NumObjects
        if ~isempty(stats_detected(i).MajorAxisLength)
            weight_map_detected(CC_detected.PixelIdxList{i}) = stats_detected(i).MajorAxisLength;
        end
    end
    
    % Normalize weights
    if max(weight_map_truth(:)) > 0
        weight_map_truth = weight_map_truth / max(weight_map_truth(:));
    end
    if max(weight_map_detected(:)) > 0
        weight_map_detected = weight_map_detected / max(weight_map_detected(:));
    end
    
    % Apply weights
    tp = sum(weight_map_detected(tp_mask));
    fp = sum(weight_map_detected(fp_mask));
    fn = sum(weight_map_truth(fn_mask));
end

%% Calculate Precision, Recall, and F-beta Score
if (tp + fp) == 0
    precision = 0;
    if verbose
        warning('No detected lineaments - precision is undefined, set to 0');
    end
else
    precision = tp / (tp + fp);
end

if (tp + fn) == 0
    recall = 0;
    if verbose
        warning('No ground truth lineaments - recall is undefined, set to 0');
    end
else
    recall = tp / (tp + fn);
end

% F_beta = (1 + beta^2) * P * R / (beta^2 * P + R), Eq. (22). With beta below 1
% the harmonic mean leans towards precision.
if (precision == 0 && recall == 0)
    fbeta_score = 0;
else
    fbeta_score = (1 + beta^2) * ((precision * recall) / ((beta^2 * precision) + recall));
end

%% Display Results (only if verbose is true)
if verbose
    fprintf('=== F-beta Score Results ===\n');
    fprintf('  Ground truth pixels: %.0f (%.2f%% of image)\n', gt_pixels, gt_pixels/total_pixels*100);
    fprintf('  Detected pixels: %.0f (%.2f%% of image)\n', det_pixels, det_pixels/total_pixels*100);
    fprintf('  Tolerance: %.1f arc-sec = %.1f pixels (%.1f%% of smallest dimension)\n', ...
        tolerance_arcsec, tolerance_pixels, tolerance_pixels/min(img_rows, img_cols)*100);
    fprintf('  True Positives: %.0f\n', tp);
    fprintf('  False Positives: %.0f\n', fp);
    fprintf('  False Negatives: %.0f\n', fn);
    fprintf('  Precision: %.4f\n', precision);
    fprintf('  Recall: %.4f\n', recall);
    fprintf('  F-beta Score (beta=%.2f): %.4f\n', beta, fbeta_score);

    % Diagnostic warnings
    if precision == 1.0 && recall == 1.0 && (gt_pixels > 0 && det_pixels > 0)
        fprintf('  *** WARNING: Perfect score detected ***\n');
        fprintf('     This may indicate:\n');
        fprintf('     - Tolerance (%.1f%%) is too large for image size\n', tolerance_percent);
        fprintf('     - Try reducing tolerance_arcsec to get more realistic scores\n');
    elseif tolerance_percent > 10
        fprintf('  *** NOTE: Large tolerance (%.1f%%) - consider reducing for more sensitive scoring\n', tolerance_percent);
    end
    fprintf('=============================\n\n');
end

end
