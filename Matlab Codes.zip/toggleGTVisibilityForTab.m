function toggleGTVisibilityForTab(checkbox_handle, iter_idx)
%toggleGTVisibilityForTab - Toggle ground truth lineament visibility for a specific tab
%
% This function finds all ground truth lines in the specified axes and
% toggles their visibility based on the checkbox state.
%
% Inputs:
%   checkbox_handle (uicontrol handle): The checkbox control (contains axes in UserData)
%   iter_idx (integer): The iteration index (for tag matching)

    % Get axes from checkbox UserData
    ax = get(checkbox_handle, 'UserData');
    if isempty(ax) || ~ishandle(ax)
        % Fallback: find axes in the checkbox's parent (tab)
        parent = get(checkbox_handle, 'Parent');
        ax = findobj(parent, 'Type', 'axes');
        if isempty(ax)
            return;  % Can't find axes, exit
        end
        ax = ax(1);  % Take first axes if multiple found
    end
    
    % Get checkbox value
    show_gt = get(checkbox_handle, 'Value');
    
    % Find all ground truth lines in this axes (by tag pattern)
    all_children = get(ax, 'Children');
    gt_lines = [];
    for i = 1:length(all_children)
        if isprop(all_children(i), 'Tag')
            tag = get(all_children(i), 'Tag');
            if ~isempty(tag) && contains(tag, ['GT_Line_', num2str(iter_idx)])
                gt_lines = [gt_lines; all_children(i)];
            end
        end
    end
    
    % Toggle visibility
    if ~isempty(gt_lines)
        if show_gt
            set(gt_lines, 'Visible', 'on');
        else
            set(gt_lines, 'Visible', 'off');
        end
    end
end

