function [orientations360, numOrientations] = createRoseDiagramsFromVectors(FaultLineaments)
    % Extract orientations directly from vector lineament data
    % Input: FaultLineaments - struct array containing vector fault data
    % Output: orientations360 - orientations in 0-360 degree range
    %         numOrientations - number of orientation segments
    
    orientations = [];
    numSegments = 0;
    
    % Process each fault lineament
    for i = 1:length(FaultLineaments)
        fault = FaultLineaments(i);
        
        % Get X and Y coordinates
        x = fault.X;
        y = fault.Y;
        
        % Remove any NaN values
        validIdx = ~isnan(x) & ~isnan(y);
        x = x(validIdx);
        y = y(validIdx);
        
        if length(x) < 2
            continue; % Skip single points
        end
        
        % Calculate orientations for each line segment
        for j = 1:length(x)-1
            % Calculate the orientation of the line segment
            dx = x(j+1) - x(j);
            dy = y(j+1) - y(j);
            
            % Skip very short segments (less than 1 meter)
            segmentLength = sqrt(dx^2 + dy^2);
            if segmentLength < 1e-6  % 1 micrometer threshold
                continue;
            end
            
            % Calculate angle using slope-based approach (matches raster createRoseDiagrams)
            % This is equivalent to: angle = atan(dy/dx) but handles vertical lines
            if abs(dx) < 1e-12  % Nearly vertical line
                angle = 90;  % Vertical = 90 degrees
            else
                slope = dy / dx;
                angle = atan(slope) * (180 / pi);  % Returns (-90, 90]
            end
            
            % Convert to 0-180 range (since fault orientation is bidirectional)
            % atan returns (-90, 90], so adding 180 to negatives gives [0, 180)
            if angle < 0
                angle = angle + 180;
            end
            
            orientations = [orientations; angle];
            numSegments = numSegments + 1;
        end
    end
    
    % Convert to 0-360 degrees range by adding 180 degrees
    % This gives us the full range of orientations
    orientations360 = [orientations; orientations + 180];
    
    % Ensure all angles are in 0-360 range
    orientations360 = mod(orientations360, 360);
    
    numOrientations = length(orientations);
    
    % Display summary information
    fprintf('Vector-based Rose Diagram:\n');
    fprintf('Number of fault lineaments: %d\n', length(FaultLineaments));
    fprintf('Number of orientation segments: %d\n', numOrientations);
    fprintf('Orientation range: %.1f° to %.1f°\n', min(orientations), max(orientations));
    
end