function toggleVectorLineamentsVisibility(checkbox_handle, iter_idx)
%toggleVectorLineamentsVisibility - Toggle vector lineament visibility for a specific tab
%
% This function finds all vector lineament lines in the specified axes and
% toggles their visibility based on the checkbox state.
%
% Inputs:
%   checkbox_handle (uicontrol handle): The checkbox control (contains axes and line handles in UserData)
%   iter_idx (integer): The iteration index (for tag matching)

    % Get UserData from checkbox
    user_data = get(checkbox_handle, 'UserData');
    if isempty(user_data) || ~isfield(user_data, 'ax') || ~isfield(user_data, 'handles')
        % Fallback: find axes in the checkbox's parent (tab)
        parent = get(checkbox_handle, 'Parent');
        ax = findobj(parent, 'Type', 'axes');
        if isempty(ax)
            return;  % Can't find axes, exit
        end
        ax = ax(1);  % Take first axes if multiple found
        
        % Try to find vector lineament lines by tag
        all_children = get(ax, 'Children');
        vector_lines = [];
        for i = 1:length(all_children)
            if isprop(all_children(i), 'Tag')
                tag = get(all_children(i), 'Tag');
                if ~isempty(tag) && contains(tag, ['VectorLineament_', num2str(iter_idx)])
                    vector_lines = [vector_lines; all_children(i)];
                end
            end
        end
        if isempty(vector_lines)
            return;  % Can't find vector lineaments, exit
        end
    else
        ax = user_data.ax;
        vector_lines = user_data.handles;
    end
    
    % Get checkbox value
    show_vectors = get(checkbox_handle, 'Value');
    
    % Toggle visibility
    if ~isempty(vector_lines)
        if show_vectors
            set(vector_lines, 'Visible', 'on');
        else
            set(vector_lines, 'Visible', 'off');
        end
    end
end



