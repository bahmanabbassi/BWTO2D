%% BHO_SensitivityAnalysis.m
% ==========================================================================
% SENSITIVITY ANALYSIS FOR BAYESIAN TOPOLOGY OPTIMIZATION (BTO)
% ==========================================================================
%
% PURPOSE:
%   Analyzes the sensitivity of BTO parameters on lineament detection
%   performance metrics (GRM and F-Beta scores).
%
% PREREQUISITES:
%   Before running this script, load data using the BWTO2D GUI:
%   1. Run Polygonize (loads polygon coordinates)
%   2. Run Point Data (loads XYZ data)
%   3. Run Lineaments Shapefile (loads ground truth)
%   4. Run Merge (in Automatic BTO tab) to prepare inputs
%
% F-BETA TOLERANCE:
%   - Set TOLERANCE_VALUE = 0 for automatic estimation (recommended)
%   - Or specify a value in COORDINATE UNITS (degrees for geographic data)
%   - The auto-estimation targets pilot F-beta in [0.4-0.6] range
%
% OUTPUTS:
%   - Excel spreadsheet with all results
%   - Plots of Parameter vs GRM and F-Beta scores (with error bars)
%
% AUTHOR:
%   Bahman Abbassi (bahman.abbassi@uqat.ca)
%   University of Quebec (UQAT)
%
% ==========================================================================

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 1: USER CONFIGURATION
% ═══════════════════════════════════════════════════════════════════════

clear; clc;
warning('off', 'all');

% ═══════════════════════════════════════════════════════════════════════
% SUPPRESS WAITBARS: Set global flag to prevent waitbar accumulation
% ═══════════════════════════════════════════════════════════════════════
global SUPPRESS_WAITBARS;
SUPPRESS_WAITBARS = true;  % This tells Lineaments_Auto7.m to skip waitbar creation

% Initial cleanup: close any leftover waitbars from previous sessions
try
    waitbarFigs = findall(0, 'Type', 'figure', 'Tag', 'TMWWaitbar');
    if ~isempty(waitbarFigs), close(waitbarFigs); end
    modalFigs = findall(0, 'Type', 'figure', 'WindowStyle', 'modal');
    if ~isempty(modalFigs), close(modalFigs); end
catch
end
drawnow;

fprintf('═══════════════════════════════════════════════════════════════════\n');
fprintf('  BHO SENSITIVITY ANALYSIS SCRIPT\n');
fprintf('═══════════════════════════════════════════════════════════════════\n\n');

% -------------------------------------------------------------------------
% PARAMETER TO TEST
% -------------------------------------------------------------------------
% Options: 'Exploration_Ratio', 'NumSeed_Points', 'GPActiveSet_Size', 
%          'AcquisitionFunction'
%
% Set RUN_ALL_PARAMETERS = true to iterate through ALL parameters automatically
RUN_ALL_PARAMETERS = true;

% If RUN_ALL_PARAMETERS = false, only this single parameter will be tested:
PARAMETER_TO_TEST = 'Exploration_Ratio';

% Full list of parameters to test (when RUN_ALL_PARAMETERS = true)
ALL_PARAMETERS_LIST = {
    'Exploration_Ratio'  
    'NumSeed_Points'
    'GPActiveSet_Size'
    'AcquisitionFunction'
};

% -------------------------------------------------------------------------
% PARAMETER RANGES (for numeric parameters)
% -------------------------------------------------------------------------
% Exploration_Ratio: Controls exploration vs exploitation balance (0 to 1)
EXPLORATION_RATIO_MIN = 0.1;
EXPLORATION_RATIO_MAX = 0.9;
EXPLORATION_RATIO_STEP = 0.1;

% NumSeed_Points: Initial random sampling points before GP model
NUMSEED_POINTS_MIN = 2;
NUMSEED_POINTS_MAX = 10;
NUMSEED_POINTS_STEP = 1;

% GPActiveSet_Size: Subset size for GP approximation
GPACTIVESET_SIZE_MIN = 100;
GPACTIVESET_SIZE_MAX = 500;
GPACTIVESET_SIZE_STEP = 50;

% Acquisition Functions to test (select which ones)
ACQUISITION_FUNCTIONS_TO_TEST = {
    'EI per Second Plus'           % expected-improvement-per-second-plus
    'Expected Improvement'         % expected-improvement
    'Expected Improvement Plus'    % expected-improvement-plus
    'EI per Second'                % expected-improvement-per-second
    'Lower Confidence Bound'       % lower-confidence-bound
    'Probability of Improvement'   % probability-of-improvement
};

% -------------------------------------------------------------------------
% BHO EXECUTION SETTINGS
% -------------------------------------------------------------------------
% Number of BHO iterations per run (higher = more thorough but slower)
BHO_ITERATIONS = 50;

% Number of repetitions per parameter value (for statistical robustness)
NUM_REPETITIONS = 7;

% Maximum time per BHO run (in minutes, 0 = unlimited)
MAX_TIME_MINUTES = 0;

% -------------------------------------------------------------------------
% F-BETA SCORE SETTINGS
% -------------------------------------------------------------------------
% Tolerance for F-beta calculation:
%   - Set to 0 or empty for AUTO-ESTIMATION (recommended)
%   - Or specify a value in COORDINATE UNITS (degrees for geographic data)
%   - Example: 0.005 degrees ≈ 10-15 pixels for typical datasets
%
% Note: If your coordinates are in degrees, do NOT use arc-seconds directly.
%       Convert: tolerance_degrees = arcseconds / 3600
TOLERANCE_VALUE = 0.0176;      % 0 = auto-estimate, or specify in coordinate units
BETA_FBETA = 0.2;         % F-beta parameter (precision emphasis)

% -------------------------------------------------------------------------
% OUTPUT SETTINGS
% -------------------------------------------------------------------------
OUTPUT_FOLDER = pwd;      % Current directory (or specify a path)
SAVE_INTERMEDIATE = true; % Save results after each parameter value

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 2: DEFAULT BHO PARAMETERS (fixed during sensitivity analysis)
% ═══════════════════════════════════════════════════════════════════════

% BHO Configuration Defaults
DEFAULT_EXPLORATION_RATIO = 0.5;
DEFAULT_NUMSEED_POINTS = 6;
DEFAULT_GPACTIVESET_SIZE = 250;
DEFAULT_ACQUISITION_FUNCTION = 'expected-improvement-per-second-plus';
DEFAULT_IS_DETERMINISTIC = true;
DEFAULT_USE_PARALLEL = false;

% =========================================================================
% Lineament Extraction Fixed Parameters (MUST MATCH GUI VALUES!)
% These are from your GUI's "Fixed Parameters" section
% =========================================================================
DEFAULT_SIGMA2 = 0;           % σI: Image Filter Ratio (GUI shows 0)
DEFAULT_SDF = 1;              % δ: Scale Dilation Factor (GUI shows 1)
DEFAULT_LINE_RES = 1;         % R: Resize Factor (GUI shows 1)
DEFAULT_DR = 3;               % d: Dimensionality Reduction target (GUI shows 3)
DEFAULT_N_SCALES = 1;         % Na: Number of CWT Scales (GUI shows 1)

% =========================================================================
% BHO Search Ranges (MUST MATCH GUI VALUES!)
% These ranges should match what you have configured in the GUI's
% "Hyperparameters Range" column for proper sensitivity analysis
% =========================================================================
% From your GUI screenshot and BHO trace:
WSFR_RANGE = [0, 1];              % σ: Wavelet Smoothness Filter Ratio
Z_RANGE = [0.5, 3];               % Z*: Poisson kernel upward continuation
VSFW_RANGE = [0, 1];              % υ*: Variability of Step Filtering Width
DISSIMILARITY_RANGE = [0.5, 1];   % γ*: CWT Feature Dissimilarity
SALIENCY_RANGE = [50, 100];       % λ*: CWT Feature Saliency (%)
CWT_ANGLES_RANGE = [12, 36];      % Nθ*: Number of CWT Angles
W_CENTER = 10;                    % w* center value (from GUI)
W_RANGE_MULTIPLIER = [0.5, 2.5];  % w* range multiplier
STEP_FILTER_ANGLES_RANGE = [12, 36];  % Nφ*: Number of Step Filtering Angles
HYST_THRESHOLD_RANGE = [35, 85]; % ξ*: Strongest Lineament Components (%)

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 3: VERIFY DATA FROM GUI
% ═══════════════════════════════════════════════════════════════════════

fprintf('Checking for required data in MATLAB workspace...\n\n');

% Declare global variables (these should be populated by the GUI)
global XI YI in xv yv
global All_Data_Matrix
global CWT_Input_Features_Matrix_Auto
global All_Trg_Matrix
global FaultLineaments
global X_Pix Y_Pix
global YI_Real_Ratio
global pop_choice3
global XI_ YI_

% Check if required data is available
missingData = {};

if isempty(XI) || isempty(YI)
    missingData{end+1} = 'Coordinate grids (XI, YI) - Run Polygonize in GUI';
end

if isempty(in)
    missingData{end+1} = 'Polygon mask (in) - Run Polygonize in GUI';
end

if isempty(All_Data_Matrix)
    missingData{end+1} = 'Point data (All_Data_Matrix) - Run Point Data in GUI';
end

if isempty(CWT_Input_Features_Matrix_Auto)
    missingData{end+1} = 'CWT Input Matrix - Run Merge in Automatic BTO tab';
end

if isempty(All_Trg_Matrix)
    missingData{end+1} = 'Ground truth (All_Trg_Matrix) - Run Lineaments Shapefile in GUI';
end

if ~isempty(missingData)
    fprintf('ERROR: The following data is missing from MATLAB workspace:\n');
    for i = 1:length(missingData)
        fprintf('  ✗ %s\n', missingData{i});
    end
    fprintf('\nPlease load data using the BWTO2D GUI before running this script.\n');
    error('Missing required data. See messages above.');
end

fprintf('  ✓ Coordinate grids (XI, YI) loaded\n');
fprintf('  ✓ Polygon mask (in) loaded\n');
fprintf('  ✓ Point data (All_Data_Matrix) loaded: %s\n', mat2str(size(All_Data_Matrix)));
fprintf('  ✓ CWT Input Matrix loaded: %s\n', mat2str(size(CWT_Input_Features_Matrix_Auto)));
fprintf('  ✓ Ground truth (All_Trg_Matrix) loaded: %s\n', mat2str(size(All_Trg_Matrix)));

if ~isempty(FaultLineaments)
    fprintf('  ✓ Vector lineaments loaded: %d features\n', length(FaultLineaments));
end

% Set defaults if not already set
if isempty(X_Pix) || X_Pix == 0
    X_Pix = size(XI, 2);
end
if isempty(Y_Pix) || Y_Pix == 0
    Y_Pix = size(YI, 1);
end
if isempty(YI_Real_Ratio) || YI_Real_Ratio <= 0
    Lat_mean = mean(YI(:));
    YI_Real_Ratio = abs(1/(cos(deg2rad(Lat_mean))));
end
if isempty(pop_choice3)
    pop_choice3 = 'derpoisson2d';
end

fprintf('\nData verification complete.\n\n');

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 3b: TOLERANCE ESTIMATION
% ═══════════════════════════════════════════════════════════════════════

if isempty(TOLERANCE_VALUE) || TOLERANCE_VALUE <= 0
    fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    fprintf('  AUTO-ESTIMATING OPTIMAL TOLERANCE FOR F-BETA\n');
    fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    try
        [TOLERANCE_COORD, tolerance_info] = estimateTolerancePreBTO(true);
        fprintf('\n  ✓ Auto-estimated tolerance: %.6f (%.1f pixels)\n', ...
            TOLERANCE_COORD, tolerance_info.optimal_tolerance_pixels);
        fprintf('  ✓ Expected pilot F-beta: %.3f\n\n', tolerance_info.optimal_fbeta);
    catch ME
        % Fallback: estimate from pixel size
        fprintf('  ⚠ Auto-estimation failed: %s\n', ME.message);
        fprintf('  → Using fallback: 10 pixels in coordinate units\n');
        
        % Calculate pixel size from coordinate grids
        global XI_line_Auto YI_line_Auto
        if ~isempty(XI_line_Auto) && size(XI_line_Auto, 2) > 1
            pixel_dx = abs(XI_line_Auto(1,2) - XI_line_Auto(1,1));
        else
            pixel_dx = abs(max(XI(:)) - min(XI(:))) / size(XI, 2);
        end
        TOLERANCE_COORD = 10 * pixel_dx;  % 10 pixels
        fprintf('  → Fallback tolerance: %.6f\n\n', TOLERANCE_COORD);
    end
else
    TOLERANCE_COORD = TOLERANCE_VALUE;
    fprintf('  Using specified tolerance: %.6f (coordinate units)\n\n', TOLERANCE_COORD);
end

% Display configured search ranges for verification
fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
fprintf('  BHO SEARCH RANGES (verify these match your GUI!)\n');
fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
fprintf('  WSFR (σ):            [%.2f, %.2f]\n', WSFR_RANGE(1), WSFR_RANGE(2));
fprintf('  Z*:                  [%.2f, %.2f]\n', Z_RANGE(1), Z_RANGE(2));
fprintf('  VSFW (υ*):           [%.2f, %.2f]\n', VSFW_RANGE(1), VSFW_RANGE(2));
fprintf('  Dissimilarity (γ*):  [%.2f, %.2f]\n', DISSIMILARITY_RANGE(1), DISSIMILARITY_RANGE(2));
fprintf('  Saliency (λ*):       [%.0f, %.0f]\n', SALIENCY_RANGE(1), SALIENCY_RANGE(2));
fprintf('  NAngles (Nθ*):       [%.0f, %.0f]\n', CWT_ANGLES_RANGE(1), CWT_ANGLES_RANGE(2));
fprintf('  w* center:           %.0f (range: [%.1f, %.1f] × center)\n', W_CENTER, W_RANGE_MULTIPLIER(1), W_RANGE_MULTIPLIER(2));
fprintf('  NSFA (Nφ*):          [%.0f, %.0f]\n', STEP_FILTER_ANGLES_RANGE(1), STEP_FILTER_ANGLES_RANGE(2));
fprintf('  SLC (ξ*):            [%.0f, %.0f]\n', HYST_THRESHOLD_RANGE(1), HYST_THRESHOLD_RANGE(2));
fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
fprintf('  Fixed Parameters:\n');
fprintf('  N_Scales (Na):       %d\n', DEFAULT_N_SCALES);
fprintf('  Line_Res (R):        %d\n', DEFAULT_LINE_RES);
fprintf('  DR (d):              %d\n', DEFAULT_DR);
fprintf('  SDF (δ):             %.1f\n', DEFAULT_SDF);
fprintf('  Sigma2 (σI):         %.1f\n', DEFAULT_SIGMA2);
fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
fprintf('  F-Beta Settings:\n');
fprintf('  Tolerance:           %.6f (coord units)\n', TOLERANCE_COORD);
fprintf('  Beta:                %.2f\n', BETA_FBETA);
fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n');

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 4: MAIN LOOP OVER PARAMETERS
% ═══════════════════════════════════════════════════════════════════════

% Determine which parameters to test
if RUN_ALL_PARAMETERS
    parametersToRun = ALL_PARAMETERS_LIST;
    fprintf('═══════════════════════════════════════════════════════════════════\n');
    fprintf('  RUNNING ALL PARAMETERS AUTOMATICALLY\n');
    fprintf('  Parameters: %s\n', strjoin(parametersToRun', ', '));
    fprintf('═══════════════════════════════════════════════════════════════════\n\n');
else
    parametersToRun = {PARAMETER_TO_TEST};
end

% Store all results for summary at the end
allParameterResults = struct();

for paramLoopIdx = 1:length(parametersToRun)
    CURRENT_PARAMETER = parametersToRun{paramLoopIdx};
    
    if RUN_ALL_PARAMETERS
        fprintf('\n');
        fprintf('███████████████████████████████████████████████████████████████████\n');
        fprintf('  PARAMETER %d/%d: %s\n', paramLoopIdx, length(parametersToRun), CURRENT_PARAMETER);
        fprintf('███████████████████████████████████████████████████████████████████\n\n');
    end

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 4a: GENERATE PARAMETER VALUES TO TEST
% ═══════════════════════════════════════════════════════════════════════

switch CURRENT_PARAMETER
    case 'Exploration_Ratio'
        paramValues = EXPLORATION_RATIO_MIN:EXPLORATION_RATIO_STEP:EXPLORATION_RATIO_MAX;
        paramLabel = 'Exploration Ratio';
        paramUnit = '';
        
    case 'NumSeed_Points'
        paramValues = NUMSEED_POINTS_MIN:NUMSEED_POINTS_STEP:NUMSEED_POINTS_MAX;
        paramLabel = 'Number of Seed Points';
        paramUnit = '';
        
    case 'GPActiveSet_Size'
        paramValues = GPACTIVESET_SIZE_MIN:GPACTIVESET_SIZE_STEP:GPACTIVESET_SIZE_MAX;
        paramLabel = 'GP Active Set Size';
        paramUnit = '';
        
    case 'AcquisitionFunction'
        paramValues = 1:length(ACQUISITION_FUNCTIONS_TO_TEST);
        paramLabel = 'Acquisition Function';
        paramUnit = '';
        
    otherwise
        error('Unknown parameter: %s', CURRENT_PARAMETER);
end

numParamValues = length(paramValues);
totalRuns = numParamValues * NUM_REPETITIONS;

fprintf('═══════════════════════════════════════════════════════════════════\n');
fprintf('  SENSITIVITY ANALYSIS CONFIGURATION\n');
fprintf('═══════════════════════════════════════════════════════════════════\n');
fprintf('  Parameter to test: %s\n', CURRENT_PARAMETER);
fprintf('  Number of values:  %d\n', numParamValues);
fprintf('  Repetitions each:  %d\n', NUM_REPETITIONS);
fprintf('  Total BHO runs:    %d\n', totalRuns);
fprintf('  BHO iterations:    %d per run\n', BHO_ITERATIONS);
fprintf('═══════════════════════════════════════════════════════════════════\n\n');

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 5: SETUP BHO OBJECTIVE FUNCTION
% ═══════════════════════════════════════════════════════════════════════

% Calculate w range
min_w = max(2, round(W_RANGE_MULTIPLIER(1) * W_CENTER));
max_w = round(W_RANGE_MULTIPLIER(2) * W_CENTER);
if max_w <= min_w
    max_w = min_w + 10;
end

% Define optimizable variables (same as GUI)
vars = [
    optimizableVariable('WSFR',           WSFR_RANGE, 'Type', 'real')
    optimizableVariable('Z',              Z_RANGE, 'Type', 'real')
    optimizableVariable('VSFW',           VSFW_RANGE, 'Type', 'real')
    optimizableVariable('FDissimilarity', DISSIMILARITY_RANGE, 'Type', 'real')
    optimizableVariable('FSaliency',      SALIENCY_RANGE, 'Type', 'real')
    optimizableVariable('NAngles',        CWT_ANGLES_RANGE, 'Type', 'integer')
    optimizableVariable('w',              [min_w, max_w], 'Type', 'integer')
    optimizableVariable('NSFA',           STEP_FILTER_ANGLES_RANGE, 'Type', 'integer')
    optimizableVariable('SLC',            HYST_THRESHOLD_RANGE, 'Type', 'integer')
    optimizableVariable('orderx',         {'0', '1'}, 'Type', 'categorical')
];

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 6: RUN SENSITIVITY ANALYSIS
% ═══════════════════════════════════════════════════════════════════════

% Initialize results storage
results = struct();
results.parameter = CURRENT_PARAMETER;
results.paramValues = paramValues;
results.paramLabels = {};
results.GRM_all = zeros(numParamValues, NUM_REPETITIONS);
results.FBeta_all = zeros(numParamValues, NUM_REPETITIONS);
results.GRM_mean = zeros(numParamValues, 1);
results.GRM_std = zeros(numParamValues, 1);
results.FBeta_mean = zeros(numParamValues, 1);
results.FBeta_std = zeros(numParamValues, 1);
results.runTime = zeros(numParamValues, NUM_REPETITIONS);

% Generate parameter labels for plots
if strcmp(CURRENT_PARAMETER, 'AcquisitionFunction')
    results.paramLabels = ACQUISITION_FUNCTIONS_TO_TEST;
else
    for i = 1:numParamValues
        results.paramLabels{i} = num2str(paramValues(i));
    end
end

fprintf('Starting sensitivity analysis...\n\n');
overallStartTime = tic;
runCounter = 0;

for pIdx = 1:numParamValues
    currentParamValue = paramValues(pIdx);
    
    % Get display label
    if strcmp(CURRENT_PARAMETER, 'AcquisitionFunction')
        currentLabel = ACQUISITION_FUNCTIONS_TO_TEST{currentParamValue};
    else
        currentLabel = num2str(currentParamValue);
    end
    
    fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    fprintf('  Testing %s = %s (%d/%d)\n', paramLabel, currentLabel, pIdx, numParamValues);
    fprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    for repIdx = 1:NUM_REPETITIONS
        runCounter = runCounter + 1;
        fprintf('\n  Repetition %d/%d (Run %d/%d overall)\n', ...
            repIdx, NUM_REPETITIONS, runCounter, totalRuns);
        
        runStartTime = tic;
        
        % ═══════════════════════════════════════════════════════════════
        % CLEANUP: Close all waitbars and flush graphics before each run
        % ═══════════════════════════════════════════════════════════════
        closeAllWaitbars();
        drawnow;  % Flush graphics queue
        
        % Clear previous BHO state
        clear global BHO_GroundTruthMetrics BHO_BestOutputs BHO_BestSoFarHistory
        global BHO_GroundTruthMetrics BHO_BestOutputs BHO_BestSoFarHistory
        
        % Set BHO parameters based on what we're testing
        switch CURRENT_PARAMETER
            case 'Exploration_Ratio'
                explorationRatio = currentParamValue;
                numSeedPoints = DEFAULT_NUMSEED_POINTS;
                gpActiveSetSize = DEFAULT_GPACTIVESET_SIZE;
                acquisitionFunctionName = DEFAULT_ACQUISITION_FUNCTION;
                
            case 'NumSeed_Points'
                explorationRatio = DEFAULT_EXPLORATION_RATIO;
                numSeedPoints = currentParamValue;
                gpActiveSetSize = DEFAULT_GPACTIVESET_SIZE;
                acquisitionFunctionName = DEFAULT_ACQUISITION_FUNCTION;
                
            case 'GPActiveSet_Size'
                explorationRatio = DEFAULT_EXPLORATION_RATIO;
                numSeedPoints = DEFAULT_NUMSEED_POINTS;
                gpActiveSetSize = currentParamValue;
                acquisitionFunctionName = DEFAULT_ACQUISITION_FUNCTION;
                
            case 'AcquisitionFunction'
                explorationRatio = DEFAULT_EXPLORATION_RATIO;
                numSeedPoints = DEFAULT_NUMSEED_POINTS;
                gpActiveSetSize = DEFAULT_GPACTIVESET_SIZE;
                acquisitionFunctionName = mapAcquisitionFunctionName(ACQUISITION_FUNCTIONS_TO_TEST{currentParamValue});
        end
        
        % Set max time
        if MAX_TIME_MINUTES <= 0
            maxTime = Inf;
        else
            maxTime = 60 * MAX_TIME_MINUTES;
        end
        
        % Create objective function
        fun = @(x) Lineaments_Auto7(CWT_Input_Features_Matrix_Auto, All_Data_Matrix, ...
            x.WSFR, x.NAngles, str2double(string(x.orderx)), x.Z, x.w, ...
            x.VSFW, x.NSFA, x.SLC, x.FDissimilarity, x.FSaliency, ...
            DEFAULT_N_SCALES, DEFAULT_LINE_RES, DEFAULT_DR, DEFAULT_SDF, ...
            DEFAULT_SIGMA2, TOLERANCE_COORD, BETA_FBETA);
        
        % Run Bayesian Optimization
        try
            bayesResults = bayesopt(fun, vars, ...
                'MaxObjectiveEvaluations', BHO_ITERATIONS, ...
                'AcquisitionFunctionName', acquisitionFunctionName, ...
                'ExplorationRatio', explorationRatio, ...
                'NumSeedPoints', round(numSeedPoints), ...
                'GPActiveSetSize', round(gpActiveSetSize), ...
                'MaxTime', maxTime, ...
                'IsObjectiveDeterministic', DEFAULT_IS_DETERMINISTIC, ...
                'UseParallel', DEFAULT_USE_PARALLEL, ...
                'Verbose', 0, ...
                'PlotFcn', []);
            
            % Extract best GRM (convert from negative objective)
            bestObjective = bayesResults.MinObjective;
            bestGRM = -bestObjective;  % GRM is negated in objective function
            
            % Extract best F-Beta from stored metrics
            if ~isempty(BHO_BestOutputs) && isfield(BHO_BestOutputs, 'fbeta_score')
                bestFBeta = BHO_BestOutputs.fbeta_score;
            elseif ~isempty(BHO_GroundTruthMetrics) && ~isempty(BHO_GroundTruthMetrics.fbeta_scores)
                % Find the F-Beta at the best GRM iteration
                [~, bestIdx] = min(-BHO_GroundTruthMetrics.GRM_values);
                bestFBeta = BHO_GroundTruthMetrics.fbeta_scores(bestIdx);
            else
                bestFBeta = NaN;
            end
            
            % Handle NaN values
            if isnan(bestGRM) || isinf(bestGRM)
                bestGRM = 0;
            end
            if isnan(bestFBeta)
                bestFBeta = 0;
            end
            
        catch ME
            fprintf('    ✗ BHO failed: %s\n', ME.message);
            bestGRM = NaN;
            bestFBeta = NaN;
        end
        
        % ═══════════════════════════════════════════════════════════════
        % CLEANUP: Close all waitbars and flush graphics after each run
        % ═══════════════════════════════════════════════════════════════
        closeAllWaitbars();
        drawnow;  % Flush graphics queue
        pause(0.1);  % Brief pause to allow system cleanup
        
        runTime = toc(runStartTime);
        
        % Store results
        results.GRM_all(pIdx, repIdx) = bestGRM;
        results.FBeta_all(pIdx, repIdx) = bestFBeta;
        results.runTime(pIdx, repIdx) = runTime;
        
        fprintf('    ✓ GRM = %.4f, F-Beta = %.4f (%.1f sec)\n', ...
            bestGRM, bestFBeta, runTime);
    end
    
    % Calculate statistics for this parameter value
    results.GRM_mean(pIdx) = mean(results.GRM_all(pIdx, :), 'omitnan');
    results.GRM_std(pIdx) = std(results.GRM_all(pIdx, :), 'omitnan');
    results.FBeta_mean(pIdx) = mean(results.FBeta_all(pIdx, :), 'omitnan');
    results.FBeta_std(pIdx) = std(results.FBeta_all(pIdx, :), 'omitnan');
    
    fprintf('\n  Summary: GRM = %.4f ± %.4f, F-Beta = %.4f ± %.4f\n', ...
        results.GRM_mean(pIdx), results.GRM_std(pIdx), ...
        results.FBeta_mean(pIdx), results.FBeta_std(pIdx));
    
    % Save intermediate results
    if SAVE_INTERMEDIATE
        saveResults(results, OUTPUT_FOLDER, CURRENT_PARAMETER, true);
    end
end

paramTime = toc(overallStartTime);
fprintf('\n═══════════════════════════════════════════════════════════════════\n');
fprintf('  PARAMETER %s COMPLETE\n', CURRENT_PARAMETER);
fprintf('  Time for this parameter: %.1f minutes\n', paramTime/60);
fprintf('═══════════════════════════════════════════════════════════════════\n\n');

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 5: SAVE FINAL RESULTS AND GENERATE PLOTS FOR THIS PARAMETER
% ═══════════════════════════════════════════════════════════════════════

% Save final results (includes .fig files)
[excelFile, figGRM, figFBeta, figGRMFile, figFBetaFile] = saveResults(results, OUTPUT_FOLDER, CURRENT_PARAMETER, false);

fprintf('Results saved to:\n');
fprintf('  Excel: %s\n', excelFile);
fprintf('  GRM Plot (PNG): %s\n', figGRM);
fprintf('  GRM Plot (FIG): %s\n', figGRMFile);
fprintf('  F-Beta Plot (PNG): %s\n', figFBeta);
fprintf('  F-Beta Plot (FIG): %s\n', figFBetaFile);

% Store results for summary
allParameterResults.(CURRENT_PARAMETER) = results;

end  % End of parameter loop

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 6: FINAL SUMMARY (when running all parameters)
% ═══════════════════════════════════════════════════════════════════════

if RUN_ALL_PARAMETERS
    fprintf('\n');
    fprintf('███████████████████████████████████████████████████████████████████\n');
    fprintf('  ALL SENSITIVITY ANALYSES COMPLETE\n');
    fprintf('███████████████████████████████████████████████████████████████████\n');
    fprintf('\nSummary of Best Results:\n');
    fprintf('─────────────────────────────────────────────────────────────────────\n');
    fprintf('%-25s %12s %12s\n', 'Parameter', 'Best GRM', 'Best F-Beta');
    fprintf('─────────────────────────────────────────────────────────────────────\n');
    
    for i = 1:length(parametersToRun)
        paramName = parametersToRun{i};
        res = allParameterResults.(paramName);
        [maxGRM, maxGRMIdx] = max(res.GRM_mean);
        [maxFBeta, maxFBetaIdx] = max(res.FBeta_mean);
        
        if strcmp(paramName, 'AcquisitionFunction')
            bestGRMVal = res.paramLabels{maxGRMIdx};
            bestFBetaVal = res.paramLabels{maxFBetaIdx};
        else
            bestGRMVal = num2str(res.paramValues(maxGRMIdx));
            bestFBetaVal = num2str(res.paramValues(maxFBetaIdx));
        end
        
        fprintf('%-25s %12.2f %12.4f\n', paramName, maxGRM, max(res.FBeta_mean));
        fprintf('  Best GRM at:    %s\n', bestGRMVal);
        fprintf('  Best F-Beta at: %s\n', bestFBetaVal);
    end
    fprintf('─────────────────────────────────────────────────────────────────────\n');
end

%% ═══════════════════════════════════════════════════════════════════════
%  HELPER FUNCTIONS
% ═══════════════════════════════════════════════════════════════════════

function acqFuncName = mapAcquisitionFunctionName(displayName)
%mapAcquisitionFunctionName Maps GUI display names to MATLAB bayesopt names
    switch displayName
        case 'EI per Second Plus'
            acqFuncName = 'expected-improvement-per-second-plus';
        case 'Expected Improvement'
            acqFuncName = 'expected-improvement';
        case 'Expected Improvement Plus'
            acqFuncName = 'expected-improvement-plus';
        case 'EI per Second'
            acqFuncName = 'expected-improvement-per-second';
        case 'Lower Confidence Bound'
            acqFuncName = 'lower-confidence-bound';
        case 'Probability of Improvement'
            acqFuncName = 'probability-of-improvement';
        otherwise
            acqFuncName = 'expected-improvement-per-second-plus';
    end
end

function [excelFile, figGRMPngFile, figFBetaPngFile, figGRMFigFile, figFBetaFigFile] = saveResults(results, outputFolder, paramName, isIntermediate)
%saveResults Saves results to Excel and generates plots (PNG and FIG formats)
    
    % Generate timestamp
    timestamp = datestr(now, 'yyyymmdd_HHMMSS');
    
    if isIntermediate
        suffix = '_intermediate';
    else
        suffix = '';
    end
    
    % Create output filenames
    baseFileName = sprintf('SensitivityAnalysis_%s_%s%s', paramName, timestamp, suffix);
    excelFile = fullfile(outputFolder, [baseFileName '.xlsx']);
    figGRMPngFile = fullfile(outputFolder, [baseFileName '_GRM.png']);
    figFBetaPngFile = fullfile(outputFolder, [baseFileName '_FBeta.png']);
    figGRMFigFile = fullfile(outputFolder, [baseFileName '_GRM.fig']);
    figFBetaFigFile = fullfile(outputFolder, [baseFileName '_FBeta.fig']);
    
    % =====================================================================
    % Save to Excel
    % =====================================================================
    
    % Create summary table
    numParams = length(results.paramValues);
    numReps = size(results.GRM_all, 2);
    
    if strcmp(results.parameter, 'AcquisitionFunction')
        paramCol = results.paramLabels(:);
    else
        paramCol = num2cell(results.paramValues(:));
    end
    
    summaryTable = table(paramCol, results.GRM_mean, results.GRM_std, ...
        results.FBeta_mean, results.FBeta_std, ...
        'VariableNames', {'ParameterValue', 'GRM_Mean', 'GRM_Std', 'FBeta_Mean', 'FBeta_Std'});
    
    % Create detailed table with all repetitions
    detailRows = {};
    for pIdx = 1:numParams
        for repIdx = 1:numReps
            if strcmp(results.parameter, 'AcquisitionFunction')
                paramVal = results.paramLabels{pIdx};
            else
                paramVal = results.paramValues(pIdx);
            end
            detailRows{end+1, 1} = paramVal;
            detailRows{end, 2} = repIdx;
            detailRows{end, 3} = results.GRM_all(pIdx, repIdx);
            detailRows{end, 4} = results.FBeta_all(pIdx, repIdx);
            detailRows{end, 5} = results.runTime(pIdx, repIdx);
        end
    end
    
    detailTable = cell2table(detailRows, 'VariableNames', ...
        {'ParameterValue', 'Repetition', 'GRM', 'FBeta', 'RunTime_sec'});
    
    % Write to Excel
    writetable(summaryTable, excelFile, 'Sheet', 'Summary');
    writetable(detailTable, excelFile, 'Sheet', 'AllRuns');
    
    % Write configuration info
    configInfo = {
        'Parameter Tested', results.parameter;
        'Number of Values', numParams;
        'Repetitions per Value', numReps;
        'Timestamp', timestamp
    };
    configTable = cell2table(configInfo, 'VariableNames', {'Setting', 'Value'});
    writetable(configTable, excelFile, 'Sheet', 'Configuration');
    
    % =====================================================================
    % Generate Plots (only for final save)
    % =====================================================================
    
    if ~isIntermediate
        % Color scheme - professional scientific palette
        colorGRM = [0.204, 0.451, 0.663];      % Steel blue
        colorFBeta = [0.839, 0.373, 0.169];   % Burnt orange
        colorFill = [0.9, 0.9, 0.9];          % Light gray for error bands
        
        % X-axis values for plotting
        if strcmp(results.parameter, 'AcquisitionFunction')
            xVals = 1:numParams;
            xTickLabels = results.paramLabels;
            useCategorial = true;
        else
            xVals = results.paramValues;
            xTickLabels = {};
            useCategorial = false;
        end
        
        % ---------------------------------------------------------------------
        % GRM Plot
        % ---------------------------------------------------------------------
        figGRM = figure('Position', [100, 100, 800, 500], 'Color', 'w');
        hold on;
        
        % Error band (filled area for std deviation)
        if numReps > 1
            fillX = [xVals, fliplr(xVals)];
            fillY = [results.GRM_mean' + results.GRM_std', ...
                     fliplr(results.GRM_mean' - results.GRM_std')];
            fill(fillX, fillY, colorGRM, 'FaceAlpha', 0.2, 'EdgeColor', 'none');
        end
        
        % Mean line with markers
        plot(xVals, results.GRM_mean, '-o', ...
            'Color', colorGRM, 'LineWidth', 2, 'MarkerSize', 8, ...
            'MarkerFaceColor', colorGRM, 'MarkerEdgeColor', 'w');
        
        % Error bars
        if numReps > 1
            errorbar(xVals, results.GRM_mean, results.GRM_std, ...
                'Color', colorGRM, 'LineStyle', 'none', 'LineWidth', 1.5, ...
                'CapSize', 6);
        end
        
        % Individual data points (scatter)
        for pIdx = 1:numParams
            scatter(repmat(xVals(pIdx), 1, numReps), results.GRM_all(pIdx, :), ...
                30, colorGRM, 'filled', 'MarkerFaceAlpha', 0.4);
        end
        
        hold off;
        
        % Formatting
        xlabel(getParamLabel(results.parameter), 'FontSize', 12, 'FontWeight', 'bold');
        ylabel('Graph Representativeness Metric (GRM)', 'FontSize', 12, 'FontWeight', 'bold');
        title(sprintf('Sensitivity Analysis: %s vs GRM', getParamLabel(results.parameter)), ...
            'FontSize', 14, 'FontWeight', 'bold');
        
        if useCategorial
            xticks(xVals);
            xticklabels(xTickLabels);
            xtickangle(30);
        end
        
        grid on;
        box on;
        set(gca, 'FontSize', 11, 'LineWidth', 1);
        
        % Add legend if multiple reps
        if numReps > 1
            legend({'Std Dev Band', 'Mean', 'Error Bars', 'Individual Runs'}, ...
                'Location', 'best', 'FontSize', 10);
        end
        
        % Save figure in both PNG and FIG formats
        saveas(figGRM, figGRMPngFile);
        savefig(figGRM, figGRMFigFile);
        
        % ---------------------------------------------------------------------
        % F-Beta Plot
        % ---------------------------------------------------------------------
        figFBeta = figure('Position', [150, 150, 800, 500], 'Color', 'w');
        hold on;
        
        % Error band
        if numReps > 1
            fillX = [xVals, fliplr(xVals)];
            fillY = [results.FBeta_mean' + results.FBeta_std', ...
                     fliplr(results.FBeta_mean' - results.FBeta_std')];
            fill(fillX, fillY, colorFBeta, 'FaceAlpha', 0.2, 'EdgeColor', 'none');
        end
        
        % Mean line with markers
        plot(xVals, results.FBeta_mean, '-s', ...
            'Color', colorFBeta, 'LineWidth', 2, 'MarkerSize', 8, ...
            'MarkerFaceColor', colorFBeta, 'MarkerEdgeColor', 'w');
        
        % Error bars
        if numReps > 1
            errorbar(xVals, results.FBeta_mean, results.FBeta_std, ...
                'Color', colorFBeta, 'LineStyle', 'none', 'LineWidth', 1.5, ...
                'CapSize', 6);
        end
        
        % Individual data points
        for pIdx = 1:numParams
            scatter(repmat(xVals(pIdx), 1, numReps), results.FBeta_all(pIdx, :), ...
                30, colorFBeta, 'filled', 'MarkerFaceAlpha', 0.4);
        end
        
        hold off;
        
        % Formatting
        xlabel(getParamLabel(results.parameter), 'FontSize', 12, 'FontWeight', 'bold');
        ylabel('F-Beta Score', 'FontSize', 12, 'FontWeight', 'bold');
        title(sprintf('Sensitivity Analysis: %s vs F-Beta Score', getParamLabel(results.parameter)), ...
            'FontSize', 14, 'FontWeight', 'bold');
        
        if useCategorial
            xticks(xVals);
            xticklabels(xTickLabels);
            xtickangle(30);
        end
        
        ylim([0, 1]);  % F-Beta is always between 0 and 1
        grid on;
        box on;
        set(gca, 'FontSize', 11, 'LineWidth', 1);
        
        if numReps > 1
            legend({'Std Dev Band', 'Mean', 'Error Bars', 'Individual Runs'}, ...
                'Location', 'best', 'FontSize', 10);
        end
        
        % Save figure in both PNG and FIG formats
        saveas(figFBeta, figFBetaPngFile);
        savefig(figFBeta, figFBetaFigFile);
        
    else
        figGRMPngFile = '';
        figFBetaPngFile = '';
        figGRMFigFile = '';
        figFBetaFigFile = '';
    end
end

function label = getParamLabel(paramName)
%getParamLabel Returns a formatted label for the parameter
    switch paramName
        case 'Exploration_Ratio'
            label = 'Exploration Ratio';
        case 'NumSeed_Points'
            label = 'Number of Seed Points';
        case 'GPActiveSet_Size'
            label = 'GP Active Set Size';
        case 'AcquisitionFunction'
            label = 'Acquisition Function';
        otherwise
            label = paramName;
    end
end

function closeAllWaitbars()
%closeAllWaitbars Closes all open waitbar figures to prevent accumulation
%   This function finds and closes all figures that are waitbars,
%   preventing memory issues during long-running sensitivity analysis.
    
    try
        % Method 1: Close figures by tag (waitbars typically have 'TMWWaitbar' tag)
        waitbarFigs = findall(0, 'Type', 'figure', 'Tag', 'TMWWaitbar');
        if ~isempty(waitbarFigs)
            close(waitbarFigs);
        end
        
        % Method 2: Close any remaining modal figures with 'waitbar' in name
        allFigs = findall(0, 'Type', 'figure');
        for i = 1:length(allFigs)
            try
                figName = get(allFigs(i), 'Name');
                if contains(lower(figName), 'waitbar') || ...
                   contains(lower(figName), 'cwt') || ...
                   contains(lower(figName), 'lineament') || ...
                   contains(lower(figName), 'graph') || ...
                   contains(lower(figName), 'saving') || ...
                   contains(lower(figName), 'loading') || ...
                   contains(lower(figName), 'processing')
                    close(allFigs(i));
                end
            catch
                % Figure may have been closed already, ignore
            end
        end
        
        % Method 3: Close any figures with WindowStyle 'modal' that aren't our plots
        modalFigs = findall(0, 'Type', 'figure', 'WindowStyle', 'modal');
        if ~isempty(modalFigs)
            close(modalFigs);
        end
        
    catch
        % Silently ignore errors during cleanup
    end
end

