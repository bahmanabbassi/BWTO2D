function [L_val, N_CWT] = Lineaments_Auto7(CWT_Input_Features_Matrix, All_Data_Matrix, WSFR...
    , N_Angles, orderx, Z, w, VSFW, NSFA, SLC, FDissimilarity, FSaliency, ...
    N_Scales, Line_Res, DR, SDF, sigma2, tolerance_arcsec, beta)
warning('off','all');

% Suppress waitbars during BTO optimization (they interrupt the live progress display)
global SUPPRESS_WAITBARS;
if isempty(SUPPRESS_WAITBARS)
    SUPPRESS_WAITBARS = true;  % Default: suppress waitbars
end
%--------------------------------------------------------------------------
% FUNCTION: Lineaments_Auto7
%
% PURPOSE:
%   Objective function of the Bayesian Topology Optimization (BTO) loop. For
%   one candidate hyperparameter vector it runs the complete curvilinear
%   pattern extraction pipeline, scores the resulting network with the Graph
%   Representativeness Metric (GRM), and returns the negated score, so that
%   minimizing L_val with MATLAB's bayesopt maximizes the GRM.
%
%   The pipeline has four stages, following Sections 1.1 to 1.3 of the paper:
%   1.  Poisson kCWT (Section 1.1). The input grid is decomposed into
%       directional coefficient maps using the Poisson Derivatives Mother
%       Wavelet, at N_Scales scales and N_Angles orientations.
%   2.  Coefficient selection and fusion (Algorithm 1, Section 1.2). The DR
%       most salient and mutually dissimilar maps are retained, masked to the
%       survey polygon, and range-adjusted.
%   3.  Curvilinear pattern extraction (Section 1.3). Each retained map is
%       convolved with a directional step filter, thresholded by hysteresis,
%       and cleaned morphologically. The cleaned maps are then intersected
%       into a single consensus network.
%   4.  Topological scoring (Algorithm 2, Section 1.3). The consensus network
%       is abstracted into a graph of segments and scored by the GRM.
%
%   When ground truth is available, the supervised metrics of Section 1.4
%   (F-beta, R_P21, HS, JSD) are computed and stored alongside the GRM for the
%   post-hoc correlation analysis. They never influence the objective value.
%
% AUTHOR:
%   Bahman Abbassi
%   University of Quebec (UQAT)
%   Email: bahman.abbassi@uqat.ca
%   GitHub: https://github.com/bahmanabbassi
%   MathWorks: https://www.mathworks.com/matlabcentral/profile/authors/31336389
%
% INPUTS:
%   Each argument is followed by the symbol used for it in the paper, so that
%   a run can be traced directly to Table 1. Ranges are those searched by BTO;
%   parameters marked "fixed" were held constant in the published experiments.
%
%   CWT_Input_Features_Matrix (double): Input grid to decompose, 2D, or a 3D
%                             stack when several input grids are supplied.
%   All_Data_Matrix (double): Additional grids carried alongside the selected
%                             kCWT maps into the extraction stage.
%   WSFR (double)            [sigma]     kCWT filtering ratio. Scales the
%                             support of the mother wavelet. Range {0 : 1}.
%   N_Angles (integer)       [N_theta]   Number of kCWT orientations, spread
%                             over 0 to 180 degrees. Range {12 : 72}.
%   orderx (integer)         [n]         Poisson derivative order in x. ordery
%                             is set to its complement below, so the pair
%                             (n, m) is either {1, 0} or {0, 1}.
%   Z (double)               [Z]         Upward continuation of the Poisson
%                             kernel, in grid cells. Range {1 : 5}.
%   w (double)               [w_bar]     Average step-filter width in pixels.
%                             Range {0.75*w_c : 2.5*w_c}, where w_c is 10
%                             percent of the smaller image dimension.
%   VSFW (double)            [upsilon]   Variability of the step-filter width.
%                             The local width follows Eq. (14). Range {0 : 1}.
%   NSFA (integer)           [N_phi]     Number of step-filter orientations.
%                             Range {12 : 72}.
%   SLC (double)             [xi]        Global confidence threshold, in
%                             percent. The high hysteresis threshold is the
%                             (100 - SLC)th percentile. Range {35 : 85}.
%   FDissimilarity (double)  [gamma]     Weight balancing correlation-based
%                             and edge-based dissimilarity in Eq. (10).
%                             Range {0 : 1}.
%   FSaliency (double)       [lambda]    Saliency percentile used to binarize
%                             candidate maps in Eq. (11). Range {0 : 100}.
%   N_Scales (integer)       [N_a]       Number of kCWT scales. Fixed at 1, so
%                             that scale jumps do not mix sources at different
%                             depths; depth control is left to Z.
%   Line_Res (double)        [R]         Resize factor applied before
%                             extraction. Every pixel-based width and
%                             tolerance below refers to this resized grid.
%                             Fixed at 2.
%   DR (integer)             [d]         Number of kCWT maps retained by the
%                             selection stage. Fixed at 3.
%   SDF (double)             [delta]     Dilation step between kCWT scales.
%                             Fixed at 1.
%   sigma2 (double)          [sigma_I]   Gaussian blur applied to each feature
%                             before step filtering. Fixed at 0.
%   tolerance_arcsec (double)[tau]       Spatial tolerance for the F-beta
%                             match, in arc-seconds. Diagnostic only.
%   beta (double)            [beta]      F-beta weight. Set to 0.2 in the
%                             paper, which favours precision over recall.
%                             Diagnostic only.
%
% OUTPUTS:
%   L_val (double):     Negated GRM, rounded to whole pixels. bayesopt
%                       minimizes this quantity, which maximizes the GRM.
%   N_CWT (integer):    Number of kCWT coefficient maps generated before
%                       selection, equal to N_Scales * N_Angles * (number of
%                       input grids).
%
% USAGE:
%   This function is normally called once per Bayesian iteration by the
%   BWTO2D app, which supplies the hyperparameters drawn by bayesopt. Calling
%   it directly requires the global grids listed below to be populated first;
%   the app fills them when the study area is polygonized and the data loaded.
%--------------------------------------------------------------------------



% Geographic context shared with the app and the functions called below.
global XI YI X_Pix Y_Pix in; % Coordinate meshgrids, pixel counts, survey mask
global pop_choice3;         % Mother wavelet: 'gaus' or Poisson
global YI_Real_Ratio;       % Latitude/longitude aspect ratio, used when cropping
global XI_line_Auto YI_line_Auto; % Coordinate grids after the Line_Res resize


if orderx == 1
    ordery = 0;
elseif orderx == 0
    ordery = 1;
end

% --- Stage 1: Poisson kCWT decomposition (Section 1.1) ---
% Mixed derivatives are symmetric over a quarter turn, so they only need to be
% sampled over 90 degrees; the first-order derivatives used in the paper cover
% the full 180 degrees of distinct orientations.
if orderx == ordery && orderx ~= 0
    betad = 90;
else
    betad = 180;
end

Scales = 1:SDF:(N_Scales*SDF);
if N_Angles > 0
    angle_step = betad / N_Angles;
    % Orientations are sampled on the half-open interval [0, betad), so that
    % the first and last angles are not duplicates of each other.
    Angless = 0 : angle_step : (betad - angle_step);
else
    Angless = 0; % Fall back to a single orientation
end
Angles = Angless * pi / 180;

if ndims(CWT_Input_Features_Matrix) == 2
    N_Fs = 1;
else
    szCWT = size(CWT_Input_Features_Matrix);
    N_Fs = szCWT(3);
end
N_CWT = N_Scales * N_Angles * N_Fs;

if ~SUPPRESS_WAITBARS
    h_cwt = waitbar(0.5,'Kernel CWT...', 'WindowStyle', 'modal', 'Name', 'CWT Computation');
    frames_cwt = java.awt.Frame.getFrames();
    if ~isempty(frames_cwt)
        frames_cwt(end).setAlwaysOnTop(1);
    end
else
    h_cwt = [];
end

% The app sets the mother wavelet; fall back to the Gaussian derivative if the
% function is called before that choice has been made.
if isempty(pop_choice3)
    pop_choice3 = 'gaus';
    disp("Warning: global 'pop_choice3' for CWT type was empty, defaulted to 'gaus'.");
end

% Poisson is the wavelet used throughout the paper. The Gaussian-derivative
% branch is retained for comparison runs.
if (strcmp(pop_choice3,'gaus'))
    Fe_All = cwt2D_DerGus_BTO(CWT_Input_Features_Matrix, Scales, Angles, orderx, ordery, WSFR);

    elseif (strcmp(pop_choice3,'derpoisson2d'))
    Fe_All = cwt2D_DerPoisson_BTO(CWT_Input_Features_Matrix,Scales,Angles,orderx,ordery,WSFR,Z);   
    
else
    if ~isempty(h_cwt) && ishandle(h_cwt), close(h_cwt); end
    error(['Unsupported pop_choice3: ', pop_choice3]);
end
if ~isempty(h_cwt) && ishandle(h_cwt), close(h_cwt); end
pause(0.01);

if ~SUPPRESS_WAITBARS
    h_save_cwt = waitbar(0.5,'Save Kernel CWT Results...', 'WindowStyle', 'modal', 'Name', 'Saving CWT');
    frames_save_cwt = java.awt.Frame.getFrames();
    if ~isempty(frames_save_cwt)
        frames_save_cwt(end).setAlwaysOnTop(1);
    end
else
    h_save_cwt = [];
end
[XI_siz, YI_siz, nn, mm, kk] = size(Fe_All);
% Result3D = reshape(Fe_All, XI_siz, YI_siz, nn*mm*kk);
Result3D = reshape(Fe_All, XI_siz, YI_siz, nn*mm, kk);

if ~isempty(h_save_cwt) && ishandle(h_save_cwt), close(h_save_cwt); end
pause(0.01);


% --- Stage 2: kCWT coefficient selection and fusion (Algorithm 1, Section 1.2) ---
Result3D_Size = size(Result3D, 3);
% bayesopt can hand DR over as a character string, so coerce it to a number.
if ischar(DR)
    DR_numeric = str2double(DR);
else
    DR_numeric = DR;
end

% Never ask for more maps than the decomposition actually produced.
if Result3D_Size >= DR_numeric
    DR2 = DR_numeric;
else
    DR2 = Result3D_Size;
end

if DR2 <= 0 % At least one map must be retained
    DR2 = 1;
end





            input_ndims = ndims(Result3D);
            image_count = 1; % One input grid unless a 4D stack was supplied

    if input_ndims == 2
        % A bare 2D array carries no coefficient maps to select from.
        Spectral_PCA_Features_Matrix(:, :, 1) = Result3D;
        close(h);
        return;

    elseif input_ndims == 3 % One input grid: rows x cols x coefficient maps
        SPCA_Features = CWTFeatureSelection(Result3D, DR2, FSaliency, FDissimilarity);
        
        [rows, cols, num_selected_features] = size(SPCA_Features);
        
        Spectral_PCA_Features_Matrix = zeros(rows, cols, num_selected_features);
        
        % Exact zeros are nudged off zero so that the masking step below can
        % use zero to mark nodes lying outside the survey polygon.
        SPCA_Features(SPCA_Features == 0) = 1e-12;
        
        % Restrict every retained map to the survey polygon. This is the
        % M(x,y) mask of Section 1.2; nodes outside it become NaN and are
        % excluded from the range adjustment performed by nDstrb2D.
        masked_features = bsxfun(@times, SPCA_Features, in);
        
        masked_features(masked_features == 0) = NaN;
        
        % nDstrb2D applies the operator L of Section 1.2 to each map.
        for k = 1:num_selected_features
            Spectral_PCA_Features_Matrix(:, :, k) = nDstrb2D(masked_features(:, :, k));
        end

    elseif input_ndims == 4 % Several input grids, each with its own map stack
        image_count = size(Result3D, 4);
        [rows, cols, ~] = size(Result3D(:,:,:,1)); 

        total_features = DR2 * image_count;
        Spectral_PCA_Features_Matrix = zeros(rows, cols, total_features);
        
        % Grids are handled in small batches to bound peak memory use.
        batch_size = min(4, image_count);
        feature_idx = 1;
        
        for batch_start = 1:batch_size:image_count
            batch_end = min(batch_start + batch_size - 1, image_count);
            current_batch_size = batch_end - batch_start + 1;
            
            % waitbar(batch_start / image_count, h, sprintf('Processing Images %d-%d of %d...', batch_start, batch_end, image_count));
            
            batch_data = Result3D(:, :, :, batch_start:batch_end);
            
            % Each grid is selected from independently, so that its own
            % variance ranking decides which orientations are retained.
            for img_idx = 1:current_batch_size
                current_image_volume = batch_data(:, :, :, img_idx);
                SPCA_Features_current_image = CWTFeatureSelection(current_image_volume, DR2, FSaliency, FDissimilarity);
                
                SPCA_Features_current_image(SPCA_Features_current_image == 0) = 1e-12;
                
                num_selected_features = size(SPCA_Features_current_image, 3);
                
                masked_features = bsxfun(@times, SPCA_Features_current_image, in);
                masked_features(masked_features == 0) = NaN;
                
                for k = 1:num_selected_features
                    Spectral_PCA_Features_Matrix(:, :, feature_idx) = nDstrb2D(masked_features(:, :, k));
                    feature_idx = feature_idx + 1;
                end
            end
        end

    else
        warning('Input data has unsupported number of dimensions (%d). Expected 2, 3, or 4.', input_ndims);
        close(h);
        return;
    end


% --- Stage 3: Curvilinear pattern extraction (Section 1.3) ---
% Each retained feature map is step filtered, thresholded, and cleaned
% independently; the resulting binary maps are fused further below.
if ~SUPPRESS_WAITBARS
    h_le = waitbar(0.66, 'Lineament Extraction...', 'WindowStyle', 'modal', 'Name', 'Lineament Extraction');
    frames_le = java.awt.Frame.getFrames();
    if ~isempty(frames_le)
        frames_le(end).setAlwaysOnTop(1);
    end
else
    h_le = [];
end

% Kept aside so it can be archived later, once this iteration is known to be
% the best one so far.
Spectral_PCA_Features_Matrix_to_store = Spectral_PCA_Features_Matrix;

% Append the original image I to the selected maps. This is the feature set
% F_i of Algorithm 1, and it is what the consensus intersection is taken over.
originalArrayNoNaNPages = cat(3, Spectral_PCA_Features_Matrix, All_Data_Matrix);
clear Spectral_PCA_Features_Matrix; % Free memory

% Drop any map that masking left entirely undefined.
if ndims(originalArrayNoNaNPages) == 3
    nanPageIndices = all(all(isnan(originalArrayNoNaNPages), 1), 2);
    originalArrayNoNaNPages(:,:,squeeze(nanPageIndices)) = [];
end

if isempty(originalArrayNoNaNPages) || all(isnan(originalArrayNoNaNPages(:)))
    disp('Warning: All feature maps are NaN or empty after masking/selection.');
    L_val = Inf;
    if ishandle(h_le), close(h_le); end
    return;
end

if ndims(originalArrayNoNaNPages) == 2
    Number_of_Features_used_for_Lineaments_Detection = 1;
    % Promote to 3D so the extraction loop below can index pages uniformly.
    temp_arr = originalArrayNoNaNPages;
    clear originalArrayNoNaNPages;
    originalArrayNoNaNPages(:,:,1) = temp_arr;
else
    Number_of_Features_used_for_Lineaments_Detection = size(originalArrayNoNaNPages, 3);
end

% Fall back to the image dimensions if the app did not supply pixel counts.
if isempty(X_Pix) || isempty(Y_Pix) || X_Pix == 0 || Y_Pix == 0
    disp("Warning: X_Pix or Y_Pix is not valid. Using image dimensions.");
    X_Pix = YI_siz; % meshgrid convention: columns span x
    Y_Pix = XI_siz; % rows span y
end

if Line_Res <=0
    disp("Warning: Line_Res is invalid. Defaulting to 256.");
    Line_Res = 1;
end

% Resolution factor R of Table 1. Every pixel width and tolerance from here on
% is expressed on the resized grid.
resize_factor = Line_Res;

% The coordinate grids are resized alongside the data so that extracted pixels
% can be mapped back to geographic positions.
if isempty(XI) || isempty(YI)
    disp("Error: Global XI or YI is empty. Cannot proceed with resizing coordinates.");
    L_val = Inf;
    if ishandle(h_le), close(h_le); end
    return;
end
XI_line_Auto = imresize(XI, resize_factor);
YI_line_Auto = imresize(YI, resize_factor);

% Inverse variance of each feature map, z-scored across maps. This is the
% z_var term of Eq. (14), which widens the step filter on smooth maps and
% narrows it on heterogeneous ones.
vari1 = zeros(Number_of_Features_used_for_Lineaments_Detection,1);
for ttt6_var = 1:Number_of_Features_used_for_Lineaments_Detection
    Grid0_var = originalArrayNoNaNPages(:,:,ttt6_var);
    Grid2_var = FilterB(Grid0_var, sigma2);
    Grid2_var(isnan(Grid2_var)) = 0;
    if var(double(Grid2_var(:))) == 0
        vari1(ttt6_var) = 1; % Flat map: avoid dividing by zero variance
    else
        vari1(ttt6_var) = 1/var(double(Grid2_var(:)));
    end
end
if length(vari1) > 1
    vari1_std = zscore(vari1);
else
    vari1_std = zeros(size(vari1)); % A single map has no spread to standardize
end

plotH0 = zeros(size(XI_line_Auto,1), size(XI_line_Auto,2), Number_of_Features_used_for_Lineaments_Detection);
plotH_colored_all = zeros(size(XI_line_Auto,1), size(XI_line_Auto,2), 3, Number_of_Features_used_for_Lineaments_Detection);  % Colour overlays for display
grm2_vector = zeros(Number_of_Features_used_for_Lineaments_Detection, 1);  % Adapted step-filter width per feature

% Orientations extracted from each feature map, pooled later for rose diagrams.
allOrientations = {};

for ttt6_le = 1:Number_of_Features_used_for_Lineaments_Detection
    Grid0_le = originalArrayNoNaNPages(:,:,ttt6_le);
    Grid2_le = FilterB(Grid0_le, sigma2);
    Grid2_le(isnan(Grid2_le)) = 0;

    % Local step-filter width, Eq. (14): w = w_bar + (upsilon * w_bar) * z_var.
    % Despite the name, grm2 is a filter width in pixels and is unrelated to
    % the Graph Representativeness Metric computed later in this function.
    current_grm = w; % w_bar, the average width drawn by bayesopt
    grm2 = round(current_grm + (VSFW * current_grm) * vari1_std(ttt6_le));
    if grm2 <= 1
        grm2 = 1; % The filter needs at least one pixel of width
    end
    grm2_vector(ttt6_le) = grm2;

    Grid_resized = imresize(Grid2_le, resize_factor);
    data1 = im2double(Grid_resized);

    % Step-filter orientations phi, evenly spaced over [0, pi).
    current_GSF_Angles = NSFA;
    Step_Filter_nAng = current_GSF_Angles;
    if Step_Filter_nAng > 0
        Step_Filter_step = pi / Step_Filter_nAng;
        Step_Filter_DTheta = 0:Step_Filter_step:pi-(Step_Filter_step);
    else
        Step_Filter_DTheta = 0; % Fall back to a single orientation
    end
    Step_Filter_Dbw = [2 4 6]; % Fixed set of step-filter band widths

    % Convolve with the zero-mean step filter over all orientations and band
    % widths, keeping the maximum response, Eqs. (13) and (15).
    Y_filtered = step_Filtering(data1, grm2, Step_Filter_DTheta, Step_Filter_Dbw, 2);

    % Hysteresis thresholding with region growing, giving the binary candidate
    % map B_i(x,y) of Section 1.3.
    [BW_detected, ~] = getFaultDetection(Y_filtered, data1, SLC);

    % Retain only components whose integrated filter response exceeds the
    % (100 - xi)th percentile, as described in Section 1.3.
    CC_detected = bwconncomp(BW_detected);
    if CC_detected.NumObjects > 0
        stats_detected = regionprops(CC_detected, Y_filtered, 'PixelValues');
        strengths_detected = cellfun(@(x) sum(x(:)), {stats_detected.PixelValues});

        pct_cutoff = 100 - SLC;
        if isempty(strengths_detected)
            th_strength = 0;
        else
            th_strength = prctile(strengths_detected, pct_cutoff);
        end
        keep_indices = find(strengths_detected >= th_strength);
        BW_filtered_strength = ismember(labelmatrix(CC_detected), keep_indices);
    else
        BW_filtered_strength = false(size(BW_detected));
    end

    % Segment orientations for the rose diagrams, taken after component
    % filtering so that they describe the patterns actually reported.
    [orientations360] = createRoseDiagrams(BW_filtered_strength);
    allOrientations{ttt6_le} = orientations360;

    % The colour renderer is also the route back to a clean binary map: it
    % draws each labelled component, and the drawing is re-binarized below.
    if CC_detected.NumObjects > 0 && ~isempty(keep_indices)
        Map_for_plot = bwlabel(BW_filtered_strength, 8);
        Labels_for_plot = unique(Map_for_plot(Map_for_plot > 0))';

        if isempty(Labels_for_plot) % Nothing survived the strength filter
            plotH_colored = zeros(size(data1,1), size(data1,2), 3);
        else
            plotH_colored = plotNewColorMap0_(Y_filtered, zeros(size(data1)), Map_for_plot, Labels_for_plot, ...
                'Detected Lineaments', YI_line_Auto(:), XI_line_Auto(:));
        end
    else
        plotH_colored = zeros(size(data1,1), size(data1,2), 3); % No components to draw
    end

    plotH_colored_all(:,:,:,ttt6_le) = plotH_colored;

    plotH00_gray = (plotH_colored(:,:,1) + plotH_colored(:,:,2) + plotH_colored(:,:,3))/3;
    plotH00_bin = imbinarize(plotH00_gray);

    CC_final_filter = bwconncomp(plotH00_bin);
    if CC_final_filter.NumObjects > 0
        componentStats_final = regionprops(CC_final_filter, 'Area');
        % Discard components below 50 pixels, the fixed size floor of
        % Section 1.3. Short fragments are removed here rather than being
        % allowed to dilute the GRM.
        validComponents_final = find([componentStats_final.Area] >= 50);
        plotH00_final = ismember(labelmatrix(CC_final_filter), validComponents_final);
    else
        plotH00_final = false(size(plotH00_bin));
    end

    % Stored inverted, so that from here on a pattern pixel is false and
    % background is true. The fusion below relies on this convention.
    plotH0(:,:,ttt6_le) = imcomplement(plotH00_final);
end

% Pool the per-feature orientations for the rose diagrams drawn by the app.
global Orient
if ~isempty(allOrientations)
    Orient = vertcat(allOrientations{:});
else
    Orient = [];
end

% Fuse the per-feature maps into the consensus network B(x,y) of Section 1.3.
% Because plotH0 is inverted (pattern = false, background = true), OR-ing the
% pages marks a pixel as background as soon as any single map called it
% background. A pixel therefore survives only where every feature map, the
% original image included, detected a pattern: this OR is the spatial
% intersection that the GRM is evaluated on, not a union.
if Number_of_Features_used_for_Lineaments_Detection > 0
    plotH1_stacked = false(size(plotH0,1), size(plotH0,2));
    for n_stack = 1:Number_of_Features_used_for_Lineaments_Detection
        plotH1_stacked = plotH1_stacked | plotH0(:,:,n_stack);
    end
else
    plotH1_stacked = false(size(XI_line_Auto,1), size(XI_line_Auto,2)); % No features
end

% Aspect ratio of the geographic grid, used to keep the border strip square
% on the ground rather than in pixels.
if isempty(YI_Real_Ratio) || YI_Real_Ratio <= 0
    YI_Real_Ratio = 1.0;
end

% Suppress the border artefacts left by the directional convolution and by the
% unpadded FFT, by resetting a strip along each of the four edges to
% background. The strip is a fixed fraction of the image dimension and is the
% edge crop referred to in Section 1.3.
plotH1_rgb_cropped = im2double(plotH1_stacked);
cropPixels1 = round(0.025 * YI_Real_Ratio * size(plotH1_stacked,1));
cropPixels2 = round(0.025 * size(plotH1_stacked,2));

% Never let the two strips meet in the middle of a small image.
cropPixels1 = min(cropPixels1, floor(size(plotH1_rgb_cropped,1)/2)-1);
cropPixels2 = min(cropPixels2, floor(size(plotH1_rgb_cropped,2)/2)-1);
if cropPixels1 < 0, cropPixels1 = 0; end
if cropPixels2 < 0, cropPixels2 = 0; end

% Value 1.0 is background in this convention, 0.0 is a pattern pixel.
if cropPixels1 > 0
    plotH1_rgb_cropped(1:cropPixels1, :) = 1.0;
    plotH1_rgb_cropped(end-cropPixels1+1:end, :) = 1.0;
end
if cropPixels2 > 0
    plotH1_rgb_cropped(:, 1:cropPixels2) = 1.0;
    plotH1_rgb_cropped(:, end-cropPixels2+1:end) = 1.0;
end

if ~isempty(h_le) && ishandle(h_le), close(h_le); end
pause(0.01);

% --- Stage 4: Segment-End Nodes Graph and GRM (Algorithm 2, Section 1.3) ---
% The consensus network is decomposed into connected segments, each segment
% becomes a graph edge weighted by its pixel count, and the Graph
% Representativeness Metric of Eq. (18) is accumulated over the segments. The
% negated metric is returned as the objective value for bayesopt.
if ~SUPPRESS_WAITBARS
    h_graph = waitbar(0.5, 'Building Graph & Computing Representativeness...', 'WindowStyle', 'modal', 'Name', 'Graph Measure');
    frames_graph = java.awt.Frame.getFrames();
    if ~isempty(frames_graph)
        frames_graph(end).setAlwaysOnTop(1);
    end
else
    h_graph = [];
end

% Pattern pixels are 0 and background is 1 in this map, so it is complemented
% wherever the patterns themselves need to be addressed.
lineamentBinary = imbinarize(plotH1_rgb_cropped);

% Local pattern density in a 3-by-3 neighbourhood. This is not used by the
% objective; it is archived and shown by the app as a density overlay.
grayImage_density = lineamentBinary;
windowSize_density = 3;
filterKernel_density = ones(windowSize_density, windowSize_density);
densityMap_final = conv2(double(grayImage_density), filterKernel_density, 'same');
densityMap_final = densityMap_final / (windowSize_density^2);
densityMap_final = imcomplement(densityMap_final);

% Connected-component labelling of the consensus network gives the N segments
% S_P of Eq. (16).
CC_segments = bwconncomp(imcomplement(lineamentBinary));
L_segments_pixels = CC_segments.PixelIdxList;

Segments = struct('startCoord', {}, 'endCoord', {}, 'pixelList', {});
if CC_segments.NumObjects > 0
    for sIdx = 1:length(L_segments_pixels)
        pixList = L_segments_pixels{sIdx};
        if numel(pixList) < 2 % A single pixel has no extent to describe
            continue;
        end
        [rs, cs] = ind2sub(size(lineamentBinary), pixList);

        % Start and end nodes s_P and e_P of Eq. (17), taken as the extreme
        % pixels of the segment along the row axis. These nodes define the
        % graph vertices; the GRM itself depends only on the segment weights
        % and separations computed below.
        [~, min_idx] = min(rs);
        [~, max_idx] = max(rs);

        seg_struct.startCoord = [rs(min_idx(1)), cs(min_idx(1))]; % First one wins if tied
        seg_struct.endCoord   = [rs(max_idx(1)), cs(max_idx(1))];
        seg_struct.pixelList  = pixList;
        Segments = [Segments; seg_struct];
    end
end

ME_value = 0;
N_graph_segments = numel(Segments);

if N_graph_segments == 0
    ME_value = 0; % An empty network scores zero
else
    % Edge weights w_P of Eq. (17): the length of each segment in pixels.
    W_vals = zeros(N_graph_segments,1);
    total_pixels_in_segments = 0;
    for i = 1:N_graph_segments
        W_vals(i) = numel(Segments(i).pixelList);
        total_pixels_in_segments = total_pixels_in_segments + W_vals(i);
    end

    % Pairwise similarities sim(S_P, S_Q) = 1 / (1 + d_PQ), Eq. (19), where
    % d_PQ is the separation between the mean pixel positions of the two
    % segments. Only the upper triangle is computed, since sim is symmetric.
    simMatrix = zeros(N_graph_segments, N_graph_segments);
    if N_graph_segments > 1
        for i = 1:N_graph_segments
            for j = i+1:N_graph_segments
                centroid_i = mean(ind2sub(size(lineamentBinary), Segments(i).pixelList),1);
                centroid_j = mean(ind2sub(size(lineamentBinary), Segments(j).pixelList),1);
                dist_centroids = norm(centroid_i - centroid_j);
                ST_val = 1 / (1 + dist_centroids);
                simMatrix(i,j) = ST_val;
                simMatrix(j,i) = ST_val;
            end
        end
    end

    % Accumulate GRM = sum over P of w_P * (1 - min over Q of sim(S_P, S_Q)),
    % Eq. (18). Because sim decreases with distance, the minimum picks the
    % most distant segment, so the bracket is close to unity whenever a
    % segment has a far counterpart. The score is therefore dominated by the
    % total length of the retained traces, as described in Section 1.3.
    for segIndex = 1:N_graph_segments
        W_val_current = W_vals(segIndex);

        if N_graph_segments == 1
            hatS_T = 0; % Nothing to compare a lone segment against
        else
            rowSimilarities = simMatrix(segIndex,:);
            rowSimilarities(segIndex) = Inf; % Set self-similarity aside before taking the minimum
            hatS_T = min(rowSimilarities);
            if isinf(hatS_T)
                hatS_T = 0;
            end
        end

        ME_value = ME_value + W_val_current * (1 - hatS_T);
    end
end

if ~isempty(h_graph) && ishandle(h_graph), close(h_graph); end
pause(0.01);

% Objective F(h) = -GRM, Eq. (20). Rounded because the GRM is a pixel count.
zeta = 1;
L_val = round(-zeta * ME_value);

if isnan(L_val) || isinf(L_val)
    L_val = Inf; % Reject hyperparameter sets that produced no usable network
end

% --- Supervised diagnostics (Section 1.4) ---
% These metrics are recorded once per iteration and accumulated across the run
% so that the GRM can be correlated against them afterwards, as in Figures 6,
% 8 and 9. They are computed only when ground truth has been loaded, and they
% never enter the objective value returned above.
global All_Trg_Matrix BHO_GroundTruthMetrics
global XI_line_Auto YI_line_Auto

fbeta_score = [];
structural_metrics = [];

% One array per metric, appended to on every iteration.
if ~exist('BHO_GroundTruthMetrics', 'var') || isempty(BHO_GroundTruthMetrics)
    BHO_GroundTruthMetrics = struct();
    BHO_GroundTruthMetrics.GRM_values = [];
    BHO_GroundTruthMetrics.fbeta_scores = [];
    BHO_GroundTruthMetrics.p21_ratios = [];
    BHO_GroundTruthMetrics.length_distribution_similarities = [];
    BHO_GroundTruthMetrics.angular_correlations = [];
    BHO_GroundTruthMetrics.hellinger_similarities = [];
    BHO_GroundTruthMetrics.js_divergences = [];
    BHO_GroundTruthMetrics.is_best_so_far = [];  % Flags the iterations that set a new maximum
end

% Ground truth and coordinate grids are both optional. When either is missing
% the metrics are stored as NaN, which keeps every array the same length as
% the GRM history and lets the optimization continue unaffected.
try
    has_gt = false;
    has_coords = false;
    
    try
        if exist('All_Trg_Matrix', 'var')
            temp_gt = All_Trg_Matrix;
            if ~isempty(temp_gt) && (isnumeric(temp_gt) || islogical(temp_gt))
                has_gt = true;
                real_faults_test = temp_gt;
            end
        end
    catch
        has_gt = false; % No ground truth loaded
    end
    
    if exist('XI_line_Auto', 'var') && ~isempty(XI_line_Auto) && ...
       exist('YI_line_Auto', 'var') && ~isempty(YI_line_Auto)
        has_coords = true;
        XI_test = XI_line_Auto;
        YI_test = YI_line_Auto;
    end
    
    if has_gt && has_coords
        
        % Back to the convention where a pattern pixel is true.
        detected_faults = imcomplement(plotH1_rgb_cropped);
        detected_faults = imbinarize(detected_faults);
        
        % The reference is resampled onto the detection grid when the two
        % differ, which happens whenever Line_Res is not 1.
        real_faults = real_faults_test;
        if size(real_faults, 1) ~= size(detected_faults, 1) || size(real_faults, 2) ~= size(detected_faults, 2)
            real_faults = imresize(real_faults, size(detected_faults));
        end
        real_faults = imbinarize(real_faults);
        
        XI_metrics = XI_line_Auto;
        YI_metrics = YI_line_Auto;
        
        % F-beta of Eq. (22). Matching is bidirectional, so precision and
        % recall are both evaluated within the tolerance tau.
        use_bidirectional = true;
        use_length_weighted = false;
        [fbeta_score, ~, ~, ~, ~, ~] = calculateFbetaScore(...
            real_faults, detected_faults, XI_metrics, YI_metrics, ...
            beta, tolerance_arcsec, use_bidirectional, use_length_weighted, false);
        
        % R_P21 of Eq. (23) plus the orientation metrics HS and JSD of
        % Eq. (24). The final argument silences printing during the run.
        structural_metrics = calculateStructuralMetrics(real_faults, detected_faults, XI_metrics, YI_metrics, false);
        
    else
        fbeta_score = NaN;
        structural_metrics = struct();
        structural_metrics.P21_ratio = NaN;
        structural_metrics.length_distribution_similarity = NaN;
        structural_metrics.angular_correlation = NaN;
        structural_metrics.hellinger_similarity = NaN;
        structural_metrics.js_divergence = NaN;
    end
    
catch ME
    % A failure here must not abort the optimization, so the iteration is
    % recorded with NaN metrics and the search continues.
    fbeta_score = NaN;
    structural_metrics = struct();
    structural_metrics.P21_ratio = NaN;
    structural_metrics.length_distribution_similarity = NaN;
    structural_metrics.angular_correlation = NaN;
    structural_metrics.hellinger_similarity = NaN;
    structural_metrics.js_divergence = NaN;
end

% The history records the GRM itself rather than the negated objective, since
% that is the quantity plotted and correlated in the paper.
if isnan(L_val) || isinf(L_val)
    actual_GRM = NaN;
else
    actual_GRM = round(-L_val);
end

% Fill in any field the metric functions did not return, so that every history
% array grows by exactly one element per iteration.
if ~isfield(structural_metrics, 'P21_ratio')
    structural_metrics.P21_ratio = NaN;
end
if ~isfield(structural_metrics, 'length_distribution_similarity')
    structural_metrics.length_distribution_similarity = NaN;
end
if ~isfield(structural_metrics, 'angular_correlation')
    structural_metrics.angular_correlation = NaN;
end
if ~isfield(structural_metrics, 'hellinger_similarity')
    structural_metrics.hellinger_similarity = NaN;
end
if ~isfield(structural_metrics, 'js_divergence')
    structural_metrics.js_divergence = NaN;
end

% Append this iteration to the history. p21_ratios holds R_P21 of Eq. (23).
BHO_GroundTruthMetrics.GRM_values = [BHO_GroundTruthMetrics.GRM_values; actual_GRM];
BHO_GroundTruthMetrics.fbeta_scores = [BHO_GroundTruthMetrics.fbeta_scores; fbeta_score];
BHO_GroundTruthMetrics.p21_ratios = [BHO_GroundTruthMetrics.p21_ratios; structural_metrics.P21_ratio];
BHO_GroundTruthMetrics.length_distribution_similarities = [BHO_GroundTruthMetrics.length_distribution_similarities; structural_metrics.length_distribution_similarity];

% Orientation metrics of Eq. (24).
if isfield(structural_metrics, 'angular_correlation')
    BHO_GroundTruthMetrics.angular_correlations = [BHO_GroundTruthMetrics.angular_correlations; structural_metrics.angular_correlation];
else
    BHO_GroundTruthMetrics.angular_correlations = [BHO_GroundTruthMetrics.angular_correlations; NaN];
end

if isfield(structural_metrics, 'hellinger_similarity')
    BHO_GroundTruthMetrics.hellinger_similarities = [BHO_GroundTruthMetrics.hellinger_similarities; structural_metrics.hellinger_similarity];
else
    BHO_GroundTruthMetrics.hellinger_similarities = [BHO_GroundTruthMetrics.hellinger_similarities; NaN];
end

if isfield(structural_metrics, 'js_divergence')
    BHO_GroundTruthMetrics.js_divergences = [BHO_GroundTruthMetrics.js_divergences; structural_metrics.js_divergence];
else
    BHO_GroundTruthMetrics.js_divergences = [BHO_GroundTruthMetrics.js_divergences; NaN];
end

% --- Archive of the best iteration so far ---
% Only the best-scoring iteration keeps its full outputs, which is what the app
% displays and exports at the end of a run. Every new maximum also appends an
% entry to the best-so-far history behind the progression gallery.
global BHO_BestOutputs
global BHO_BestSoFarHistory
if ~exist('BHO_BestOutputs', 'var') || isempty(BHO_BestOutputs)
    BHO_BestOutputs = struct();
    BHO_BestOutputs.best_L_val = Inf;  % Any real objective value will beat this
    BHO_BestOutputs.has_outputs = false;
end

if ~exist('BHO_BestSoFarHistory', 'var') || isempty(BHO_BestSoFarHistory)
    BHO_BestSoFarHistory = struct('iteration', {}, 'hyperparameters', {}, 'fbeta_score', {}, ...
        'structural_metrics', {}, 'lineaments_vectors', {}, 'XI_line_Auto', {}, ...
        'YI_line_Auto', {}, 'L_val', {}, 'densityMap', {}, 'rasterLineaments', {});
end

current_iteration = length(BHO_GroundTruthMetrics.is_best_so_far) + 1;

% bayesopt minimizes, so a smaller L_val means a larger GRM.
is_current_best = (L_val < BHO_BestOutputs.best_L_val);
if is_current_best
    BHO_BestOutputs.best_L_val = L_val;
    BHO_BestOutputs.plotH1_rgb_cropped = plotH1_rgb_cropped;
    BHO_BestOutputs.plotH0 = plotH0;
    BHO_BestOutputs.XI_line_Auto = XI_line_Auto;
    BHO_BestOutputs.YI_line_Auto = YI_line_Auto;
    BHO_BestOutputs.Number_of_Features_used_for_Lineaments_Detection = Number_of_Features_used_for_Lineaments_Detection;
    BHO_BestOutputs.grm2_vector = grm2_vector;  % Adapted filter width per feature
    BHO_BestOutputs.Result3D_Auto = Result3D;  % Full kCWT coefficient stack
    BHO_BestOutputs.Spectral_PCA_Features_Matrix_Auto = Spectral_PCA_Features_Matrix_to_store;  % Maps kept by selection
    BHO_BestOutputs.plotH_colored_all = plotH_colored_all;  % Colour overlays, shaded by response strength
    BHO_BestOutputs.densityMap_Auto = densityMap_final;  % Density overlay
    
    if ~isempty(fbeta_score) && ~isempty(structural_metrics)
        BHO_BestOutputs.fbeta_score = fbeta_score;
        BHO_BestOutputs.structural_metrics = structural_metrics;
        BHO_BestOutputs.has_ground_truth = true;
    else
        BHO_BestOutputs.has_ground_truth = false;
    end
    
    BHO_BestOutputs.has_outputs = true;
    
    % --- Vectorize the extracted patterns for export ---
    % Each feature map is thinned to single-pixel width and traced, then the
    % pixel indices are mapped back onto the geographic grid.
    Shape_Auto_iter = struct('Geometry', {}, 'X', {}, 'Y', {}, 'Name', {});
    
    for n = 1:Number_of_Features_used_for_Lineaments_Detection
        BW = plotH0(:,:,n);
        
        % Undo the inverted storage convention: patterns become true.
        BW = imcomplement(BW);
        
        BW = bwmorph(BW, 'thin', Inf);
        
        [B,~] = bwboundaries(BW, 'noholes');
        
        % Regular coordinate axes spanning the resized grid.
        xVec = linspace(min(XI_line_Auto(:)), max(XI_line_Auto(:)), size(BW,2));
        yVec = linspace(min(YI_line_Auto(:)), max(YI_line_Auto(:)), size(BW,1));
        
        for k = 1:length(B)
            boundary = B{k};
            rowIdx = boundary(:,1);  % Row index maps to latitude
            colIdx = boundary(:,2);  % Column index maps to longitude
            
            xCoords = xVec(colIdx);
            yCoords = yVec(rowIdx);
            
            currentShape = struct('Geometry', 'Line', 'X', xCoords', 'Y', yCoords', ...
                'Name', ['Fault_Feature', num2str(n), '_', num2str(k)]);
            Shape_Auto_iter = [Shape_Auto_iter; currentShape];
        end
    end
    
    % Hyperparameters of this iteration, kept with its outputs so that the
    % reported configuration can be reproduced. See Table 1 for the symbols.
    hyperparams = struct('WSFR', WSFR, 'NAngles', N_Angles, 'orderx', orderx, ...
        'Z', Z, 'w', w, 'VSFW', VSFW, 'NSFA', NSFA, 'SLC', SLC, ...
        'FDissimilarity', FDissimilarity, 'FSaliency', FSaliency);
    
    % Second half of the dual-fusion strategy of Section 1.3. Scoring uses the
    % intersection built earlier; the network shown in the results figures is
    % the union, which is what this raster holds. Under the inverted storage
    % convention, AND-ing the pages keeps a pixel as background only where
    % every feature agreed it was background, so a pixel detected by any single
    % feature survives.
    plotH1_display = true(size(plotH0,1), size(plotH0,2));
    for n_display = 1:Number_of_Features_used_for_Lineaments_Detection
        plotH1_display = plotH1_display & plotH0(:,:,n_display);
    end
    % Same edge crop as the consensus map, so the two remain comparable.
    plotH1_display_cropped = im2double(plotH1_display);
    if cropPixels1 > 0
        plotH1_display_cropped(1:cropPixels1, :) = 1.0;
        plotH1_display_cropped(end-cropPixels1+1:end, :) = 1.0;
    end
    if cropPixels2 > 0
        plotH1_display_cropped(:, 1:cropPixels2) = 1.0;
        plotH1_display_cropped(:, end-cropPixels2+1:end) = 1.0;
    end
    
    % The history stores the union raster, so that it matches the exported
    % vector patterns rather than the sparser consensus map.
    history_entry = struct('iteration', current_iteration, ...
        'hyperparameters', hyperparams, ...
        'fbeta_score', fbeta_score, ...
        'structural_metrics', structural_metrics, ...
        'lineaments_vectors', Shape_Auto_iter, ...
        'XI_line_Auto', XI_line_Auto, ...
        'YI_line_Auto', YI_line_Auto, ...
        'L_val', L_val, ...
        'densityMap', densityMap_final, ...
        'rasterLineaments', plotH1_display_cropped);
    
    BHO_BestSoFarHistory = [BHO_BestSoFarHistory; history_entry];
end

BHO_GroundTruthMetrics.is_best_so_far = [BHO_GroundTruthMetrics.is_best_so_far; is_current_best];

%% Live progress display
% One window is reused across the whole run, showing the network extracted by
% the current iteration next to the GRM against F-beta trajectory of Figure 6b.
persistent h_live_fig h_ax_lineaments h_ax_scatter h_checkbox_trajectory h_trajectory_line

if isempty(h_live_fig) || ~ishandle(h_live_fig)
    h_live_fig = figure('Name', 'BTO Live Progress', 'NumberTitle', 'off');
    set(h_live_fig, 'Units', 'normalized', 'OuterPosition', [0 0 1 1]);
    try
        set(h_live_fig, 'WindowState', 'maximized');
    catch
        % Fallback for older MATLAB versions
    end
    
    % Create subplots with space for checkbox
    h_ax_lineaments = subplot(1, 2, 1);
    h_ax_scatter = subplot(1, 2, 2);
    
    % Add checkbox to toggle trajectory lines (default: ON)
    h_checkbox_trajectory = uicontrol(h_live_fig, 'Style', 'checkbox', ...
        'String', 'Show Trajectory', ...
        'Value', 1, ...  % Default: show trajectory
        'Units', 'normalized', ...
        'Position', [0.75, 0.02, 0.12, 0.04], ...
        'FontSize', 10, ...
        'BackgroundColor', get(h_live_fig, 'Color'), ...
        'Tag', 'TrajectoryCheckbox');
    
    % Set callback to toggle trajectory line visibility
    set(h_checkbox_trajectory, 'Callback', @(src,~) toggleTrajectoryLine(src));
    
    % Initialize trajectory line handle
    h_trajectory_line = [];
end

% Make sure figure is visible and brought to front
figure(h_live_fig);

% Get trajectory checkbox state (default to true if checkbox doesn't exist)
show_trajectory = true;
if ~isempty(h_checkbox_trajectory) && ishandle(h_checkbox_trajectory)
    show_trajectory = get(h_checkbox_trajectory, 'Value') == 1;
end

% --- Left subplot: Current iteration lineaments ---
subplot(h_ax_lineaments);
cla(h_ax_lineaments);
hold(h_ax_lineaments, 'on');

% Convert raster to vector lineaments for better display
% (same approach as used in BHO Best So Far display)
for n_feat = 1:size(plotH0, 3)
    BW_feat = plotH0(:,:,n_feat);
    BW_feat = imcomplement(BW_feat);  % Invert so lines are 1, background is 0
    BW_feat = bwmorph(BW_feat, 'thin', Inf);  % Skeletonize
    [B_feat, ~] = bwboundaries(BW_feat, 'noholes');
    
    % Get coordinate vectors
    xVec_feat = linspace(min(XI_line_Auto(:)), max(XI_line_Auto(:)), size(BW_feat, 2));
    yVec_feat = linspace(min(YI_line_Auto(:)), max(YI_line_Auto(:)), size(BW_feat, 1));
    
    % Plot each boundary as a line
    for k_feat = 1:length(B_feat)
        boundary_feat = B_feat{k_feat};
        if size(boundary_feat, 1) > 2  % Only plot if more than 2 points
            rowIdx_feat = boundary_feat(:, 1);
            colIdx_feat = boundary_feat(:, 2);
            xCoords_feat = xVec_feat(colIdx_feat);
            yCoords_feat = yVec_feat(rowIdx_feat);
            plot(h_ax_lineaments, xCoords_feat, yCoords_feat, 'Color', [0.2 0.6 0.8], 'LineWidth', 1.2);
        end
    end
end

hold(h_ax_lineaments, 'off');
set(h_ax_lineaments, 'YDir', 'normal');
axis(h_ax_lineaments, 'tight');
% Apply YI_Real_Ratio for correct aspect ratio
if exist('YI_Real_Ratio', 'var') && ~isempty(YI_Real_Ratio) && YI_Real_Ratio > 0
    daspect(h_ax_lineaments, [YI_Real_Ratio 1 1]);
else
    axis(h_ax_lineaments, 'equal');
end
xlabel(h_ax_lineaments, 'Longitude', 'FontSize', 11);
ylabel(h_ax_lineaments, 'Latitude', 'FontSize', 11);
box(h_ax_lineaments, 'on');

% Title with current metrics
if ~isempty(fbeta_score) && ~isnan(fbeta_score)
    title(h_ax_lineaments, sprintf('Iteration %d: GRM = %d, F-Beta = %.4f', ...
        current_iteration, actual_GRM, fbeta_score), 'FontSize', 12);
else
    title(h_ax_lineaments, sprintf('Iteration %d: GRM = %d', ...
        current_iteration, actual_GRM), 'FontSize', 12);
end

% Mark if this is best so far
if is_current_best
    text(h_ax_lineaments, 0.02, 0.98, 'BEST SO FAR', 'Units', 'normalized', ...
        'FontSize', 12, 'FontWeight', 'bold', 'Color', [0 0.6 0], ...
        'VerticalAlignment', 'top', 'BackgroundColor', [0.9 1 0.9]);
end

% --- Right subplot: GRM vs F-beta scatter plot with trajectory ---
axes(h_ax_scatter);  % Make sure we're on the right axes
cla(h_ax_scatter, 'reset');  % Full reset of axes

% Get ALL data points
all_grm = BHO_GroundTruthMetrics.GRM_values(:);
all_fbeta = BHO_GroundTruthMetrics.fbeta_scores(:);
all_is_best = BHO_GroundTruthMetrics.is_best_so_far(:);
n_total = length(all_grm);

% Get valid data points (non-NaN F-beta scores and GRM values)
valid_mask = ~isnan(all_fbeta) & ~isnan(all_grm);
n_valid = sum(valid_mask);

if n_valid > 0
    hold(h_ax_scatter, 'on');
    
    % Draw trajectory line connecting iterations in ORDER (iteration 1 -> 2 -> 3 -> ...)
    traj_grm = [];
    traj_fbeta = [];
    for iter = 1:n_total
        if valid_mask(iter)
            traj_grm = [traj_grm; all_grm(iter)];
            traj_fbeta = [traj_fbeta; all_fbeta(iter)];
        end
    end
    if length(traj_grm) >= 2
        h_trajectory_line = plot(h_ax_scatter, traj_grm, traj_fbeta, '-', ...
            'Color', [0.5 0.5 0.5], 'LineWidth', 2, 'Tag', 'TrajectoryLine');
        % Set initial visibility based on checkbox
        if show_trajectory
            set(h_trajectory_line, 'Visible', 'on');
        else
            set(h_trajectory_line, 'Visible', 'off');
        end
    end
    
    % Plot each point with iteration number inside
    for iter = 1:n_total
        if valid_mask(iter)
            grm_pt = all_grm(iter);
            fbeta_pt = all_fbeta(iter);
            
            % Determine color based on best-so-far status
            if iter <= length(all_is_best) && all_is_best(iter)
                % Best so far - orange
                face_color = [1.0 0.5 0.0];
                edge_color = [0.8 0.3 0.0];
                marker_size = 500;
                text_color = 'k';
            else
                % Discarded - gray
                face_color = [0.7 0.7 0.7];
                edge_color = [0.5 0.5 0.5];
                marker_size = 400;
                text_color = 'k';
            end
            
            % Highlight current iteration with green
            if iter == current_iteration
                face_color = [0.2 0.9 0.2];
                edge_color = [0.0 0.6 0.0];
                marker_size = 600;
                text_color = 'k';
            end
            
            % Draw filled circle
            scatter(h_ax_scatter, grm_pt, fbeta_pt, marker_size, 'o', ...
                'filled', 'MarkerFaceColor', face_color, 'MarkerEdgeColor', edge_color, 'LineWidth', 2);
            
            % Add iteration number inside circle (black text for visibility)
            text(h_ax_scatter, grm_pt, fbeta_pt, num2str(iter), ...
                'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                'FontSize', 10, 'FontWeight', 'bold', 'Color', text_color);
        end
    end
    
    hold(h_ax_scatter, 'off');
    
    % Calculate correlation if enough points
    valid_grm = all_grm(valid_mask);
    valid_fbeta = all_fbeta(valid_mask);
    if n_valid >= 2
        r = corrcoef(valid_grm, valid_fbeta);
        r_val = r(1,2);
        title(h_ax_scatter, sprintf('BTO Trajectory (r = %.3f)', r_val), 'FontSize', 12, 'FontWeight', 'bold');
    else
        title(h_ax_scatter, 'BTO Trajectory', 'FontSize', 12, 'FontWeight', 'bold');
    end
    
    xlabel(h_ax_scatter, 'GRM', 'FontSize', 11);
    ylabel(h_ax_scatter, 'F-Beta Score', 'FontSize', 11);
    grid(h_ax_scatter, 'on');
    set(h_ax_scatter, 'FontSize', 10);
    
else
    % No valid F-beta scores yet
    text(h_ax_scatter, 0.5, 0.5, 'Waiting for ground truth metrics...', ...
        'HorizontalAlignment', 'center', 'FontSize', 12, 'Units', 'normalized');
    title(h_ax_scatter, 'BTO Trajectory', 'FontSize', 12, 'FontWeight', 'bold');
    xlabel(h_ax_scatter, 'GRM', 'FontSize', 11);
    ylabel(h_ax_scatter, 'F-Beta Score', 'FontSize', 11);
end

% Update figure
drawnow;

% fprintf('Objective L_val: %f, N_CWT: %d\n', L_val, N_CWT);
end

%% Local function: Toggle trajectory line visibility
function toggleTrajectoryLine(src)
    % Find the trajectory line in the current figure by its tag
    h_line = findobj(gcf, 'Tag', 'TrajectoryLine');
    if ~isempty(h_line) && ishandle(h_line)
        if src.Value == 1
            set(h_line, 'Visible', 'on');
        else
            set(h_line, 'Visible', 'off');
        end
    end
end