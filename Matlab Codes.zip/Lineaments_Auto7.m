function [L_val, N_CWT] = Lineaments_Auto7(CWT_Input_Features_Matrix, All_Data_Matrix, WSFR...
    , N_Angles, orderx, Z, w, VSFW, NSFA, SLC, FDissimilarity, FSaliency, ...
    N_Scales, Line_Res, DR, SDF, sigma2, tolerance_arcsec, beta)
warning('off','all');

% Suppress waitbars during BTO optimization (they interrupt the live progress display)
global SUPPRESS_WAITBARS;
if isempty(SUPPRESS_WAITBARS)
    SUPPRESS_WAITBARS = true;  % Default: suppress waitbars
end
%--------------------------------------------------------------------------
% FUNCTION: Lineaments_Auto7
%
% PURPOSE:
%   Automates the detection of geological lineaments from geophysical or
%   remote sensing data using a multi-stage process. The function is
%   designed to be an objective function for Bayesian optimization, where
%   it evaluates a set of hyperparameters and returns a score (`L_val`)
%   representing the quality of the detected lineaments.
%
%   The process involves four main stages:
%   1.  **CWT Feature Generation**: Applies a 2D Continuous Wavelet Transform
%       to generate feature maps at multiple scales and angles.
%   2.  **Feature Selection**: Reduces the dimensionality of the CWT features
%       using a custom selection method based on saliency and dissimilarity.
%   3.  **Lineament Extraction**: Identifies lineament segments from the
%       selected feature maps using filtering and morphological operations.
%   4.  **Graph Representativeness**: Constructs a graph from the extracted
%       lineaments and computes a "representativeness" score, which serves
%       as the final objective value for optimization.
%
% AUTHOR:
%   Bahman Abbassi
%   University of Quebec (UQAT)
%   Email: bahman.abbassi@uqat.ca
%   GitHub: https://github.com/bahmanabbassi
%   MathWorks: https://www.mathworks.com/matlabcentral/profile/authors/31336389
%
% INPUTS:
%   CWT_Input_Features_Matrix (double): A 2D or 3D matrix of input data for CWT.
%   All_Data_Matrix (double): A 3D matrix of additional data to be combined
%                             with CWT features before lineament extraction.
%   WSFR (double):      Wavelet support scaling factor for CWT.
%   N_Angles (integer): Number of CWT angles to compute.
%   orderx (integer):   Derivative order in the x-direction for the CWT kernel.
%   Z (double):         Parameter for the Poisson wavelet.
%   w (double):         Base window size for the step-filter.
%   VSFW (double):      Variance-based scaling factor for the step-filter window.
%   NSFA (integer):     Number of angles for the step-filter.
%   SLC (double):       Strength level cutoff for lineament component filtering (%).
%   FDissimilarity (double): Dissimilarity weight for CWT feature selection.
%   FSaliency (double): Saliency percentile for CWT feature selection.
%   N_Scales (integer): Number of CWT scales to compute.
%   Line_Res (double):  Resize factor for the feature maps before extraction.
%   DR (integer):       Dimensionality reduction target (number of features).
%   SDF (double):       Scale step for CWT.
%   sigma2 (double):    Sigma for the Gaussian filter (`FilterB`).
%   tolerance_arcsec (double): Tolerance distance in arc-seconds for F-beta
%                             score calculation (read from GUI).
%   beta (double):      F-beta parameter for F-beta score calculation
%                       (read from GUI, typically 0.2).
%
% OUTPUTS:
%   L_val (double):     The final objective function value (Graph Representativeness).
%                       Lower is better for Bayesian optimization.
%   N_CWT (integer):    Total number of CWT features generated before selection.
%
% EXAMPLE:
%   % This function is typically called by a Bayesian optimizer. A direct
%   % call would require setting up numerous global variables and inputs.
%   %
%   % --- Setup (Illustrative) ---
%   % global XI YI X_Pix Y_Pix in pop_choice3 YI_Real_Ratio;
%   % load('input_data.mat'); % Load CWT_Input, All_Data, globals, etc.
%   %
%   % % Define a sample hyperparameter set
%   % params.WSFR = 1; params.N_Angles = 8; params.orderx = 1;
%   % params.Z = 2; params.w = 5; params.VSFW = 0.5;
%   % params.NSFA = 8; params.SLC = 80; params.FDissimilarity = 0.5;
%   % params.FSaliency = 75; params.N_Scales = 10; params.Line_Res = 1;
%   % params.DR = 10; params.SDF = 1.5; params.sigma2 = 1;
%   %
%   % [objectiveValue, numFeatures] = Lineaments_Auto7(...
%   %     CWT_Input_Features_Matrix, All_Data_Matrix, params.WSFR, ...
%   %     params.N_Angles, params.orderx, params.Z, params.w, params.VSFW, ...
%   %     params.NSFA, params.SLC, params.FDissimilarity, params.FSaliency, ...
%   %     params.N_Scales, params.Line_Res, params.DR, params.SDF, params.sigma2);
%   %
%   % fprintf('Objective Value (L_val): %.4f\n', objectiveValue);
%--------------------------------------------------------------------------



% Declare global variables used within this function or by called functions
global XI YI X_Pix Y_Pix in; % Essential for geometric context and masking
global pop_choice3;         % Determines the CWT kernel
global YI_Real_Ratio;       % Used for cropping operations
global XI_line_Auto YI_line_Auto; % For resized coordinate grids


if orderx == 1
    ordery = 0;
elseif orderx == 0
    ordery = 1;
end

% --- Stage 1: CWT Feature Generation ---
if orderx == ordery && orderx ~= 0 % Assuming non-zero equal orders might use 90 deg range
    betad = 90;
else
    betad = 180; % Standard angular range for CWT
end

Scales = 1:SDF:(N_Scales*SDF);
if N_Angles > 0
    angle_step = betad / N_Angles;
    Angless = 0 : angle_step : (betad - angle_step); % Ensure angles are within [0, betad)
else
    Angless = 0; % Default to a single angle if N_Angles is zero or invalid
end
Angles = Angless * pi / 180;

if ndims(CWT_Input_Features_Matrix) == 2
    N_Fs = 1;
else
    szCWT = size(CWT_Input_Features_Matrix);
    N_Fs = szCWT(3);
end
N_CWT = N_Scales * N_Angles * N_Fs;

if ~SUPPRESS_WAITBARS
    h_cwt = waitbar(0.5,'Kernel CWT...', 'WindowStyle', 'modal', 'Name', 'CWT Computation');
    frames_cwt = java.awt.Frame.getFrames();
    if ~isempty(frames_cwt)
        frames_cwt(end).setAlwaysOnTop(1);
    end
else
    h_cwt = [];
end

% Ensure pop_choice3 is set (e.g., from app state or default)
if isempty(pop_choice3)
    pop_choice3 = 'gaus'; % Default to 'gaus' if not set
    disp("Warning: global 'pop_choice3' for CWT type was empty, defaulted to 'gaus'.");
end

% Call the appropriate CWT function (assuming cwt2D_DerGus_BTO can handle derpoisson2d logic)
% Ensure cwt2D_DerGus_BTO is on the path
if (strcmp(pop_choice3,'gaus'))
    Fe_All = cwt2D_DerGus_BTO(CWT_Input_Features_Matrix, Scales, Angles, orderx, ordery, WSFR);

    elseif (strcmp(pop_choice3,'derpoisson2d'))
    Fe_All = cwt2D_DerPoisson_BTO(CWT_Input_Features_Matrix,Scales,Angles,orderx,ordery,WSFR,Z);   
    
else
    if ~isempty(h_cwt) && ishandle(h_cwt), close(h_cwt); end
    error(['Unsupported pop_choice3: ', pop_choice3]);
end
if ~isempty(h_cwt) && ishandle(h_cwt), close(h_cwt); end
pause(0.01);

if ~SUPPRESS_WAITBARS
    h_save_cwt = waitbar(0.5,'Save Kernel CWT Results...', 'WindowStyle', 'modal', 'Name', 'Saving CWT');
    frames_save_cwt = java.awt.Frame.getFrames();
    if ~isempty(frames_save_cwt)
        frames_save_cwt(end).setAlwaysOnTop(1);
    end
else
    h_save_cwt = [];
end
[XI_siz, YI_siz, nn, mm, kk] = size(Fe_All);
% Result3D = reshape(Fe_All, XI_siz, YI_siz, nn*mm*kk);
Result3D = reshape(Fe_All, XI_siz, YI_siz, nn*mm, kk);

if ~isempty(h_save_cwt) && ishandle(h_save_cwt), close(h_save_cwt); end
pause(0.01);


Result3D_Size = size(Result3D, 3);
% DR is passed as a character string from optimizableVariable, convert if not already numeric
if ischar(DR)
    DR_numeric = str2double(DR);
else
    DR_numeric = DR;
end

if Result3D_Size >= DR_numeric
    DR2 = DR_numeric;
else
    DR2 = Result3D_Size;
end

if DR2 <= 0 % Ensure DR2 is at least 1 if there are features
    DR2 = 1;
end





            input_ndims = ndims(Result3D);
            image_count = 1; % Default for a single image or 2D input

    if input_ndims == 2
        % This case is unlikely for CWT results and remains unchanged
        Spectral_PCA_Features_Matrix(:, :, 1) = Result3D;
        close(h);
        return;

    elseif input_ndims == 3 % Single 3D image (m x n x features) - OPTIMIZED
        % Process the single image
        SPCA_Features = CWTFeatureSelection(Result3D, DR2, FSaliency, FDissimilarity);
        
        [rows, cols, num_selected_features] = size(SPCA_Features);
        
        % Initialize output matrix
        Spectral_PCA_Features_Matrix = zeros(rows, cols, num_selected_features);
        
        % Handle zero values efficiently
        SPCA_Features(SPCA_Features == 0) = 1e-12;
        
        % OPTIMIZATION: Process all features at once using vectorized operations
        % Apply masking to all features simultaneously
        masked_features = bsxfun(@times, SPCA_Features, in);
        
        % Set masked values to NaN efficiently
        masked_features(masked_features == 0) = NaN;
        
        % Process all features in parallel using arrayfun or vectorized operations
        for k = 1:num_selected_features
            Spectral_PCA_Features_Matrix(:, :, k) = nDstrb2D(masked_features(:, :, k));
        end

    elseif input_ndims == 4 % Multiple 3D images - HEAVILY OPTIMIZED
        image_count = size(Result3D, 4);
        [rows, cols, ~] = size(Result3D(:,:,:,1)); 

        % Pre-allocate output matrix
        total_features = DR2 * image_count;
        Spectral_PCA_Features_Matrix = zeros(rows, cols, total_features);
        
        % Process images in batches for better memory management
        batch_size = min(4, image_count); % Process 4 images at a time
        feature_idx = 1;
        
        for batch_start = 1:batch_size:image_count
            batch_end = min(batch_start + batch_size - 1, image_count);
            current_batch_size = batch_end - batch_start + 1;
            
            % waitbar(batch_start / image_count, h, sprintf('Processing Images %d-%d of %d...', batch_start, batch_end, image_count));
            
            % OPTIMIZATION: Process batch of images simultaneously
            batch_data = Result3D(:, :, :, batch_start:batch_end);
            
            % Process each image in the batch
            for img_idx = 1:current_batch_size
                current_image_volume = batch_data(:, :, :, img_idx);
                SPCA_Features_current_image = CWTFeatureSelection(current_image_volume, DR2, FSaliency, FDissimilarity);
                
                % Handle zero values
                SPCA_Features_current_image(SPCA_Features_current_image == 0) = 1e-12;
                
                num_selected_features = size(SPCA_Features_current_image, 3);
                
                % OPTIMIZATION: Apply masking to all features at once
                masked_features = bsxfun(@times, SPCA_Features_current_image, in);
                masked_features(masked_features == 0) = NaN;
                
                % Store features efficiently
                for k = 1:num_selected_features
                    Spectral_PCA_Features_Matrix(:, :, feature_idx) = nDstrb2D(masked_features(:, :, k));
                    feature_idx = feature_idx + 1;
                end
            end
        end

    else
        warning('Input data has unsupported number of dimensions (%d). Expected 2, 3, or 4.', input_ndims);
        close(h);
        return;
    end

            % SPCA_Features_Size is now the number of *features* for a single image,
            % not the number of images. You might want a different variable
            % to report the number of images processed.
            % app.CWTReductionto.Value = SPCA_Features_Size; % This line should probably be removed or adjusted


% --- Stage 3: Lineament Extraction per Feature ---
if ~SUPPRESS_WAITBARS
    h_le = waitbar(0.66, 'Lineament Extraction...', 'WindowStyle', 'modal', 'Name', 'Lineament Extraction');
    frames_le = java.awt.Frame.getFrames();
    if ~isempty(frames_le)
        frames_le(end).setAlwaysOnTop(1);
    end
else
    h_le = [];
end

% Store Spectral_PCA_Features_Matrix in BHO_BestOutputs if this becomes the best iteration
% (We'll check and store it later when we know if this is the best iteration)
Spectral_PCA_Features_Matrix_to_store = Spectral_PCA_Features_Matrix;

originalArrayNoNaNPages = cat(3, Spectral_PCA_Features_Matrix, All_Data_Matrix);
clear Spectral_PCA_Features_Matrix; % Free memory

% Remove pages that are all NaN (if any, though masking might prevent this)
if ndims(originalArrayNoNaNPages) == 3
    nanPageIndices = all(all(isnan(originalArrayNoNaNPages), 1), 2);
    originalArrayNoNaNPages(:,:,squeeze(nanPageIndices)) = [];
end

if isempty(originalArrayNoNaNPages) || all(isnan(originalArrayNoNaNPages(:)))
    disp('Warning: All feature maps are NaN or empty after masking/selection.');
    L_val = Inf;
    if ishandle(h_le), close(h_le); end
    return;
end

if ndims(originalArrayNoNaNPages) == 2
    Number_of_Features_used_for_Lineaments_Detection = 1;
    % Ensure it's 3D for consistency in the loop
    temp_arr = originalArrayNoNaNPages;
    clear originalArrayNoNaNPages;
    originalArrayNoNaNPages(:,:,1) = temp_arr;
else
    Number_of_Features_used_for_Lineaments_Detection = size(originalArrayNoNaNPages, 3);
end

% Ensure X_Pix and Y_Pix are valid
if isempty(X_Pix) || isempty(Y_Pix) || X_Pix == 0 || Y_Pix == 0
    disp("Warning: X_Pix or Y_Pix is not valid. Using image dimensions.");
    X_Pix = YI_siz; % Assuming YI_siz corresponds to X dimension of image based on typical meshgrid
    Y_Pix = XI_siz; % Assuming XI_siz corresponds to Y dimension
end

% Ensure Line_Res is valid
if Line_Res <=0
    disp("Warning: Line_Res is invalid. Defaulting to 256.");
    Line_Res = 1;
end

resize_factor = Line_Res;

% Initialize XI_line_Auto and YI_line_Auto based on the *original* grid dimensions (XI, YI)
% These should be available as globals from the main app scope
if isempty(XI) || isempty(YI)
    disp("Error: Global XI or YI is empty. Cannot proceed with resizing coordinates.");
    L_val = Inf;
    if ishandle(h_le), close(h_le); end
    return;
end
XI_line_Auto = imresize(XI, resize_factor);
YI_line_Auto = imresize(YI, resize_factor);

% Calculate variance for dynamic grm2 adjustment
vari1 = zeros(Number_of_Features_used_for_Lineaments_Detection,1);
for ttt6_var = 1:Number_of_Features_used_for_Lineaments_Detection
    Grid0_var = originalArrayNoNaNPages(:,:,ttt6_var);
    % Ensure FilterB is on the path
    Grid2_var = FilterB(Grid0_var, sigma2);
    Grid2_var(isnan(Grid2_var)) = 0;
    if var(double(Grid2_var(:))) == 0
        vari1(ttt6_var) = 1; % Avoid division by zero if variance is zero
    else
        vari1(ttt6_var) = 1/var(double(Grid2_var(:)));
    end
end
if length(vari1) > 1
    vari1_std = zscore(vari1);
else
    vari1_std = zeros(size(vari1)); % Zscore of a single element is NaN, handle this.
end

plotH0 = zeros(size(XI_line_Auto,1), size(XI_line_Auto,2), Number_of_Features_used_for_Lineaments_Detection);
plotH_colored_all = zeros(size(XI_line_Auto,1), size(XI_line_Auto,2), 3, Number_of_Features_used_for_Lineaments_Detection);  % Store colored images for display
grm2_vector = zeros(Number_of_Features_used_for_Lineaments_Detection, 1);  % Store grm2 for each feature

% Initialize cell array to store orientations from each feature
allOrientations = {};

for ttt6_le = 1:Number_of_Features_used_for_Lineaments_Detection
    Grid0_le = originalArrayNoNaNPages(:,:,ttt6_le);
    Grid2_le = FilterB(Grid0_le, sigma2);
    Grid2_le(isnan(Grid2_le)) = 0;

    current_grm = w; % w is the parameter from BHO
    grm2 = round(current_grm + (VSFW * current_grm) * vari1_std(ttt6_le));
    if grm2 <= 1
        grm2 = 1;
    end
    grm2_vector(ttt6_le) = grm2;  % Store grm2 for this feature

    Grid_resized = imresize(Grid2_le, resize_factor);
    data1 = im2double(Grid_resized);

    current_GSF_Angles = NSFA; % NSFA is the parameter from BHO
    Step_Filter_nAng = current_GSF_Angles;
    if Step_Filter_nAng > 0
        Step_Filter_step = pi / Step_Filter_nAng;
        Step_Filter_DTheta = 0:Step_Filter_step:pi-(Step_Filter_step);
    else
        Step_Filter_DTheta = 0; % Default if NSFA is 0
    end
    Step_Filter_Dbw = [2 4 6]; % This is fixed in your original code

    % Ensure step_Filtering is on the path
    Y_filtered = step_Filtering(data1, grm2, Step_Filter_DTheta, Step_Filter_Dbw, 2);

    % Ensure getFaultDetection is on the path
    [BW_detected, ~] = getFaultDetection(Y_filtered, data1, SLC);

    % Component-level filter based on strength
    CC_detected = bwconncomp(BW_detected);
    if CC_detected.NumObjects > 0
        stats_detected = regionprops(CC_detected, Y_filtered, 'PixelValues');
        strengths_detected = cellfun(@(x) sum(x(:)), {stats_detected.PixelValues});

        pct_cutoff = 100 - SLC;
        if isempty(strengths_detected)
            th_strength = 0;
        else
            th_strength = prctile(strengths_detected, pct_cutoff);
        end
        keep_indices = find(strengths_detected >= th_strength);
        BW_filtered_strength = ismember(labelmatrix(CC_detected), keep_indices);
    else
        BW_filtered_strength = false(size(BW_detected));
    end

    % Generate orientation data from the binary lineament map for a rose diagram
    % Use BW_filtered_strength (after component-level filtering) to match final lineaments
    [orientations360] = createRoseDiagrams(BW_filtered_strength);
    allOrientations{ttt6_le} = orientations360; % Store the orientations

    % Visualization part (plotNewColorMap0_) and subsequent processing for plotH00
    % This part seems to generate a binary image from a colored plot, which is indirect.
    % A more direct approach from BW_filtered_strength might be better if plotH_ is just for visualization.
    % Assuming plotNewColorMap0_ generates an RGB image and you need to convert it.
    if CC_detected.NumObjects > 0 && ~isempty(keep_indices)
        Map_for_plot = bwlabel(BW_filtered_strength, 8);
        Labels_for_plot = unique(Map_for_plot(Map_for_plot > 0))';

        % Ensure plotNewColorMap0_ is on the path
        if isempty(Labels_for_plot) % If no labels satisfy condition
            plotH_colored = zeros(size(data1,1), size(data1,2), 3); % black image
        else
            plotH_colored = plotNewColorMap0_(Y_filtered, zeros(size(data1)), Map_for_plot, Labels_for_plot, ...
                'Detected Lineaments', YI_line_Auto(:), XI_line_Auto(:));
        end
    else
        plotH_colored = zeros(size(data1,1), size(data1,2), 3); % Render as black if no components
    end

    % Store colored image for display (before converting to binary)
    plotH_colored_all(:,:,:,ttt6_le) = plotH_colored;

    plotH00_gray = (plotH_colored(:,:,1) + plotH_colored(:,:,2) + plotH_colored(:,:,3))/3;
    plotH00_bin = imbinarize(plotH00_gray);

    CC_final_filter = bwconncomp(plotH00_bin);
    if CC_final_filter.NumObjects > 0
        componentStats_final = regionprops(CC_final_filter, 'Area');
        % Using a fixed area threshold of 50 as in your code
        validComponents_final = find([componentStats_final.Area] >= 50);
        plotH00_final = ismember(labelmatrix(CC_final_filter), validComponents_final);
    else
        plotH00_final = false(size(plotH00_bin));
    end

    plotH0(:,:,ttt6_le) = imcomplement(plotH00_final); % Store complemented binary image
end

% Combine orientation data from all features into a single global variable
global Orient
if ~isempty(allOrientations)
    Orient = vertcat(allOrientations{:}); % Combine along the first dimension
else
    Orient = []; % Empty if no orientations were generated
end

% Stack lineaments from all features
% Original format: plotH0 is stored as imcomplement(plotH00_final), so it has:
%   lineaments = false (0), background = true (1)
% Keep original format for GRM calculation (no inversion)
% Original stacking logic: OR operation (this is what GRM expects)
if Number_of_Features_used_for_Lineaments_Detection > 0
    % Initialize stacked image based on the size of one processed feature map
    plotH1_stacked = false(size(plotH0,1), size(plotH0,2));
    for n_stack = 1:Number_of_Features_used_for_Lineaments_Detection
        % Use plotH0 directly (original format: lineaments = false (0), background = true (1))
        % Original OR operation - DO NOT CHANGE THIS as it affects GRM calculation
        plotH1_stacked = plotH1_stacked | plotH0(:,:,n_stack);
    end
else
    plotH1_stacked = false(size(XI_line_Auto,1), size(XI_line_Auto,2)); % empty if no features
end

% Ensure YI_Real_Ratio is sensible (e.g. aspect ratio of original image pixels if not square)
if isempty(YI_Real_Ratio) || YI_Real_Ratio <= 0
    YI_Real_Ratio = 1.0; % Default if not set or invalid
end

plotH1_rgb_cropped = im2double(plotH1_stacked); % Convert logical to double for cropping
cropPixels1 = round(0.025 * YI_Real_Ratio * size(plotH1_stacked,1));
cropPixels2 = round(0.025 * size(plotH1_stacked,2));

% Ensure crop pixels are not too large
cropPixels1 = min(cropPixels1, floor(size(plotH1_rgb_cropped,1)/2)-1);
cropPixels2 = min(cropPixels2, floor(size(plotH1_rgb_cropped,2)/2)-1);
if cropPixels1 < 0, cropPixels1 = 0; end
if cropPixels2 < 0, cropPixels2 = 0; end

% Set border pixels to 1.0 (white background) to match original format
% Original format: lineaments = 0.0 (black), background = 1.0 (white)
if cropPixels1 > 0
    plotH1_rgb_cropped(1:cropPixels1, :) = 1.0;  % White border (background)
    plotH1_rgb_cropped(end-cropPixels1+1:end, :) = 1.0;  % White border (background)
end
if cropPixels2 > 0
    plotH1_rgb_cropped(:, 1:cropPixels2) = 1.0;  % White border (background)
    plotH1_rgb_cropped(:, end-cropPixels2+1:end) = 1.0;  % White border (background)
end

if ~isempty(h_le) && ishandle(h_le), close(h_le); end
pause(0.01);

% --- Stage 4: Compute Graph Representativeness (Objective Value) ---
if ~SUPPRESS_WAITBARS
    h_graph = waitbar(0.5, 'Building Graph & Computing Representativeness...', 'WindowStyle', 'modal', 'Name', 'Graph Measure');
    frames_graph = java.awt.Frame.getFrames();
    if ~isempty(frames_graph)
        frames_graph(end).setAlwaysOnTop(1);
    end
else
    h_graph = [];
end

% Original GRM calculation: plotH1_rgb_cropped has lineaments = 0.0, background = 1.0
% Use imcomplement before bwconncomp to find lineament components
lineamentBinary = imbinarize(plotH1_rgb_cropped); % Ensure it's binary {0,1}, lineaments = 0, background = 1

% Density Map (used for segment weighting if getSegmentWeight requires it)
% This density map is based on the final cropped and stacked lineaments
% Also stored for display purposes
grayImage_density = lineamentBinary; % Already binary
windowSize_density = 3; % As in your code
filterKernel_density = ones(windowSize_density, windowSize_density);
densityMap_final = conv2(double(grayImage_density), filterKernel_density, 'same');
densityMap_final = densityMap_final / (windowSize_density^2);
densityMap_final = imcomplement(densityMap_final); % Original code complements

% Original approach: complement before bwconncomp to find lineament components
CC_segments = bwconncomp(imcomplement(lineamentBinary)); % Original GRM calculation
L_segments_pixels = CC_segments.PixelIdxList;

Segments = struct('startCoord', {}, 'endCoord', {}, 'pixelList', {});
if CC_segments.NumObjects > 0
    for sIdx = 1:length(L_segments_pixels)
        pixList = L_segments_pixels{sIdx};
        if numel(pixList) < 2 % Skip single-pixel segments or very short ones
            continue;
        end
        [rs, cs] = ind2sub(size(lineamentBinary), pixList);

        % A simple way to define start/end for non-skeletonized segments:
        % Find extreme points. For more robust, skeletonize first.
        % This is a simplification; proper skeletonization and endpoint/branchpoint detection is better.
        [~, min_idx] = min(rs); % Top-most as start_y
        [~, max_idx] = max(rs); % Bottom-most as end_y

        seg_struct.startCoord = [rs(min_idx(1)), cs(min_idx(1))]; % Take the first if multiple min/max
        seg_struct.endCoord   = [rs(max_idx(1)), cs(max_idx(1))];
        seg_struct.pixelList  = pixList;
        Segments = [Segments; seg_struct];
    end
end

ME_value = 0;
N_graph_segments = numel(Segments);

if N_graph_segments == 0
    ME_value = 0; % Or a penalty if no segments are found
else
    % --- Build Graph (simplified for ME_value calculation if full graph structure not strictly needed here) ---
    % The graph structure (G) was for visualization or other metrics in your example.
    % For ME_value, you primarily need segments and their pairwise similarities.

    % 1) Precompute segment weights (W_vals)
    % This requires a function `getSegmentWeight_auto`
    % Placeholder: using segment length as weight
    W_vals = zeros(N_graph_segments,1);
    total_pixels_in_segments = 0;
    for i = 1:N_graph_segments
        % W_vals(i) = getSegmentWeight_auto(Segments(i), densityMap_final); % Your custom function
        W_vals(i) = numel(Segments(i).pixelList); % Example: Length as weight
        total_pixels_in_segments = total_pixels_in_segments + W_vals(i);
    end

    % 2) Precompute similarity matrix (simMatrix)
    % This requires a function `computeSimilarity_auto`
    simMatrix = zeros(N_graph_segments, N_graph_segments);
    if N_graph_segments > 1
        for i = 1:N_graph_segments
            for j = i+1:N_graph_segments % Only upper triangle
                % ST_val = computeSimilarity_auto(Segments(i), Segments(j), densityMap_final); % Your custom function
                % Placeholder: inverse of distance between centroids
                centroid_i = mean(ind2sub(size(lineamentBinary), Segments(i).pixelList),1);
                centroid_j = mean(ind2sub(size(lineamentBinary), Segments(j).pixelList),1);
                dist_centroids = norm(centroid_i - centroid_j);
                ST_val = 1 / (1 + dist_centroids); % Example similarity
                simMatrix(i,j) = ST_val;
                simMatrix(j,i) = ST_val; % Symmetric
            end
        end
    end

    % 3) Sum up for ME_value
    for segIndex = 1:N_graph_segments
        W_val_current = W_vals(segIndex);

        if N_graph_segments == 1
            hatS_T = 0; % No other segments to compare to
        else
            rowSimilarities = simMatrix(segIndex,:);
            rowSimilarities(segIndex) = Inf; % Exclude self-similarity by setting to Inf for min
            hatS_T = min(rowSimilarities);
            if isinf(hatS_T) % If only one segment, min(Inf) is Inf
                hatS_T = 0;
            end
        end

        ME_value = ME_value + W_val_current * (1 - hatS_T);
    end
end

if ~isempty(h_graph) && ishandle(h_graph), close(h_graph); end
pause(0.01);

zeta = 1; % Weighting factor for graph representativeness
L_val = round(-zeta * ME_value); % Bayesopt minimizes, so negate. Round since GRM is in pixels (integer)

% Handle cases where L_val might be NaN or Inf
if isnan(L_val) || isinf(L_val)
    L_val = Inf; % Penalize bad parameter sets heavily
end

% --- Calculate Ground Truth Metrics for GRM Evaluation (BEFORE storing best outputs) ---
% Store metrics in global variables to track across BHO iterations
global All_Trg_Matrix BHO_GroundTruthMetrics
global XI_line_Auto YI_line_Auto

% Initialize variables for metrics (will be set if ground truth is available)
fbeta_score = [];
structural_metrics = [];

% Initialize BHO_GroundTruthMetrics if it doesn't exist
if ~exist('BHO_GroundTruthMetrics', 'var') || isempty(BHO_GroundTruthMetrics)
    BHO_GroundTruthMetrics = struct();
    BHO_GroundTruthMetrics.GRM_values = [];
    BHO_GroundTruthMetrics.fbeta_scores = [];
    BHO_GroundTruthMetrics.p21_ratios = [];
    BHO_GroundTruthMetrics.length_distribution_similarities = [];
    BHO_GroundTruthMetrics.angular_correlations = [];
    BHO_GroundTruthMetrics.bhattacharyya_coeffs = [];
    BHO_GroundTruthMetrics.js_divergences = [];
    BHO_GroundTruthMetrics.is_best_so_far = [];  % Track which iterations were best so far
end

% Check if ground truth is available
% Note: All_Trg_Matrix must be loaded before running BHO
try
    % Try to access the global variables directly
    % If they don't exist as globals, these will be empty or error
    has_gt = false;
    has_coords = false;
    
    % Check All_Trg_Matrix
    try
        if exist('All_Trg_Matrix', 'var')
            temp_gt = All_Trg_Matrix;
            if ~isempty(temp_gt) && (isnumeric(temp_gt) || islogical(temp_gt))
                has_gt = true;
                real_faults_test = temp_gt;
            end
        end
    catch
        % All_Trg_Matrix doesn't exist or is invalid
        has_gt = false;
    end
    
    % Check coordinate grids
    if exist('XI_line_Auto', 'var') && ~isempty(XI_line_Auto) && ...
       exist('YI_line_Auto', 'var') && ~isempty(YI_line_Auto)
        has_coords = true;
        XI_test = XI_line_Auto;
        YI_test = YI_line_Auto;
    end
    
    % Check if we have everything needed
    if has_gt && has_coords
        
        % Prepare detected lineaments (binary)
        detected_faults = imcomplement(plotH1_rgb_cropped);
        detected_faults = imbinarize(detected_faults);
        
        % Prepare ground truth (resize to match detected if needed)
        real_faults = real_faults_test;
        if size(real_faults, 1) ~= size(detected_faults, 1) || size(real_faults, 2) ~= size(detected_faults, 2)
            real_faults = imresize(real_faults, size(detected_faults));
        end
        real_faults = imbinarize(real_faults);
        
        % Get coordinate grids
        XI_metrics = XI_line_Auto;
        YI_metrics = YI_line_Auto;
        
        % Calculate F-beta score using tolerance passed from GUI/auto-estimation
        use_bidirectional = true;
        use_length_weighted = false;
        [fbeta_score, ~, ~, ~, ~, ~] = calculateFbetaScore(...
            real_faults, detected_faults, XI_metrics, YI_metrics, ...
            beta, tolerance_arcsec, use_bidirectional, use_length_weighted, false);
        
        % Calculate structural metrics (silent mode for BHO iterations)
        structural_metrics = calculateStructuralMetrics(real_faults, detected_faults, XI_metrics, YI_metrics, false);
        
    else
        % Ground truth not available - set metrics to NaN
        fbeta_score = NaN;
        structural_metrics = struct();
        structural_metrics.P21_ratio = NaN;
        structural_metrics.length_distribution_similarity = NaN;
        structural_metrics.angular_correlation = NaN;
        structural_metrics.bhattacharyya_coeff = NaN;
        structural_metrics.js_divergence = NaN;
    end
    
catch ME
    % If ground truth calculation fails (e.g., All_Trg_Matrix doesn't exist), 
    % just continue without it - don't break the optimization
    % This is expected if ground truth is not loaded
    % Set all metrics to NaN to keep arrays consistent
    fbeta_score = NaN;
    structural_metrics = struct();
    structural_metrics.P21_ratio = NaN;
    structural_metrics.length_distribution_similarity = NaN;
    structural_metrics.angular_correlation = NaN;
    structural_metrics.bhattacharyya_coeff = NaN;
    structural_metrics.js_divergence = NaN;
end

% Append current iteration metrics to global structure (ALWAYS store, even if NaN)
% This ensures all arrays have the same length regardless of errors
% Store actual GRM (ME_value), not the negated objective function (L_val)
% L_val = -zeta * ME_value, so actual GRM = -L_val (since zeta = 1)
% Handle edge cases where L_val might be Inf or NaN
% Round to integer since GRM is measured in pixels (discrete count)
if isnan(L_val) || isinf(L_val)
    actual_GRM = NaN;  % Store NaN if objective is invalid
else
    actual_GRM = round(-L_val);  % Convert negated objective to actual GRM (rounded to pixels)
end

% Ensure structural_metrics struct has all required fields (in case it wasn't created)
if ~isfield(structural_metrics, 'P21_ratio')
    structural_metrics.P21_ratio = NaN;
end
if ~isfield(structural_metrics, 'length_distribution_similarity')
    structural_metrics.length_distribution_similarity = NaN;
end
if ~isfield(structural_metrics, 'angular_correlation')
    structural_metrics.angular_correlation = NaN;
end
if ~isfield(structural_metrics, 'bhattacharyya_coeff')
    structural_metrics.bhattacharyya_coeff = NaN;
end
if ~isfield(structural_metrics, 'js_divergence')
    structural_metrics.js_divergence = NaN;
end

% Store all metrics (will be NaN if ground truth was not available or calculation failed)
BHO_GroundTruthMetrics.GRM_values = [BHO_GroundTruthMetrics.GRM_values; actual_GRM];
BHO_GroundTruthMetrics.fbeta_scores = [BHO_GroundTruthMetrics.fbeta_scores; fbeta_score];
BHO_GroundTruthMetrics.p21_ratios = [BHO_GroundTruthMetrics.p21_ratios; structural_metrics.P21_ratio];
BHO_GroundTruthMetrics.length_distribution_similarities = [BHO_GroundTruthMetrics.length_distribution_similarities; structural_metrics.length_distribution_similarity];

% Store angular metrics
if isfield(structural_metrics, 'angular_correlation')
    BHO_GroundTruthMetrics.angular_correlations = [BHO_GroundTruthMetrics.angular_correlations; structural_metrics.angular_correlation];
else
    BHO_GroundTruthMetrics.angular_correlations = [BHO_GroundTruthMetrics.angular_correlations; NaN];
end

if isfield(structural_metrics, 'bhattacharyya_coeff')
    BHO_GroundTruthMetrics.bhattacharyya_coeffs = [BHO_GroundTruthMetrics.bhattacharyya_coeffs; structural_metrics.bhattacharyya_coeff];
else
    BHO_GroundTruthMetrics.bhattacharyya_coeffs = [BHO_GroundTruthMetrics.bhattacharyya_coeffs; NaN];
end

if isfield(structural_metrics, 'js_divergence')
    BHO_GroundTruthMetrics.js_divergences = [BHO_GroundTruthMetrics.js_divergences; structural_metrics.js_divergence];
else
    BHO_GroundTruthMetrics.js_divergences = [BHO_GroundTruthMetrics.js_divergences; NaN];
end

% --- Store outputs from best iteration so far ---
% Track the best objective value and store outputs when this iteration is better
global BHO_BestOutputs
global BHO_BestSoFarHistory
if ~exist('BHO_BestOutputs', 'var') || isempty(BHO_BestOutputs)
    BHO_BestOutputs = struct();
    BHO_BestOutputs.best_L_val = Inf;  % Initialize with worst possible value
    BHO_BestOutputs.has_outputs = false;
end

% Initialize BHO_BestSoFarHistory if it doesn't exist
if ~exist('BHO_BestSoFarHistory', 'var') || isempty(BHO_BestSoFarHistory)
    BHO_BestSoFarHistory = struct('iteration', {}, 'hyperparameters', {}, 'fbeta_score', {}, ...
        'structural_metrics', {}, 'lineaments_vectors', {}, 'XI_line_Auto', {}, ...
        'YI_line_Auto', {}, 'L_val', {}, 'densityMap', {}, 'rasterLineaments', {});
end

% Get current iteration number from BHO_GroundTruthMetrics
current_iteration = length(BHO_GroundTruthMetrics.is_best_so_far) + 1;

% Check if this iteration is better than the best so far
% Since bayesopt minimizes, lower L_val is better
is_current_best = (L_val < BHO_BestOutputs.best_L_val);
if is_current_best
    % This is the best iteration so far - store all outputs
    BHO_BestOutputs.best_L_val = L_val;
    BHO_BestOutputs.plotH1_rgb_cropped = plotH1_rgb_cropped;
    BHO_BestOutputs.plotH0 = plotH0;
    BHO_BestOutputs.XI_line_Auto = XI_line_Auto;
    BHO_BestOutputs.YI_line_Auto = YI_line_Auto;
    BHO_BestOutputs.Number_of_Features_used_for_Lineaments_Detection = Number_of_Features_used_for_Lineaments_Detection;
    BHO_BestOutputs.grm2_vector = grm2_vector;  % Store grm2 values for deep/shallow classification
    BHO_BestOutputs.Result3D_Auto = Result3D;  % Store CWT results from best iteration
    BHO_BestOutputs.Spectral_PCA_Features_Matrix_Auto = Spectral_PCA_Features_Matrix_to_store;  % Store selected features from best iteration
    BHO_BestOutputs.plotH_colored_all = plotH_colored_all;  % Store colored lineament images for display (blue to red based on strength)
    BHO_BestOutputs.densityMap_Auto = densityMap_final;  % Store density map for display
    
    % Store ground truth metrics from best iteration (if calculated)
    if ~isempty(fbeta_score) && ~isempty(structural_metrics)
        BHO_BestOutputs.fbeta_score = fbeta_score;
        BHO_BestOutputs.structural_metrics = structural_metrics;
        BHO_BestOutputs.has_ground_truth = true;
    else
        BHO_BestOutputs.has_ground_truth = false;
    end
    
    BHO_BestOutputs.has_outputs = true;
    
    % --- Create Shape_Auto from plotH0 for this best-so-far iteration ---
    % Convert binary lineament maps to vector format
    Shape_Auto_iter = struct('Geometry', {}, 'X', {}, 'Y', {}, 'Name', {});
    
    for n = 1:Number_of_Features_used_for_Lineaments_Detection
        % Get binary image for this feature
        BW = plotH0(:,:,n);
        
        % Invert so lines are objects (1) on background (0)
        BW = imcomplement(BW);
        
        % Skeletonize to ensure single-pixel width
        BW = bwmorph(BW, 'thin', Inf);
        
        % Extract boundaries
        [B,~] = bwboundaries(BW, 'noholes');
        
        % Get coordinate vectors
        xVec = linspace(min(XI_line_Auto(:)), max(XI_line_Auto(:)), size(BW,2));
        yVec = linspace(min(YI_line_Auto(:)), max(YI_line_Auto(:)), size(BW,1));
        
        % Convert each boundary to vector coordinates
        for k = 1:length(B)
            boundary = B{k};
            rowIdx = boundary(:,1);  % Y
            colIdx = boundary(:,2);  % X
            
            % Convert pixel indices to real-world coordinates
            xCoords = xVec(colIdx);
            yCoords = yVec(rowIdx);
            
            % Store in shape structure
            currentShape = struct('Geometry', 'Line', 'X', xCoords', 'Y', yCoords', ...
                'Name', ['Fault_Feature', num2str(n), '_', num2str(k)]);
            Shape_Auto_iter = [Shape_Auto_iter; currentShape];
        end
    end
    
    % Store hyperparameters as a structure
    hyperparams = struct('WSFR', WSFR, 'NAngles', N_Angles, 'orderx', orderx, ...
        'Z', Z, 'w', w, 'VSFW', VSFW, 'NSFA', NSFA, 'SLC', SLC, ...
        'FDissimilarity', FDissimilarity, 'FSaliency', FSaliency);
    
    % Create display-friendly raster using AND-stacking (UNION of lineaments)
    % This is different from plotH1_rgb_cropped which uses OR-stacking (INTERSECTION)
    % The AND-stacked version shows ALL lineaments from ANY feature, matching vector lineaments
    % Format: plotH0 has lineaments=false(0), background=true(1)
    % AND operation: pixel is background only if ALL features say it's background
    %                pixel is lineament if ANY feature says it's lineament (UNION)
    plotH1_display = true(size(plotH0,1), size(plotH0,2));
    for n_display = 1:Number_of_Features_used_for_Lineaments_Detection
        plotH1_display = plotH1_display & plotH0(:,:,n_display);
    end
    % Convert to double and apply same cropping as plotH1_rgb_cropped
    plotH1_display_cropped = im2double(plotH1_display);
    if cropPixels1 > 0
        plotH1_display_cropped(1:cropPixels1, :) = 1.0;
        plotH1_display_cropped(end-cropPixels1+1:end, :) = 1.0;
    end
    if cropPixels2 > 0
        plotH1_display_cropped(:, 1:cropPixels2) = 1.0;
        plotH1_display_cropped(:, end-cropPixels2+1:end) = 1.0;
    end
    
    % Add to history - use AND-stacked raster for display (matches vector lineaments)
    history_entry = struct('iteration', current_iteration, ...
        'hyperparameters', hyperparams, ...
        'fbeta_score', fbeta_score, ...
        'structural_metrics', structural_metrics, ...
        'lineaments_vectors', Shape_Auto_iter, ...
        'XI_line_Auto', XI_line_Auto, ...
        'YI_line_Auto', YI_line_Auto, ...
        'L_val', L_val, ...
        'densityMap', densityMap_final, ...
        'rasterLineaments', plotH1_display_cropped);
    
    BHO_BestSoFarHistory = [BHO_BestSoFarHistory; history_entry];
end

% Store whether this iteration was best so far
BHO_GroundTruthMetrics.is_best_so_far = [BHO_GroundTruthMetrics.is_best_so_far; is_current_best];

%% Live Visualization: Update figure with current lineaments and GRM vs F-beta plot
% Use a persistent figure handle to update the same figure across iterations
persistent h_live_fig h_ax_lineaments h_ax_scatter h_checkbox_trajectory h_trajectory_line

% Check if figure exists and is valid
if isempty(h_live_fig) || ~ishandle(h_live_fig)
    % Create new figure for live visualization (maximized)
    h_live_fig = figure('Name', 'BTO Live Progress', 'NumberTitle', 'off');
    set(h_live_fig, 'Units', 'normalized', 'OuterPosition', [0 0 1 1]);
    try
        set(h_live_fig, 'WindowState', 'maximized');
    catch
        % Fallback for older MATLAB versions
    end
    
    % Create subplots with space for checkbox
    h_ax_lineaments = subplot(1, 2, 1);
    h_ax_scatter = subplot(1, 2, 2);
    
    % Add checkbox to toggle trajectory lines (default: ON)
    h_checkbox_trajectory = uicontrol(h_live_fig, 'Style', 'checkbox', ...
        'String', 'Show Trajectory', ...
        'Value', 1, ...  % Default: show trajectory
        'Units', 'normalized', ...
        'Position', [0.75, 0.02, 0.12, 0.04], ...
        'FontSize', 10, ...
        'BackgroundColor', get(h_live_fig, 'Color'), ...
        'Tag', 'TrajectoryCheckbox');
    
    % Set callback to toggle trajectory line visibility
    set(h_checkbox_trajectory, 'Callback', @(src,~) toggleTrajectoryLine(src));
    
    % Initialize trajectory line handle
    h_trajectory_line = [];
end

% Make sure figure is visible and brought to front
figure(h_live_fig);

% Get trajectory checkbox state (default to true if checkbox doesn't exist)
show_trajectory = true;
if ~isempty(h_checkbox_trajectory) && ishandle(h_checkbox_trajectory)
    show_trajectory = get(h_checkbox_trajectory, 'Value') == 1;
end

% --- Left subplot: Current iteration lineaments ---
subplot(h_ax_lineaments);
cla(h_ax_lineaments);
hold(h_ax_lineaments, 'on');

% Convert raster to vector lineaments for better display
% (same approach as used in BHO Best So Far display)
for n_feat = 1:size(plotH0, 3)
    BW_feat = plotH0(:,:,n_feat);
    BW_feat = imcomplement(BW_feat);  % Invert so lines are 1, background is 0
    BW_feat = bwmorph(BW_feat, 'thin', Inf);  % Skeletonize
    [B_feat, ~] = bwboundaries(BW_feat, 'noholes');
    
    % Get coordinate vectors
    xVec_feat = linspace(min(XI_line_Auto(:)), max(XI_line_Auto(:)), size(BW_feat, 2));
    yVec_feat = linspace(min(YI_line_Auto(:)), max(YI_line_Auto(:)), size(BW_feat, 1));
    
    % Plot each boundary as a line
    for k_feat = 1:length(B_feat)
        boundary_feat = B_feat{k_feat};
        if size(boundary_feat, 1) > 2  % Only plot if more than 2 points
            rowIdx_feat = boundary_feat(:, 1);
            colIdx_feat = boundary_feat(:, 2);
            xCoords_feat = xVec_feat(colIdx_feat);
            yCoords_feat = yVec_feat(rowIdx_feat);
            plot(h_ax_lineaments, xCoords_feat, yCoords_feat, 'Color', [0.2 0.6 0.8], 'LineWidth', 1.2);
        end
    end
end

hold(h_ax_lineaments, 'off');
set(h_ax_lineaments, 'YDir', 'normal');
axis(h_ax_lineaments, 'tight');
% Apply YI_Real_Ratio for correct aspect ratio
if exist('YI_Real_Ratio', 'var') && ~isempty(YI_Real_Ratio) && YI_Real_Ratio > 0
    daspect(h_ax_lineaments, [YI_Real_Ratio 1 1]);
else
    axis(h_ax_lineaments, 'equal');
end
xlabel(h_ax_lineaments, 'Longitude', 'FontSize', 11);
ylabel(h_ax_lineaments, 'Latitude', 'FontSize', 11);
box(h_ax_lineaments, 'on');

% Title with current metrics
if ~isempty(fbeta_score) && ~isnan(fbeta_score)
    title(h_ax_lineaments, sprintf('Iteration %d: GRM = %d, F-Beta = %.4f', ...
        current_iteration, actual_GRM, fbeta_score), 'FontSize', 12);
else
    title(h_ax_lineaments, sprintf('Iteration %d: GRM = %d', ...
        current_iteration, actual_GRM), 'FontSize', 12);
end

% Mark if this is best so far
if is_current_best
    text(h_ax_lineaments, 0.02, 0.98, 'BEST SO FAR', 'Units', 'normalized', ...
        'FontSize', 12, 'FontWeight', 'bold', 'Color', [0 0.6 0], ...
        'VerticalAlignment', 'top', 'BackgroundColor', [0.9 1 0.9]);
end

% --- Right subplot: GRM vs F-beta scatter plot with trajectory ---
axes(h_ax_scatter);  % Make sure we're on the right axes
cla(h_ax_scatter, 'reset');  % Full reset of axes

% Get ALL data points
all_grm = BHO_GroundTruthMetrics.GRM_values(:);
all_fbeta = BHO_GroundTruthMetrics.fbeta_scores(:);
all_is_best = BHO_GroundTruthMetrics.is_best_so_far(:);
n_total = length(all_grm);

% Get valid data points (non-NaN F-beta scores and GRM values)
valid_mask = ~isnan(all_fbeta) & ~isnan(all_grm);
n_valid = sum(valid_mask);

if n_valid > 0
    hold(h_ax_scatter, 'on');
    
    % Draw trajectory line connecting iterations in ORDER (iteration 1 -> 2 -> 3 -> ...)
    traj_grm = [];
    traj_fbeta = [];
    for iter = 1:n_total
        if valid_mask(iter)
            traj_grm = [traj_grm; all_grm(iter)];
            traj_fbeta = [traj_fbeta; all_fbeta(iter)];
        end
    end
    if length(traj_grm) >= 2
        h_trajectory_line = plot(h_ax_scatter, traj_grm, traj_fbeta, '-', ...
            'Color', [0.5 0.5 0.5], 'LineWidth', 2, 'Tag', 'TrajectoryLine');
        % Set initial visibility based on checkbox
        if show_trajectory
            set(h_trajectory_line, 'Visible', 'on');
        else
            set(h_trajectory_line, 'Visible', 'off');
        end
    end
    
    % Plot each point with iteration number inside
    for iter = 1:n_total
        if valid_mask(iter)
            grm_pt = all_grm(iter);
            fbeta_pt = all_fbeta(iter);
            
            % Determine color based on best-so-far status
            if iter <= length(all_is_best) && all_is_best(iter)
                % Best so far - orange
                face_color = [1.0 0.5 0.0];
                edge_color = [0.8 0.3 0.0];
                marker_size = 500;
                text_color = 'k';
            else
                % Discarded - gray
                face_color = [0.7 0.7 0.7];
                edge_color = [0.5 0.5 0.5];
                marker_size = 400;
                text_color = 'k';
            end
            
            % Highlight current iteration with green
            if iter == current_iteration
                face_color = [0.2 0.9 0.2];
                edge_color = [0.0 0.6 0.0];
                marker_size = 600;
                text_color = 'k';
            end
            
            % Draw filled circle
            scatter(h_ax_scatter, grm_pt, fbeta_pt, marker_size, 'o', ...
                'filled', 'MarkerFaceColor', face_color, 'MarkerEdgeColor', edge_color, 'LineWidth', 2);
            
            % Add iteration number inside circle (black text for visibility)
            text(h_ax_scatter, grm_pt, fbeta_pt, num2str(iter), ...
                'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                'FontSize', 10, 'FontWeight', 'bold', 'Color', text_color);
        end
    end
    
    hold(h_ax_scatter, 'off');
    
    % Calculate correlation if enough points
    valid_grm = all_grm(valid_mask);
    valid_fbeta = all_fbeta(valid_mask);
    if n_valid >= 2
        r = corrcoef(valid_grm, valid_fbeta);
        r_val = r(1,2);
        title(h_ax_scatter, sprintf('BTO Trajectory (r = %.3f)', r_val), 'FontSize', 12, 'FontWeight', 'bold');
    else
        title(h_ax_scatter, 'BTO Trajectory', 'FontSize', 12, 'FontWeight', 'bold');
    end
    
    xlabel(h_ax_scatter, 'GRM', 'FontSize', 11);
    ylabel(h_ax_scatter, 'F-Beta Score', 'FontSize', 11);
    grid(h_ax_scatter, 'on');
    set(h_ax_scatter, 'FontSize', 10);
    
else
    % No valid F-beta scores yet
    text(h_ax_scatter, 0.5, 0.5, 'Waiting for ground truth metrics...', ...
        'HorizontalAlignment', 'center', 'FontSize', 12, 'Units', 'normalized');
    title(h_ax_scatter, 'BTO Trajectory', 'FontSize', 12, 'FontWeight', 'bold');
    xlabel(h_ax_scatter, 'GRM', 'FontSize', 11);
    ylabel(h_ax_scatter, 'F-Beta Score', 'FontSize', 11);
end

% Update figure
drawnow;

% fprintf('Objective L_val: %f, N_CWT: %d\n', L_val, N_CWT);
end

%% Local function: Toggle trajectory line visibility
function toggleTrajectoryLine(src)
    % Find the trajectory line in the current figure by its tag
    h_line = findobj(gcf, 'Tag', 'TrajectoryLine');
    if ~isempty(h_line) && ishandle(h_line)
        if src.Value == 1
            set(h_line, 'Visible', 'on');
        else
            set(h_line, 'Visible', 'off');
        end
    end
end