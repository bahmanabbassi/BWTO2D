function shapeStruct = convertRasterToShape(rasterImage, XI_line, YI_line, prefix)
% CONVERTRASTERTOSHAPE Convert a binary raster lineament image to a shape structure
%
% Inputs:
%   rasterImage - 2D raster image with lineaments=1.0, background=0.0
%   XI_line     - X coordinate grid
%   YI_line     - Y coordinate grid  
%   prefix      - String prefix for naming (e.g., 'Deep', 'Shallow', 'All')
%
% Output:
%   shapeStruct - Structure array with fields: Geometry, X, Y, Name
%                 Compatible with shapewrite() function

    % Initialize empty shape structure
    shapeStruct = struct('Geometry', {}, 'X', {}, 'Y', {}, 'Name', {});
    
    % Check for valid inputs
    if isempty(rasterImage) || isempty(XI_line) || isempty(YI_line)
        return;
    end
    
    % Get binary image (lineaments = 1, background = 0)
    % The input rasterImage should already have lineaments=1.0, background=0.0
    BW = imbinarize(rasterImage);
    
    % Skeletonize to ensure single-pixel width lines
    BW = bwmorph(BW, 'thin', Inf);
    
    % Extract boundaries
    [B, ~] = bwboundaries(BW, 'noholes');
    
    % Get coordinate vectors
    xVec = linspace(min(XI_line(:)), max(XI_line(:)), size(BW, 2));
    yVec = linspace(min(YI_line(:)), max(YI_line(:)), size(BW, 1));
    
    % Convert each boundary to vector coordinates
    for k = 1:length(B)
        boundary = B{k};
        rowIdx = boundary(:, 1);  % Y (row index)
        colIdx = boundary(:, 2);  % X (column index)
        
        % Convert pixel indices to real-world coordinates
        xCoords = xVec(colIdx);
        yCoords = yVec(rowIdx);
        
        % Store in shape structure
        currentShape = struct('Geometry', 'Line', ...
                              'X', xCoords', ...
                              'Y', yCoords', ...
                              'Name', [prefix, '_Fault_', num2str(k)]);
        shapeStruct = [shapeStruct; currentShape];
    end
end

