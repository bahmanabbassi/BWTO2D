function toggleGTVisibilityCallback(fig_handle)
% Helper function to toggle ground truth overlay visibility
% This function is defined in a separate file to be accessible from callbacks
    try
        % Get the checkbox handle
        checkbox_handle = findobj(fig_handle, 'Tag', 'ShowGroundTruthCheckbox');
        if isempty(checkbox_handle)
            return;
        end
        
        % Get current checkbox value
        show_gt = get(checkbox_handle, 'Value');
        
        % Get current axes
        ax = findobj(fig_handle, 'Type', 'axes');
        if isempty(ax)
            return;
        end
        ax = ax(1);  % Use first axes
        
        % Find all ground truth line plots by their tag
        gt_lines = findobj(ax, 'Tag', 'GroundTruthLine');
        
        if show_gt
            % Show ground truth lines
            if ~isempty(gt_lines)
                set(gt_lines, 'Visible', 'on');
            end
        else
            % Hide ground truth lines
            if ~isempty(gt_lines)
                set(gt_lines, 'Visible', 'off');
            end
        end
    catch ME
        % Silently handle any errors to prevent callback failures
        % disp(ME.message);  % Uncomment for debugging
    end
end






