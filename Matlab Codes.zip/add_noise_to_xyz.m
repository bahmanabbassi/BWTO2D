%% ADD_NOISE_TO_XYZ - Add noise to Gravity/Magnetic Geosoft XYZ files
%
% This script adds various types of noise to geophysical data (gravity,
% magnetics) stored in Geosoft .XYZ format.
%
% NOISE TYPES AVAILABLE:
%   1. Gaussian     - Normal distribution noise (most common)
%   2. Uniform      - Uniform distribution noise
%   3. Salt&Pepper  - Random spike noise (impulse noise)
%   4. Poisson      - Poisson distribution noise
%   5. Pink (1/f)   - Correlated noise, common in geophysics
%   6. Regional     - Low-frequency trend/drift noise
%
% OPTIMIZED for large files (100MB+)
% FLEXIBLE: Handles various XYZ formats (3 or 4 columns, with/without headers)
%
% Author: MATLAB Script
% Date: December 2024

clear; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% USER CONFIGURATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input file (Geosoft .XYZ format)
inputFile = 'Magnetic_RTP_Trend_LatLon_Zone17N.xyz';

% Output file: 'auto' = generate from input name + noise parameters
outputFile = 'auto';

% Data column: 'auto' = last column, or specify number (3, 4, etc.)
dataColumn = 'auto';

% ----- NOISE SETTINGS -----

% Noise type: 'gaussian', 'uniform', 'saltpepper', 'poisson', 'pink', 'regional'
noiseType = 'gaussian';

% Noise level as percentage (e.g., 5 = 5% noise)
noisePercent = 2;

% Reference for percentage: 'range' (data range) or 'std' (standard deviation)
noiseReference = 'range';

% Salt & Pepper specific: density of affected points (0-1)
saltPepperDensity = 0.05;

% Regional noise specific: wavelength as fraction of data extent
regionalWavelength = 0.2;

% Random seed (for reproducibility, set to [] for random)
randomSeed = 42;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% READ INPUT FILE (ROBUST FOR VARIOUS FORMATS)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('====================================================\n');
fprintf('  ADD NOISE TO GEOSOFT XYZ DATA\n');
fprintf('====================================================\n\n');

if ~exist(inputFile, 'file')
    error('Input file not found: %s', inputFile);
end

% Generate output filename automatically if 'auto'
if ischar(outputFile) && strcmpi(outputFile, 'auto')
    [~, baseName, ext] = fileparts(inputFile);
    
    % Build parameter string
    paramStr = sprintf('_NT-%s_NP-%.1f', noiseType, noisePercent);
    
    % Add specific parameters based on noise type
    if strcmpi(noiseType, 'saltpepper')
        paramStr = [paramStr, sprintf('_SPD-%.2f', saltPepperDensity)];
    elseif strcmpi(noiseType, 'regional')
        paramStr = [paramStr, sprintf('_RW-%.2f', regionalWavelength)];
    end
    
    outputFile = [baseName, paramStr, ext];
    fprintf('Auto-generated output filename:\n  %s\n\n', outputFile);
end

% Set random seed
if ~isempty(randomSeed)
    rng(randomSeed);
    fprintf('Random seed: %d (reproducible)\n', randomSeed);
else
    rng('shuffle');
    fprintf('Random seed: shuffled\n');
end

% Get file size
fileInfo = dir(inputFile);
fileSizeMB = fileInfo.bytes / 1024 / 1024;
fprintf('Reading: %s (%.1f MB)\n', inputFile, fileSizeMB);
fprintf('  Please wait...\n');
tic;

% Read entire file and parse
% This handles: spaces, tabs, leading whitespace, no headers
fid = fopen(inputFile, 'r');
fileContent = fread(fid, '*char')';
fclose(fid);

% Split into lines
lines = strsplit(fileContent, {'\r\n', '\n', '\r'});

% Separate header lines (starting with /) from data lines
headerLines = {};
dataLines = {};

for i = 1:length(lines)
    line = strtrim(lines{i});
    if isempty(line)
        continue;
    elseif line(1) == '/'
        headerLines{end+1} = lines{i}; %#ok<SAGROW>
    else
        dataLines{end+1} = line; %#ok<SAGROW>
    end
end

fprintf('  Found %d header lines, %d data lines\n', length(headerLines), length(dataLines));

% Parse data lines into matrix
if isempty(dataLines)
    error('No data found in file!');
end

% Determine number of columns from first data line
firstLineValues = sscanf(dataLines{1}, '%f');
numCols = length(firstLineValues);
numPoints = length(dataLines);

fprintf('  Detected %d columns\n', numCols);

% Pre-allocate matrix
dataMatrix = zeros(numPoints, numCols);

% Parse all data lines (vectorized where possible)
fprintf('  Parsing data...\n');
for i = 1:numPoints
    dataMatrix(i, :) = sscanf(dataLines{i}, '%f')';
end

readTime = toc;
fprintf('  Loaded %d points (%.2f sec)\n\n', numPoints, readTime);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DETERMINE DATA COLUMN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ischar(dataColumn) && strcmpi(dataColumn, 'auto')
    % Auto-detect: use the last column
    dataColumn = numCols;
    fprintf('Auto-detected data column: %d (last column)\n\n', dataColumn);
elseif dataColumn > numCols
    error('Data column %d exceeds number of columns (%d)', dataColumn, numCols);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% EXTRACT DATA AND COMPUTE STATISTICS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

originalData = dataMatrix(:, dataColumn);

dataMin = min(originalData);
dataMax = max(originalData);
dataRange = dataMax - dataMin;
dataStd = std(originalData);
dataMean = mean(originalData);

fprintf('Original Data Statistics (Column %d):\n', dataColumn);
fprintf('  Min:   %12.4f\n', dataMin);
fprintf('  Max:   %12.4f\n', dataMax);
fprintf('  Range: %12.4f\n', dataRange);
fprintf('  Mean:  %12.4f\n', dataMean);
fprintf('  Std:   %12.4f\n\n', dataStd);

if strcmpi(noiseReference, 'range')
    noiseAmplitude = (noisePercent / 100) * dataRange;
    fprintf('Noise amplitude: %.4f (%.1f%% of range)\n', noiseAmplitude, noisePercent);
else
    noiseAmplitude = (noisePercent / 100) * dataStd;
    fprintf('Noise amplitude: %.4f (%.1f%% of std)\n', noiseAmplitude, noisePercent);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% GENERATE NOISE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('\nGenerating %s noise...\n', upper(noiseType));
tic;

switch lower(noiseType)
    
    case 'gaussian'
        noise = noiseAmplitude * randn(numPoints, 1);
        fprintf('  Type: Gaussian (Normal distribution)\n');
        
    case 'uniform'
        noise = noiseAmplitude * (2 * rand(numPoints, 1) - 1);
        fprintf('  Type: Uniform distribution\n');
        
    case 'saltpepper'
        noise = zeros(numPoints, 1);
        numAffected = round(saltPepperDensity * numPoints);
        affectedIdx = randperm(numPoints, numAffected);
        halfIdx = round(numAffected / 2);
        noise(affectedIdx(1:halfIdx)) = noiseAmplitude * 3;
        noise(affectedIdx(halfIdx+1:end)) = -noiseAmplitude * 3;
        fprintf('  Type: Salt & Pepper (%.1f%% affected)\n', saltPepperDensity * 100);
        
    case 'poisson'
        scaleFactor = noiseAmplitude / sqrt(abs(dataMean) + 1);
        noise = scaleFactor * (poissrnd(abs(originalData) + 1) - abs(originalData) - 1);
        fprintf('  Type: Poisson (signal-dependent)\n');
        
    case 'pink'
        whiteNoise = randn(numPoints, 1);
        N = numPoints;
        f = (1:N)';
        pinkFilter = 1 ./ sqrt(f);
        pinkFilter(1) = 0;
        fftNoise = fft(whiteNoise);
        pinkFFT = fftNoise .* pinkFilter;
        pinkNoise = real(ifft(pinkFFT));
        noise = noiseAmplitude * (pinkNoise / std(pinkNoise));
        fprintf('  Type: Pink noise (1/f spectrum)\n');
        
    case 'regional'
        X = dataMatrix(:, 1);
        Y = dataMatrix(:, 2);
        Xn = (X - min(X)) / (max(X) - min(X) + eps);
        Yn = (Y - min(Y)) / (max(Y) - min(Y) + eps);
        freq = 1 / regionalWavelength;
        phase1 = 2 * pi * rand();
        phase2 = 2 * pi * rand();
        regionalTrend = sin(2*pi*freq*Xn + phase1) .* cos(2*pi*freq*Yn + phase2);
        regionalTrend = regionalTrend + 0.5 * sin(4*pi*freq*Xn + phase2);
        noise = noiseAmplitude * (regionalTrend / std(regionalTrend));
        fprintf('  Type: Regional trend noise\n');
        
    otherwise
        error('Unknown noise type: %s', noiseType);
end

fprintf('  Generated in %.2f sec\n', toc);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% APPLY NOISE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

noisyData = originalData + noise;
dataMatrix(:, dataColumn) = noisyData;

actualNoiseStd = std(noise);
snr = 10 * log10(var(originalData) / var(noise));

fprintf('\nNoise Statistics:\n');
fprintf('  Noise Std:    %.4f\n', actualNoiseStd);
fprintf('  Noise %%range: %.2f%%\n', (actualNoiseStd / dataRange) * 100);
fprintf('  SNR:          %.2f dB\n', snr);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% WRITE OUTPUT FILE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('\nWriting: %s\n', outputFile);
fprintf('  Please wait...\n');
tic;

fid = fopen(outputFile, 'w');

% Write header lines (if any)
for i = 1:length(headerLines)
    fprintf(fid, '%s\n', headerLines{i});
end

% Add noise information as comment
fprintf(fid, '/ Noise: %s, %.1f%% of %s, SNR=%.1fdB\n', noiseType, noisePercent, noiseReference, snr);

% Write data - match original format (space-delimited)
formatStr = [repmat('%15.6f ', 1, numCols-1), '%15.6f\n'];
fprintf(fid, formatStr, dataMatrix');

fclose(fid);

writeTime = toc;
fprintf('  Done (%.2f sec)\n', writeTime);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SUMMARY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('\n====================================================\n');
fprintf('  NOISE ADDED SUCCESSFULLY\n');
fprintf('====================================================\n');
fprintf('  Input:      %s\n', inputFile);
fprintf('  Output:     %s\n', outputFile);
fprintf('  Points:     %d\n', numPoints);
fprintf('  Columns:    %d (data in col %d)\n', numCols, dataColumn);
fprintf('  Noise type: %s\n', noiseType);
fprintf('  Noise:      %.1f%% of %s\n', noisePercent, noiseReference);
fprintf('  SNR:        %.2f dB\n', snr);
fprintf('  Total time: %.2f sec\n', readTime + writeTime);
fprintf('====================================================\n');
