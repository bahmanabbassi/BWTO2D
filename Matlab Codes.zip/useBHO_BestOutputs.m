function useBHO_BestOutputs()
%useBHO_BestOutputs - Use stored outputs from best BHO iteration instead of re-running
%
% This function takes the outputs stored from the best iteration of Lineaments_Auto7
% and sets them as global variables, replacing what BHO_Lines_4 would have done.
% This ensures the final results match exactly what was optimized.

global BHO_BestOutputs
global plotH1_rgb plotH1_rgb_Deep plotH1_rgb_Shallow
global XI_line_Auto YI_line_Auto
global grm2_vector_Auto
global Result3D_Auto
global Spectral_PCA_Features_Matrix_Auto
global densityMap_Auto

% Check if best outputs are available
if ~exist('BHO_BestOutputs', 'var') || isempty(BHO_BestOutputs) || ~BHO_BestOutputs.has_outputs
    error('BHO_BestOutputs not available. Cannot use stored outputs.');
end

% Extract stored outputs
plotH1_rgb_cropped = BHO_BestOutputs.plotH1_rgb_cropped;
plotH0 = BHO_BestOutputs.plotH0;
grm2_vector = BHO_BestOutputs.grm2_vector;
num_features = BHO_BestOutputs.Number_of_Features_used_for_Lineaments_Detection;

% Set coordinate grids as globals
XI_line_Auto = BHO_BestOutputs.XI_line_Auto;
YI_line_Auto = BHO_BestOutputs.YI_line_Auto;

% Set Result3D_Auto from best iteration for CWT display
if isfield(BHO_BestOutputs, 'Result3D_Auto') && ~isempty(BHO_BestOutputs.Result3D_Auto)
    clear global Result3D_Auto
    global Result3D_Auto
    Result3D_Auto = BHO_BestOutputs.Result3D_Auto;
else
    clear global Result3D_Auto
    global Result3D_Auto
    Result3D_Auto = [];
end

% Set Spectral_PCA_Features_Matrix_Auto from best iteration for Selected Components display
if isfield(BHO_BestOutputs, 'Spectral_PCA_Features_Matrix_Auto') && ~isempty(BHO_BestOutputs.Spectral_PCA_Features_Matrix_Auto)
    clear global Spectral_PCA_Features_Matrix_Auto
    global Spectral_PCA_Features_Matrix_Auto
    Spectral_PCA_Features_Matrix_Auto = BHO_BestOutputs.Spectral_PCA_Features_Matrix_Auto;
else
    clear global Spectral_PCA_Features_Matrix_Auto
    global Spectral_PCA_Features_Matrix_Auto
    Spectral_PCA_Features_Matrix_Auto = [];
end

% Create plotH1_rgb (all lineaments) - this is the main output
% Re-stack lineaments properly for display (using AND logic) from stored plotH0
% This is ONLY for display - GRM already used the original plotH1_rgb_cropped
% plotH0 format: lineaments = false (0), background = true (1)
% To stack lineaments (union): use AND operation, initialize to all background (true)
clear global plotH1_rgb
global plotH1_rgb
if num_features > 0
    % Re-stack properly for display using AND logic
    plotH1_stacked_display = true(size(plotH0, 1), size(plotH0, 2));
    for n = 1:num_features
        plotH1_stacked_display = plotH1_stacked_display & plotH0(:,:,n);  % AND: union of lineaments
    end
    
    % Apply cropping
    global YI_Real_Ratio
    if isempty(YI_Real_Ratio) || YI_Real_Ratio <= 0
        YI_Real_Ratio = 1.0;
    end
    cropPixels1 = round(0.025 * YI_Real_Ratio * size(plotH1_stacked_display, 1));
    cropPixels2 = round(0.025 * size(plotH1_stacked_display, 2));
    cropPixels1 = min(cropPixels1, floor(size(plotH1_stacked_display, 1)/2)-1);
    cropPixels2 = min(cropPixels2, floor(size(plotH1_stacked_display, 2)/2)-1);
    if cropPixels1 < 0, cropPixels1 = 0; end
    if cropPixels2 < 0, cropPixels2 = 0; end
    
    plotH1_rgb_display = im2double(plotH1_stacked_display);
    % Set border pixels to 1.0 (white background in original format)
    if cropPixels1 > 0
        plotH1_rgb_display(1:cropPixels1, :) = 1.0;
        plotH1_rgb_display(end-cropPixels1+1:end, :) = 1.0;
    end
    if cropPixels2 > 0
        plotH1_rgb_display(:, 1:cropPixels2) = 1.0;
        plotH1_rgb_display(:, end-cropPixels2+1:end) = 1.0;
    end
    
    % Invert for display: lineaments=1.0 (black), background=0.0 (white)
    plotH1_rgb = imcomplement(plotH1_rgb_display);
    
    % Calculate densityMap_Auto from the original plotH1_rgb_cropped (best iteration result)
    % This uses the OR-stacked lineaments which should have more lineaments than the re-stacked version
    clear global densityMap_Auto
    global densityMap_Auto
    % Use plotH1_rgb_cropped (original format: lineaments = 0.0, background = 1.0)
    % Invert to get display format (lineaments = 1.0, background = 0.0) for density calculation
    plotH1_rgb2 = imcomplement(plotH1_rgb_cropped);  % Invert: lineaments = 1.0, background = 0.0
    
    % Convert to grayscale (plotH1_rgb is already 2D double, but handle both cases)
    if ndims(plotH1_rgb2) == 3
        grayImage = rgb2gray(plotH1_rgb2);
    else
        grayImage = plotH1_rgb2;  % Already grayscale (2D double)
    end
    
    % Convert grayscale to binary
    binaryImage = imbinarize(grayImage);
    
    % Define the window size
    windowSize = 3;
    filterKernel = ones(windowSize, windowSize); % Moving window kernel
    
    % Calculate density map using convolution
    densityMap_Auto = conv2(double(binaryImage), filterKernel, 'same');
    
    % Normalize the density map
    densityMap_Auto = densityMap_Auto / (windowSize^2);
    
    % Do NOT complement - keep high values for high density
    % High convolution values (dense lineaments) → high values → appear as red/yellow (high density)
    % Low convolution values (sparse lineaments) → low values → appear as blue (low density)
    % This is the intuitive interpretation: red = high density, blue = low density
    % densityMap_Auto = imcomplement(densityMap_Auto);  % Removed - keep intuitive mapping
else
    plotH1_rgb = [];
    clear global densityMap_Auto
    global densityMap_Auto
    densityMap_Auto = [];
end

% Create deep/shallow classifications based on grm2_vector
if ~isempty(grm2_vector) && num_features > 0
    avg_grm2 = mean(grm2_vector);
    
    % Deep lineaments (grm2 > average)
    % Note: plotH0 is stored as imcomplement(plotH00_final), so it has:
    %   lineaments = false (0), background = true (1)
    % To stack lineaments (union): use AND operation, initialize to all background (true)
    plotH1_Deep = true(size(plotH0, 1), size(plotH0, 2));
    for n = 1:num_features
        if grm2_vector(n) > avg_grm2
            plotH1_Deep = plotH1_Deep & plotH0(:,:,n);  % AND: union of lineaments
        end
    end
    
    % Shallow lineaments (grm2 <= average)
    % Same approach: AND operation for union of lineaments
    plotH1_Shallow = true(size(plotH0, 1), size(plotH0, 2));
    for n = 1:num_features
        if grm2_vector(n) <= avg_grm2
            plotH1_Shallow = plotH1_Shallow & plotH0(:,:,n);  % AND: union of lineaments
        end
    end
    
    % Apply same cropping as in BHO_Lines_4
    global YI_Real_Ratio
    if isempty(YI_Real_Ratio) || YI_Real_Ratio <= 0
        YI_Real_Ratio = 1.0;
    end
    
    cropPixels1 = round(0.025 * YI_Real_Ratio * size(plotH1_Deep, 1));
    cropPixels2 = round(0.025 * size(plotH1_Deep, 2));
    cropPixels1 = min(cropPixels1, floor(size(plotH1_Deep, 1)/2)-1);
    cropPixels2 = min(cropPixels2, floor(size(plotH1_Deep, 2)/2)-1);
    if cropPixels1 < 0, cropPixels1 = 0; end
    if cropPixels2 < 0, cropPixels2 = 0; end
    
    % Set Deep lineaments
    clear global plotH1_rgb_Deep
    global plotH1_rgb_Deep
    plotH1_rgb_Deep = im2double(plotH1_Deep);
    % Set border pixels to 1.0 (white background in original format)
    if cropPixels1 > 0
        plotH1_rgb_Deep(1:cropPixels1, :) = 1.0;  % White border (background)
        plotH1_rgb_Deep(end-cropPixels1+1:end, :) = 1.0;  % White border (background)
    end
    if cropPixels2 > 0
        plotH1_rgb_Deep(:, 1:cropPixels2) = 1.0;  % White border (background)
        plotH1_rgb_Deep(:, end-cropPixels2+1:end) = 1.0;  % White border (background)
    end
    % Invert for display: lineaments=1.0 (black), background=0.0 (white)
    plotH1_rgb_Deep = imcomplement(plotH1_rgb_Deep);
    
    % Set Shallow lineaments
    clear global plotH1_rgb_Shallow
    global plotH1_rgb_Shallow
    plotH1_rgb_Shallow = im2double(plotH1_Shallow);
    % Set border pixels to 1.0 (white background in original format)
    if cropPixels1 > 0
        plotH1_rgb_Shallow(1:cropPixels1, :) = 1.0;  % White border (background)
        plotH1_rgb_Shallow(end-cropPixels1+1:end, :) = 1.0;  % White border (background)
    end
    if cropPixels2 > 0
        plotH1_rgb_Shallow(:, 1:cropPixels2) = 1.0;  % White border (background)
        plotH1_rgb_Shallow(:, end-cropPixels2+1:end) = 1.0;  % White border (background)
    end
    % Invert for display: lineaments=1.0 (black), background=0.0 (white)
    plotH1_rgb_Shallow = imcomplement(plotH1_rgb_Shallow);
    
    % Set grm2_vector_Auto for compatibility
    clear global grm2_vector_Auto
    global grm2_vector_Auto
    grm2_vector_Auto = grm2_vector;
else
    % If no grm2_vector, just set empty deep/shallow
    clear global plotH1_rgb_Deep plotH1_rgb_Shallow
    global plotH1_rgb_Deep plotH1_rgb_Shallow
    plotH1_rgb_Deep = [];
    plotH1_rgb_Shallow = [];
    grm2_vector_Auto = [];
end

% Note: Shapefile generation and density maps would need to be created separately
% if needed, but the core lineament maps are now set from the best iteration

end

