% Temporary diagnostic probe: reproduces the GRM block of Lineaments_Auto7.m
% to check (1) ind2sub single-output behaviour and (2) how GRM relates to
% total detected lineament length.

fprintf('--- 1. ind2sub with a single output ---\n');
sz  = [400 400];
idx = [1; 2; 401; 5000; 12345];
one_out = ind2sub(sz, idx);
[r2, c2] = ind2sub(sz, idx);
fprintf('input linear idx : %s\n', mat2str(idx'));
fprintf('ind2sub 1 output : %s\n', mat2str(one_out'));
fprintf('ind2sub 2 outputs: rows %s / cols %s\n', mat2str(r2'), mat2str(c2'));
fprintf('single output identical to input linear index? %d\n\n', isequal(one_out, idx));

fprintf('--- 2. GRM on a synthetic segment map ---\n');
rng(0);
B = false(400,400);
for k = 1:25
    x1 = randi(400); y1 = randi(400); th = rand*pi;
    t  = 0:0.5:60;
    xs = round(x1 + t*cos(th)); ys = round(y1 + t*sin(th));
    ok = xs>=1 & xs<=400 & ys>=1 & ys<=400;
    B(sub2ind(size(B), ys(ok), xs(ok))) = true;
end

CC   = bwconncomp(B);
segs = CC.PixelIdxList;
segs = segs(cellfun(@numel, segs) >= 2);
N    = numel(segs);
W    = cellfun(@numel, segs)';

% --- (a) exactly as coded in Lineaments_Auto7.m lines 602-634 ---
simA = zeros(N);
for i = 1:N
    for j = i+1:N
        ci = mean(ind2sub(size(B), segs{i}), 1);
        cj = mean(ind2sub(size(B), segs{j}), 1);
        v  = 1 / (1 + norm(ci - cj));
        simA(i,j) = v; simA(j,i) = v;
    end
end
GRM_asCoded = 0;
for s = 1:N
    row = simA(s,:); row(s) = Inf;
    h = min(row); if isinf(h), h = 0; end
    GRM_asCoded = GRM_asCoded + W(s)*(1 - h);
end

% --- (b) true 2-D centroid distance, min() as coded vs max() as in paper ---
cen = zeros(N,2);
for i = 1:N
    [rr, cc] = ind2sub(size(B), segs{i});
    cen(i,:) = [mean(rr) mean(cc)];
end
simB = zeros(N);
for i = 1:N
    for j = i+1:N
        v = 1 / (1 + norm(cen(i,:) - cen(j,:)));
        simB(i,j) = v; simB(j,i) = v;
    end
end
GRM_min = 0; GRM_max = 0;
for s = 1:N
    row = simB(s,:); row(s) = Inf;
    GRM_min = GRM_min + W(s)*(1 - min(row));
    row2 = simB(s,:); row2(s) = -Inf;
    GRM_max = GRM_max + W(s)*(1 - max(row2));
end

total = sum(W);
fprintf('segments N                      = %d\n', N);
fprintf('total segment pixels sum(w_P)   = %d\n', total);
fprintf('GRM as coded (min, linear idx)  = %.4f   ratio = %.6f\n', GRM_asCoded, GRM_asCoded/total);
fprintf('GRM 2D centroid, min()          = %.4f   ratio = %.6f\n', GRM_min, GRM_min/total);
fprintf('GRM 2D centroid, max() [paper]  = %.4f   ratio = %.6f\n', GRM_max, GRM_max/total);

fprintf('\n--- 3. Correlation of as-coded GRM with total length over random maps ---\n');
g = zeros(30,1); tl = zeros(30,1);
for trial = 1:30
    rng(trial);
    Bt = false(400,400);
    for k = 1:randi([5 40])
        x1 = randi(400); y1 = randi(400); th = rand*pi;
        t  = 0:0.5:(20+rand*80);
        xs = round(x1 + t*cos(th)); ys = round(y1 + t*sin(th));
        ok = xs>=1 & xs<=400 & ys>=1 & ys<=400;
        Bt(sub2ind(size(Bt), ys(ok), xs(ok))) = true;
    end
    cc2 = bwconncomp(Bt);
    sg  = cc2.PixelIdxList; sg = sg(cellfun(@numel, sg) >= 2);
    n   = numel(sg); w = cellfun(@numel, sg)';
    if n == 0, continue; end
    sm = zeros(n);
    for i = 1:n
        for j = i+1:n
            ci = mean(ind2sub(size(Bt), sg{i}), 1);
            cj = mean(ind2sub(size(Bt), sg{j}), 1);
            v  = 1/(1+norm(ci-cj)); sm(i,j)=v; sm(j,i)=v;
        end
    end
    gv = 0;
    for s = 1:n
        row = sm(s,:); row(s) = Inf;
        h = min(row); if isinf(h), h = 0; end
        gv = gv + w(s)*(1-h);
    end
    g(trial) = gv; tl(trial) = sum(w);
end
keep = tl > 0;
rr2 = corrcoef(g(keep), tl(keep));
fprintf('Pearson r( GRM_as_coded , total lineament pixels ) = %.8f over %d maps\n', rr2(1,2), sum(keep));
fprintf('max relative deviation of GRM from total length    = %.6f percent\n', 100*max(abs(g(keep)-tl(keep))./tl(keep)));
