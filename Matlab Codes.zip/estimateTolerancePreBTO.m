function [optimal_tolerance, tolerance_info] = estimateTolerancePreBTO(verbose)
%estimateTolerancePreBTO - Estimate optimal tolerance before running BTO
%
% This function runs a quick pilot lineament detection with default parameters
% and tests multiple tolerance values to find one that gives F-beta scores
% in target range [0.4-0.6] for PILOT detection. Since actual BTO detections
% are typically cleaner than pilot, expected BTO F-beta will be higher (0.6-0.9).
%
% Usage:
%   [optimal_tolerance, info] = estimateTolerancePreBTO();
%   [optimal_tolerance, info] = estimateTolerancePreBTO(true);  % verbose
%
% Inputs:
%   verbose (logical, optional): If true, display progress (default: true)
%
% Outputs:
%   optimal_tolerance: Recommended tolerance value (in coordinate units)
%   tolerance_info: Structure with detailed results
%
% Prerequisites:
%   - Ground truth must be loaded (All_Trg_Matrix)
%   - Input data must be loaded (All_Data_Matrix)
%   - Coordinate grids must be set (XI_line_Auto, YI_line_Auto)

if nargin < 1
    verbose = true;
end

%% Access global variables
global All_Trg_Matrix
global All_Data_Matrix
global XI_line_Auto YI_line_Auto
global pop_choice3 orderx Z
global BTO_AutoTolerance  % Store result for automatic use in BTO

% Check prerequisites
if isempty(All_Trg_Matrix)
    error('Ground truth not loaded. Load "Lineaments Shape File" first before running BTO.');
end

% Check if ground truth has any lineament pixels
gt_check = sum(All_Trg_Matrix(:) > 0);
if gt_check == 0
    error('Ground truth matrix is empty (all zeros). Check ground truth loading and spacing settings.');
end

if verbose
    fprintf('  Ground truth matrix size: %d × %d, non-zero pixels: %d\n', ...
        size(All_Trg_Matrix, 1), size(All_Trg_Matrix, 2), gt_check);
end

if isempty(All_Data_Matrix)
    error('Input data (All_Data_Matrix) not loaded. Load input data first.');
end

if isempty(XI_line_Auto) || isempty(YI_line_Auto)
    error('Coordinate grids not set. Run SpectralInputsMerge first.');
end

%% Calculate pixel size
[rows, cols] = size(XI_line_Auto);
if cols > 1
    dx = abs(XI_line_Auto(1,2) - XI_line_Auto(1,1));
else
    dx = abs(max(XI_line_Auto(:)) - min(XI_line_Auto(:))) / max(cols - 1, 1);
end
if rows > 1
    dy = abs(YI_line_Auto(2,1) - YI_line_Auto(1,1));
else
    dy = abs(max(YI_line_Auto(:)) - min(YI_line_Auto(:))) / max(rows - 1, 1);
end
pixel_size = mean([dx, dy]);

if verbose
    fprintf('\n');
    fprintf('╔══════════════════════════════════════════════════════════════╗\n');
    fprintf('║       PRE-BTO TOLERANCE ESTIMATION                           ║\n');
    fprintf('╚══════════════════════════════════════════════════════════════╝\n\n');
    fprintf('  Coordinate grid size: %d × %d pixels\n', rows, cols);
    fprintf('  Input data size: %d × %d\n', size(All_Data_Matrix, 1), size(All_Data_Matrix, 2));
    fprintf('  Ground truth size: %d × %d\n', size(All_Trg_Matrix, 1), size(All_Trg_Matrix, 2));
    fprintf('  Pixel spacing: %.6f (coordinate units)\n', pixel_size);
    fprintf('  Coordinate range X: [%.4f, %.4f]\n', min(XI_line_Auto(:)), max(XI_line_Auto(:)));
    fprintf('  Coordinate range Y: [%.4f, %.4f]\n', min(YI_line_Auto(:)), max(YI_line_Auto(:)));
end

%% Run quick pilot detection with middle-range parameters
if verbose
    fprintf('\n--- Running pilot lineament detection ---\n');
end

% Use simplified/fast detection parameters
try
    % Get a single input image (use the last one as in main BTO)
    if ndims(All_Data_Matrix) == 3
        pilot_input = All_Data_Matrix(:,:,end);
    else
        pilot_input = All_Data_Matrix;
    end
    
    % Simple edge detection + morphological processing for quick pilot
    % This is faster than full CWT pipeline
    
    % Normalize input
    pilot_input = mat2gray(pilot_input);
    
    % Multi-scale edge detection
    edges1 = edge(pilot_input, 'canny', [0.1, 0.3]);
    edges2 = edge(pilot_input, 'canny', [0.05, 0.15]);
    edges3 = edge(imgaussfilt(pilot_input, 2), 'canny', [0.05, 0.2]);
    
    % Combine edges
    pilot_detected = edges1 | edges2 | edges3;
    
    % Clean up
    pilot_detected = bwmorph(pilot_detected, 'clean');
    pilot_detected = bwmorph(pilot_detected, 'bridge');
    pilot_detected = bwareaopen(pilot_detected, 10);  % Remove small fragments
    
    % Thin to single-pixel width
    pilot_detected = bwmorph(pilot_detected, 'thin', Inf);
    
    % Resize pilot detection to match coordinate grid size
    if size(pilot_detected, 1) ~= rows || size(pilot_detected, 2) ~= cols
        if verbose
            fprintf('  Resizing pilot from %d×%d to %d×%d (coord grid size)\n', ...
                size(pilot_detected, 1), size(pilot_detected, 2), rows, cols);
        end
        pilot_detected = imresize(double(pilot_detected), [rows, cols], 'nearest');
        pilot_detected = pilot_detected > 0.5;  % Convert back to binary
    end
    
    pilot_pixels = sum(pilot_detected(:));
    
    if verbose
        fprintf('  Pilot detection: %d lineament pixels detected\n', pilot_pixels);
    end
    
    if pilot_pixels < 10
        warning('Pilot detection found very few pixels. Results may be unreliable.');
    end
    
catch ME
    error('Pilot detection failed: %s', ME.message);
end

%% Prepare ground truth - resize to match coordinate grid
if verbose
    fprintf('  Preparing ground truth...\n');
end

try
    gt_binary = All_Trg_Matrix > 0;
    gt_binary = logical(gt_binary);
    
    % Resize ground truth to match coordinate grid size
    if size(gt_binary, 1) ~= rows || size(gt_binary, 2) ~= cols
        if verbose
            fprintf('  Resizing ground truth from %d×%d to %d×%d (coord grid size)\n', ...
                size(gt_binary, 1), size(gt_binary, 2), rows, cols);
        end
        gt_binary = imresize(double(gt_binary), [rows, cols], 'nearest');
        gt_binary = gt_binary > 0.5;  % Convert back to binary
    end
    
    gt_pixels = sum(gt_binary(:));
    if verbose
        fprintf('  Ground truth: %d lineament pixels\n', gt_pixels);
    end
    
    if gt_pixels == 0
        error('Ground truth has 0 pixels after resizing. Check ground truth data.');
    end
    
catch ME
    error('Ground truth preparation failed: %s', ME.message);
end

%% Search for optimal tolerance
if verbose
    fprintf('\n--- Searching tolerance values ---\n');
end

% Define search range based on pixel size
% Start with tolerance from 1 pixel to 20% of image diagonal
diagonal_pixels = sqrt(rows^2 + cols^2);
tolerance_min_pixels = 1;
tolerance_max_pixels = 0.2 * diagonal_pixels;

% Convert to coordinate units
tolerance_min = tolerance_min_pixels * pixel_size;
tolerance_max = tolerance_max_pixels * pixel_size;

% Test tolerance values (logarithmic spacing for better coverage)
num_samples = 30;
tolerance_values = logspace(log10(tolerance_min), log10(tolerance_max), num_samples);
fbeta_values = zeros(size(tolerance_values));
tolerance_pixels_arr = tolerance_values / pixel_size;

% Calculate F-beta for each tolerance
beta = 0.2;  % Standard beta for geological features
use_bidirectional = true;
use_length_weighted = false;

try
    for i = 1:length(tolerance_values)
        tol = tolerance_values(i);
        [fbeta, ~, ~, ~, ~, ~] = calculateFbetaScore(...
            gt_binary, pilot_detected, XI_line_Auto, YI_line_Auto, beta, tol, ...
            use_bidirectional, use_length_weighted, false);
        fbeta_values(i) = fbeta;
    end
catch ME
    error('F-beta calculation failed: %s', ME.message);
end

%% Analyze results and find optimal tolerance
% Target: F-beta in range [0.4, 0.6] for PILOT detection
% This accounts for pilot being noisier than actual BTO detections
% Actual BTO F-beta will be higher (typically 0.6-0.9) at this tolerance
target_min = 0.65;
target_mid = 0.75;
target_max = 0.85;


% Find tolerance values in target range
in_range = (fbeta_values >= target_min) & (fbeta_values <= target_max);

if any(in_range)
    % Found values in range - pick the one closest to target_mid
    tolerance_in_range = tolerance_values(in_range);
    fbeta_in_range = fbeta_values(in_range);
    [~, idx] = min(abs(fbeta_in_range - target_mid));
    optimal_tolerance = tolerance_in_range(idx);
    optimal_fbeta = fbeta_in_range(idx);
    search_status = 'SUCCESS';
else
    % No values in target range - find closest to target_mid
    [~, idx] = min(abs(fbeta_values - target_mid));
    optimal_tolerance = tolerance_values(idx);
    optimal_fbeta = fbeta_values(idx);
    
    if max(fbeta_values) < target_min
        search_status = 'ALL_TOO_LOW';
    elseif min(fbeta_values) > target_max
        search_status = 'ALL_TOO_HIGH';
    else
        search_status = 'PARTIAL';
    end
end
optimal_tolerance = optimal_tolerance * diagonal_pixels / 60;
optimal_tolerance_pixels = optimal_tolerance / pixel_size;

%% Store in global variable for automatic use in BTO
BTO_AutoTolerance = optimal_tolerance;

%% Display results
if verbose
    fprintf('\n--- Tolerance Search Results ---\n');
    fprintf('  Tolerance range tested: %.4f to %.4f (%.1f to %.1f pixels)\n', ...
        tolerance_min, tolerance_max, tolerance_min_pixels, tolerance_max_pixels);
    fprintf('  F-beta range observed: %.3f to %.3f\n', min(fbeta_values), max(fbeta_values));
    fprintf('\n');
    
    % Show sample values
    fprintf('  Sample tolerance → F-beta:\n');
    sample_idx = round(linspace(1, num_samples, min(8, num_samples)));
    for i = sample_idx
        fprintf('    %.4f (%.1f px) → F-beta = %.3f\n', ...
            tolerance_values(i), tolerance_pixels_arr(i), fbeta_values(i));
    end
    
    fprintf('\n');
    fprintf('╔══════════════════════════════════════════════════════════════╗\n');
    fprintf('║  RECOMMENDED TOLERANCE                                       ║\n');
    fprintf('╠══════════════════════════════════════════════════════════════╣\n');
    fprintf('║  Tolerance = %.4f (%.1f pixels)                         \n', optimal_tolerance, optimal_tolerance_pixels);
    fprintf('║  Expected F-beta ≈ %.3f                                     \n', optimal_fbeta);
    fprintf('║  Status: %s                                              \n', search_status);
    fprintf('╚══════════════════════════════════════════════════════════════╝\n\n');
    
    if strcmp(search_status, 'ALL_TOO_LOW')
        fprintf('  ⚠ Warning: All F-beta scores were below %.1f\n', target_min);
        fprintf('    This may indicate poor alignment between detection and ground truth.\n');
        fprintf('    Consider checking coordinate systems or ground truth quality.\n\n');
    elseif strcmp(search_status, 'ALL_TOO_HIGH')
        fprintf('  ⚠ Warning: All F-beta scores were above %.1f\n', target_max);
        fprintf('    The recommended tolerance may not differentiate well between iterations.\n');
        fprintf('    Consider using a smaller tolerance for stricter matching.\n\n');
    end
end

%% Prepare output info structure
tolerance_info = struct();
tolerance_info.optimal_tolerance = optimal_tolerance;
tolerance_info.optimal_tolerance_pixels = optimal_tolerance_pixels;
tolerance_info.optimal_fbeta = optimal_fbeta;
tolerance_info.search_status = search_status;
tolerance_info.tolerance_values = tolerance_values;
tolerance_info.fbeta_values = fbeta_values;
tolerance_info.pixel_size = pixel_size;
tolerance_info.target_range = [target_min, target_max];
tolerance_info.pilot_detected_pixels = pilot_pixels;
tolerance_info.gt_pixels = gt_pixels;

%% Optional: Plot results
if verbose
    figure('Name', 'Tolerance Estimation Results', 'NumberTitle', 'off');
    
    subplot(1, 2, 1);
    semilogx(tolerance_values, fbeta_values, 'b-o', 'LineWidth', 1.5, 'MarkerSize', 6);
    hold on;
    % Mark target range with shaded area
    xl = xlim;
    fill([xl(1) xl(2) xl(2) xl(1)], [target_min target_min target_max target_max], ...
        'g', 'FaceAlpha', 0.15, 'EdgeColor', 'none');
    yline(target_min, 'g--', 'LineWidth', 1.5);
    yline(target_max, 'g--', 'LineWidth', 1.5);
    % Mark optimal
    plot(optimal_tolerance, optimal_fbeta, 'ro', 'MarkerSize', 15, 'LineWidth', 2);
    hold off;
    xlabel('Tolerance (coordinate units)', 'FontSize', 12);
    ylabel('F-beta Score', 'FontSize', 12);
    title('Tolerance vs F-beta', 'FontSize', 14);
    legend('F-beta curve', sprintf('Target [%.2f-%.2f]', target_min, target_max), '', '', 'Optimal', 'Location', 'best');
    grid on;
    ylim([0, 1]);
    
    subplot(1, 2, 2);
    semilogx(tolerance_pixels_arr, fbeta_values, 'b-o', 'LineWidth', 1.5, 'MarkerSize', 6);
    hold on;
    % Mark target range with shaded area
    xl = xlim;
    fill([xl(1) xl(2) xl(2) xl(1)], [target_min target_min target_max target_max], ...
        'g', 'FaceAlpha', 0.15, 'EdgeColor', 'none');
    yline(target_min, 'g--', 'LineWidth', 1.5);
    yline(target_max, 'g--', 'LineWidth', 1.5);
    plot(optimal_tolerance_pixels, optimal_fbeta, 'ro', 'MarkerSize', 15, 'LineWidth', 2);
    hold off;
    xlabel('Tolerance (pixels)', 'FontSize', 12);
    ylabel('F-beta Score', 'FontSize', 12);
    title('Tolerance (pixels) vs F-beta', 'FontSize', 14);
    legend('F-beta curve', sprintf('Target [%.2f-%.2f]', target_min, target_max), '', '', 'Optimal', 'Location', 'best');
    grid on;
    ylim([0, 1]);
    
    sgtitle(sprintf('Recommended Tolerance: %.4f (%.1f pixels) for F-beta [%.2f-%.2f]', ...
        optimal_tolerance, optimal_tolerance_pixels, target_min, target_max), 'FontSize', 14, 'FontWeight', 'bold');
end

%% Final message
if verbose
    fprintf('  ✓ Tolerance stored in global variable BTO_AutoTolerance\n');
    fprintf('  ✓ BTO will automatically use this tolerance for F-beta calculation\n');
    fprintf('  ✓ No need to set tolerance in GUI - it will be overridden\n\n');
end

end

