function [BW_object, plotSkel] = getFaultDetection(z, z_orig, SLC)
% getFaultDetection - Thresholding and morphological cleanup stage of Section 1.3.
%
% Turns the step-filter response D_i(x,y) into the binary candidate map
% B_i(x,y). Hysteresis thresholding with region growing is done by the
% binarize sub-function below, after which the map is cleaned with the fixed
% morphological constants quoted in the paper: components under 10 pixels are
% removed, single-pixel gaps are bridged, and dead-end branches up to 50 pixels
% are pruned. Those three constants are identical for every dataset and every
% optimization iteration; only SLC is tuned.
%
% Inputs:
%   z        (2D matrix): Step-filter response, the map to be thresholded.
%   z_orig   (2D matrix): The feature map before filtering, used only as the
%                         backdrop of the overlay image.
%   SLC      (double) [xi]: Global confidence threshold in percent, Table 1.
%                         Larger values admit more candidate pixels, because
%                         the cut is taken at the (100 - SLC)th percentile.
%
% Outputs:
%   BW_object (binary matrix): The cleaned candidate map B_i, true on patterns.
%   plotSkel  (RGB matrix):    Overlay of the detections on the input map,
%                              coloured from blue for weak to red for strong.
%
% Modified from:
% Panagiotakis, C., 2025. Filters for Curvilinear Enhancement. MATLAB Central File Exchange. 
% https://www.mathworks.com/matlabcentral/fileexchange/46541-filters-for-curvilinear-enhancement (accessed August 1, 2025).



% Suppress irrelevant warnings for a cleaner output.
warning('off','all');

% --- Step 1: Retained from the original implementation; leaves z unchanged ---
rotI = z; z = rotI;
clear rotI;

% --- Step 2: Hysteresis thresholding and morphological cleanup ---
[BW] = binarize(z, SLC);
BW_object = BW;       % Raw candidate map before cleaning

% The three constants below are fixed for all datasets and iterations.
BW_object = bwareaopen(BW_object, 10);      % Drop components under 10 pixels
BW_object = bwmorph(BW_object,'bridge');    % Close single-pixel gaps
BW_object = bwmorph(BW_object,'spur',50);   % Prune dead-end branches up to 50 pixels

% --- Step 3: Grayscale backdrop for the overlay image ---
normal = max(z(:)); % Normalization factor from the processed data for fault coloring.
par    = max(z_orig(:)) - min(z_orig(:)); % Range of original data for background scaling.
plotH(:,:,1) = (z_orig - min(z_orig(:))) / par; % Red channel
plotH(:,:,2) = plotH(:,:,1); % Green channel
plotH(:,:,3) = plotH(:,:,1); % Blue channel
clear par;

% --- Step 4: Create Overlay Visualization ---
% Overlay the cleaned fault pixels onto the grayscale background image.
% The color of the fault varies from blue (low intensity) to red (high intensity).
for i=1:size(BW_object,1)
  for j=1:size(BW_object,2)
    % Check if the current pixel is part of a detected fault.
    if BW_object(i,j)
      plotH(i,j,1) = abs(z(i,j))/normal;      % Red component increases with fault intensity.
      plotH(i,j,2) = 0;                       % Green component is set to zero for faults.
      plotH(i,j,3) = 1 - abs(z(i,j))/normal;  % Blue component decreases with fault intensity.
    end
  end
end
% Assign the final overlay image to the output variable.
plotSkel = plotH;

% --- Step 5: Create Alternative Visualization (White Background) ---
% NOTE: This visualization is created but not returned by the function.
% It is useful for displaying faults without the underlying data.

% Create a blank white canvas.
plotH(:, :, 1) = ones(size(z_orig, 1), size(z_orig, 2)); % Red channel to 1.
plotH(:, :, 2) = ones(size(z_orig, 1), size(z_orig, 2)); % Green channel to 1.
plotH(:, :, 3) = ones(size(z_orig, 1), size(z_orig, 2)); % Blue channel to 1.

% Overlay faults onto the white background using the same coloring scheme.
for i = 1:size(BW, 1)
    for j = 1:size(BW, 2)
        if BW(i, j) > 0 % If the pixel belongs to a detected fault.
            plotH(i, j, 1) = abs(z(i, j)) / normal;         % Update red channel.
            plotH(i, j, 2) = 0;                             % Set green channel to 0.
            plotH(i, j, 3) = 1 - abs(z(i, j)) / normal;     % Update blue channel.
        end
    end
end
clear normal BW;
end





function [B1] = binarize(z, SLC)
% binarize - Hysteresis thresholding with region growing, Section 1.3.
%
% Strong candidates are pixels that are both above a high threshold and a
% local ridge maximum. Weaker pixels connected to them are then absorbed, so
% that a trace which fades in places is recovered as one continuous feature
% instead of breaking into fragments.
%
% Inputs:
%   z  (2D matrix):   Step-filter response; larger values are stronger ridges.
%   SLC (double) [xi]: Global confidence threshold in percent. The initial cut
%                      is the (100 - SLC)th percentile of z, so a larger SLC
%                      lowers the cut and admits more candidate pixels.
%
% Outputs:
%   B1 (binary matrix): Raw candidate map, 1 on detected pixels.

% --- Step 1: Analysis margin ---
% A border of about 3 percent of the image dimensions is left unclassified, to
% keep the wraparound of the unpadded FFT and the edge response of the
% directional convolution out of the result. The 3x3 neighbourhood tests below
% also need one pixel of slack at every border.
global YI_Real_Ratio
cropPixels1 = round(0.03 * YI_Real_Ratio * size(z,1), 0);
cropPixels2 = round(0.03 * size(z,2), 0);
apo = round((cropPixels1 + cropPixels2)/2,0);

B = 0 * z;

% --- Step 2: Initial cut at the (100 - SLC)th percentile ---
% Values are sorted from high to low, so taking element 0.01*SLC*N counts SLC
% percent of the pixels down from the maximum.
allD = reshape(z, 1, numel(z));
allD = sort(allD, 'descend');
threshold_idx = round(0.01 * SLC * numel(z));
threshold_idx = max(1, min(threshold_idx, numel(z)));  % Keep the index in range
Tr = allD(threshold_idx);
clear allD;

% --- Step 3: Provisional strong and weak candidates ---
% Ridge position matters as well as amplitude: a pixel above Tr counts as
% strong only if it is among the two largest values in its 3x3 neighbourhood,
% which keeps the detection on the crest of a response rather than its flanks.
for i = apo:size(z, 1) - apo
    for j = apo:size(z, 2) - apo
        temp = reshape(z(i-1:i+1, j-1:j+1), 1, 9);
        st = sort(temp, 'descend');
        if z(i, j) > Tr
            if (z(i, j) >= st(2))
                B(i, j) = 1;   % On the ridge crest: strong candidate
            elseif (z(i, j) == st(4) || z(i, j) == st(3))
                B(i, j) = -1;  % On a flank: weak candidate
            end
        end
    end
end

% --- Step 4: Derive the two hysteresis thresholds from the data ---
% T_high and T_low are the mean responses of the provisional strong and weak
% sets, so both adapt to the amplitude of each feature map rather than being
% fixed in advance.
[Sx, Sy] = find(B == 1);
y = zeros(1, length(Sx));
for i = 1:length(Sx)
    y(i) = z(Sx(i), Sy(i));
end
T_high = mean(y);
clear Sx Sy y;

[Sx, Sy] = find(B == -1);
y = zeros(1, length(Sx));
for i = 1:length(Sx)
    y(i) = z(Sx(i), Sy(i));
end
T_low = mean(y);
clear Sx Sy y;

% --- Step 5: Relabel every pixel against the two thresholds ---
% Labels are -2 for rejected, 1 for strong, -1 for weak, and 0 for pixels that
% lie between the thresholds and are left for the growing step to decide.
B = -2 * ones(size(z));
for i = apo:size(z, 1) - apo
    for j = apo:size(z, 2) - apo
        temp = reshape(z(i-1:i+1, j-1:j+1), 1, 9);
        st = sort(temp, 'descend');
        if z(i, j) <= T_low
            B(i, j) = -2; % Below the low threshold: rejected outright
        elseif z(i, j) >= T_high && (z(i, j) >= st(2))
            B(i, j) = 1;  % Above the high threshold and on a crest
        elseif (z(i, j) < st(4))
            B(i, j) = -1; % Too far off the crest to be part of a trace
        else
            B(i, j) = 0;  % Between the thresholds: decided by growing below
        end
    end
end

% --- Step 6: Region growing ---
% Undecided pixels touching a strong pixel are promoted, and the sweep repeats
% until nothing changes. This is what carries a trace across the stretches
% where its response dips below the high threshold.
while 1
    [Sx, Sy] = find(B == 0);
    change = 0;
    for i = 1:length(Sx)
        x = Sx(i); y = Sy(i);
        [u, v] = find(B(x-1:x+1, y-1:y+1) == 1);
        if ~isempty(u)
            B(x, y) = 1;
            change = change + 1;
        end
    end
    if change == 0
        break; % Nothing was promoted in a full pass, so growth has converged
    end
    clear Sx Sy u v;
end

% --- Step 7: Collapse the labels into a binary map ---
% Everything still negative was rejected or never absorbed.
B(B < 0) = 0;
B1 = B;
clear B apo cropPixels1 cropPixels2 T_high T_low;
end