function [metrics] = calculateStructuralMetrics(real_faults, detected_faults, XI, YI, verbose)
%calculateStructuralMetrics - Calculate structural validation metrics for lineament detection
%
% Based on validation approach from:
% Prabhakaran et al. (2019): "An automated fracture trace detection technique 
% using the complex shearlet transform", Solid Earth, 10, 2137-2166
%
% This function computes:
% 1. P21 (Fracture Intensity) - length per unit area (m^-1 or arc-sec^-1)
% 2. Length-weighted orientation statistics
% 3. Trace length distribution (cumulative frequency)
% 4. Comparison metrics between ground truth and detected lineaments
%
% Inputs:
%   real_faults (2D binary matrix): Ground truth lineaments
%   detected_faults (2D binary matrix): Detected lineaments
%   XI, YI (2D matrices): Coordinate grids in arc-seconds
%   verbose (logical, optional): If true, display metrics to console (default: true)
%
% Outputs:
%   metrics (struct): Structure containing all calculated metrics
%     - P21_truth: Fracture intensity for ground truth (arc-sec^-1)
%     - P21_detected: Fracture intensity for detected (arc-sec^-1)
%     - P21_ratio: Ratio of detected/truth P21
%     - orientations_truth: Length-weighted orientations for ground truth
%     - orientations_detected: Length-weighted orientations for detected
%     - orientation_similarity: Circular correlation coefficient
%     - trace_lengths_truth: Array of trace lengths (pixels)
%     - trace_lengths_detected: Array of trace lengths (pixels)
%     - length_distribution_similarity: KS test statistic (0-1, higher = more similar)

% Set default verbose if not provided
if nargin < 5
    verbose = true;
end

% Ensure inputs are binary
real_faults = logical(real_faults);
detected_faults = logical(detected_faults);

%% Ensure same size (resize if needed)
[rows_gt, cols_gt] = size(real_faults);
[rows_det, cols_det] = size(detected_faults);

if rows_gt ~= rows_det || cols_gt ~= cols_det
    % Resize detected to match ground truth
    detected_faults = imresize(double(detected_faults), [rows_gt, cols_gt], 'nearest') > 0.5;
end

%% Skeletonize both images for fair P21 comparison
% This ensures we compare trace LENGTH, not area (which depends on line thickness)
% Ground truth from digitization may have thick lines (3-5 pixels)
% Detected lineaments are typically single-pixel skeletons
real_faults_skeleton = bwmorph(real_faults, 'thin', Inf);
detected_faults_skeleton = bwmorph(detected_faults, 'thin', Inf);

%% Calculate Grid Spacing and Area
dx = abs(XI(1,2) - XI(1,1));  % Grid spacing in X direction (arc-seconds)
dy = abs(YI(2,1) - YI(1,1));  % Grid spacing in Y direction (arc-seconds)
pixel_size_arcsec = mean([dx, dy]);  % Average pixel size in arc-seconds

% Calculate total area in arc-seconds^2
[img_rows, img_cols] = size(real_faults);
total_area_arcsec2 = (img_rows * pixel_size_arcsec) * (img_cols * pixel_size_arcsec);

% Convert to meters^2 for P21 calculation (1 arc-second ≈ 30.87 meters at equator)
% For geological applications, we'll keep in arc-seconds but note the conversion
arcsec_to_meters = 30.87;  % Approximate conversion at equator
total_area_m2 = total_area_arcsec2 * (arcsec_to_meters^2);

%% 1. Calculate P21 (Fracture Intensity) - Length per Unit Area
% P21 = Total trace length / Total area
% IMPORTANT: Use skeletonized versions for fair comparison (removes line thickness bias)

% Get connected components for SKELETONIZED images
CC_truth = bwconncomp(real_faults_skeleton);
CC_detected = bwconncomp(detected_faults_skeleton);

% Calculate trace lengths using regionprops
stats_truth = regionprops(CC_truth, 'PixelList', 'Perimeter', 'MajorAxisLength');
stats_detected = regionprops(CC_detected, 'PixelList', 'Perimeter', 'MajorAxisLength');

% Calculate total trace length in pixels (from skeletonized = true length)
total_length_truth_pixels = sum(real_faults_skeleton(:));
total_length_detected_pixels = sum(detected_faults_skeleton(:));

% === NEW: Calculate SPATIALLY MATCHED P21 ratio ===
% Use distance transform to find detected pixels near ground truth
% This gives a meaningful ratio: what fraction of truth was detected nearby
% Use larger tolerance since lineaments may not align exactly
tolerance_pixels = 70;  % Match tolerance in pixels (larger for structural matching)

% Dilate ground truth by tolerance to create matching zone
se = strel('disk', tolerance_pixels);
truth_dilated = imdilate(real_faults_skeleton, se);

% Count detected pixels that fall within tolerance of ground truth
matched_detected = detected_faults_skeleton & truth_dilated;
matched_length_pixels = sum(matched_detected(:));

% Also check reverse: ground truth pixels near detected (for recall-like measure)
detected_dilated = imdilate(detected_faults_skeleton, se);
matched_truth = real_faults_skeleton & detected_dilated;
matched_truth_pixels = sum(matched_truth(:));


% Convert to arc-seconds
total_length_truth_arcsec = total_length_truth_pixels * pixel_size_arcsec;
total_length_detected_arcsec = total_length_detected_pixels * pixel_size_arcsec;
matched_length_arcsec = matched_truth_pixels * pixel_size_arcsec;  % Use truth-matched for ratio

% Calculate P21 (length per unit area)
P21_truth = total_length_truth_arcsec / total_area_arcsec2;
P21_detected = total_length_detected_arcsec / total_area_arcsec2;

% Calculate ratio using SPATIALLY MATCHED length
% P21_ratio = fraction of ground truth that was detected (recall-like)
if total_length_truth_pixels > 0
    P21_ratio = matched_truth_pixels / total_length_truth_pixels;
else
    P21_ratio = NaN;
end

%% 2. Length-Weighted Orientation Statistics
% Calculate orientations weighted by trace length (emphasizes major structures)

% Get orientations and lengths for ground truth (using skeletonized)
orientations_truth = [];
lengths_truth = [];
for i = 1:CC_truth.NumObjects
    if length(CC_truth.PixelIdxList{i}) > 1  % Need at least 2 pixels for orientation
        [rows, cols] = ind2sub(size(real_faults_skeleton), CC_truth.PixelIdxList{i});
        % Fit line to get orientation
        coeffs = polyfit(cols, rows, 1);
        angle = atan(coeffs(1)) * (180 / pi);
        if angle < 0
            angle = angle + 180;
        end
        % Weight by trace length (number of pixels)
        trace_length = length(CC_truth.PixelIdxList{i});
        orientations_truth = [orientations_truth; repmat(angle, trace_length, 1)];
        lengths_truth = [lengths_truth; trace_length];
    end
end

% Get orientations and lengths for detected (using skeletonized)
orientations_detected = [];
lengths_detected = [];
for i = 1:CC_detected.NumObjects
    if length(CC_detected.PixelIdxList{i}) > 1
        [rows, cols] = ind2sub(size(detected_faults_skeleton), CC_detected.PixelIdxList{i});
        coeffs = polyfit(cols, rows, 1);
        angle = atan(coeffs(1)) * (180 / pi);
        if angle < 0
            angle = angle + 180;
        end
        trace_length = length(CC_detected.PixelIdxList{i});
        orientations_detected = [orientations_detected; repmat(angle, trace_length, 1)];
        lengths_detected = [lengths_detected; trace_length];
    end
end

% Calculate orientation metrics (0-180° range for consistency with Old_metrics.m)
% Convert orientations to 0-180° range (each orientation counted once)
if ~isempty(orientations_truth) && ~isempty(orientations_detected)
    % Ensure orientations are in 0-180° range
    orientations_truth_180 = mod(orientations_truth, 180);
    orientations_detected_180 = mod(orientations_detected, 180);
    
    % Use mean resultant length as similarity measure (for backward compatibility)
    % For each dataset, calculate mean orientation
    mean_orient_truth = circ_mean(deg2rad(orientations_truth));
    mean_orient_detected = circ_mean(deg2rad(orientations_detected));
    
    % Calculate circular variance (1 - mean resultant length)
    % Lower variance = more concentrated orientations
    R_truth = abs(mean(exp(1i * deg2rad(orientations_truth))));
    R_detected = abs(mean(exp(1i * deg2rad(orientations_detected))));
    
    % Orientation similarity: compare mean orientations (keep for backward compatibility)
    % Use 1 - normalized angular difference (0-1 scale)
    angle_diff = abs(mean_orient_truth - mean_orient_detected);
    angle_diff = min(angle_diff, 2*pi - angle_diff);  % Wrap to [0, pi]
    orientation_similarity = 1 - (angle_diff / pi);  % 1 = identical, 0 = opposite
    
    % Also consider concentration similarity
    R_similarity = 1 - abs(R_truth - R_detected);
    orientation_similarity = (orientation_similarity + R_similarity) / 2;
    
    % === NEW METRICS: Angular Correlation, Bhattacharyya, JS Divergence ===
    % Create histogram bins (5° intervals, 0-180° range, matching Old_metrics.m)
    binWidth = 5;
    edges_180 = 0:binWidth:180;
    
    % Check if orientations are not empty before calculating
    if ~isempty(orientations_truth_180) && ~isempty(orientations_detected_180) && ...
       length(orientations_truth_180) > 0 && length(orientations_detected_180) > 0
        counts_truth = histcounts(orientations_truth_180, edges_180);
        counts_detected = histcounts(orientations_detected_180, edges_180);
        
        % Normalize to probability distributions
        if sum(counts_truth) > 0 && sum(counts_detected) > 0
            prob_truth = counts_truth / sum(counts_truth);
            prob_detected = counts_detected / sum(counts_detected);
            
            % 1. Angular Correlation (correlation coefficient between distributions)
            if length(prob_truth) == length(prob_detected) && length(prob_truth) > 1
                corr_matrix = corrcoef(prob_truth, prob_detected);
                angular_correlation = corr_matrix(1, 2);
                if isnan(angular_correlation)
                    angular_correlation = 0;  % No correlation if NaN
                end
            else
                angular_correlation = NaN;
            end
        else
            angular_correlation = NaN;
            prob_truth = [];
            prob_detected = [];
        end
    else
        angular_correlation = NaN;
        prob_truth = [];
        prob_detected = [];
    end
    
    % 2. Bhattacharyya Coefficient and JS Divergence
    % Calculate using probability distributions (fallback method that always works)
    if exist('prob_detected', 'var') && exist('prob_truth', 'var') && ...
       ~isempty(prob_detected) && ~isempty(prob_truth) && length(prob_detected) == length(prob_truth) && length(prob_detected) > 0
        epsilon = 1e-10;
        prob_detected_safe = prob_detected + epsilon;
        prob_truth_safe = prob_truth + epsilon;
        prob_mean = (prob_detected_safe + prob_truth_safe) / 2;
        
        % JS Divergence
        js_divergence = 0.5 * sum(prob_detected_safe .* log(prob_detected_safe ./ prob_mean)) + ...
                       0.5 * sum(prob_truth_safe .* log(prob_truth_safe ./ prob_mean));
        
        % Hellinger Distance-based Bhattacharyya Coefficient
        hellinger_dist = sqrt(sum((sqrt(prob_detected) - sqrt(prob_truth)).^2)) / sqrt(2);
        bhattacharyya_coeff = 1 - hellinger_dist;
        
        % Also try calculateAngularSimilarity if available (for comparison, but use fallback values)
        if exist('calculateAngularSimilarity', 'file') == 2 && ~isempty(orientations_detected_180) && ~isempty(orientations_truth_180) && ...
           length(orientations_detected_180) > 0 && length(orientations_truth_180) > 0
            try
                % Suppress console output from calculateAngularSimilarity
                evalc('[js_div_test, bhatt_test, ~] = calculateAngularSimilarity(orientations_detected_180, orientations_truth_180, binWidth)');
                % Use values from calculateAngularSimilarity if they're valid
                if exist('js_div_test', 'var') && exist('bhatt_test', 'var') && ...
                   ~isnan(js_div_test) && ~isnan(bhatt_test)
                    js_divergence = js_div_test;
                    bhattacharyya_coeff = bhatt_test;
                end
            catch
                % Keep fallback values if calculateAngularSimilarity fails
            end
        end
    else
        js_divergence = NaN;
        bhattacharyya_coeff = NaN;
    end
    
else
    orientation_similarity = NaN;
    mean_orient_truth = NaN;
    mean_orient_detected = NaN;
    R_truth = NaN;
    R_detected = NaN;
    angular_correlation = NaN;
    bhattacharyya_coeff = NaN;
    js_divergence = NaN;
end

%% 3. Trace Length Distribution
% Extract trace lengths for cumulative frequency analysis

trace_lengths_truth = lengths_truth;
trace_lengths_detected = lengths_detected;

% If empty, set to empty arrays
if isempty(trace_lengths_truth)
    trace_lengths_truth = [];
end
if isempty(trace_lengths_detected)
    trace_lengths_detected = [];
end

% Calculate cumulative frequency distributions
if ~isempty(trace_lengths_truth) && ~isempty(trace_lengths_detected)
    % Sort lengths
    sorted_truth = sort(trace_lengths_truth);
    sorted_detected = sort(trace_lengths_detected);
    
    % Create common length axis for comparison
    min_len = min([min(sorted_truth), min(sorted_detected)]);
    max_len = max([max(sorted_truth), max(sorted_detected)]);
    
    if max_len > min_len
        len_axis = linspace(min_len, max_len, 100);
        
        % Calculate cumulative frequencies
        cumfreq_truth = arrayfun(@(x) sum(sorted_truth <= x) / length(sorted_truth), len_axis);
        cumfreq_detected = arrayfun(@(x) sum(sorted_detected <= x) / length(sorted_detected), len_axis);
        
        % Kolmogorov-Smirnov test statistic (maximum difference)
        ks_stat = max(abs(cumfreq_truth - cumfreq_detected));
        
        % Convert to similarity (0-1, higher = more similar)
        length_distribution_similarity = 1 - ks_stat;
    else
        length_distribution_similarity = 1.0;  % Both have same single length
    end
else
    length_distribution_similarity = NaN;
    len_axis = [];
    cumfreq_truth = [];
    cumfreq_detected = [];
end

%% 4. Composite Validation Score
% Combine all metrics into a single score (0-1, higher = better match)

% Normalize P21 ratio (closer to 1 is better)
if ~isnan(P21_ratio) && P21_ratio > 0
    % Use inverse of log ratio to penalize both over and under-detection
    P21_score = 1 / (1 + abs(log(P21_ratio)));
else
    P21_score = 0;
end

% Orientation similarity (already 0-1)
if isnan(orientation_similarity)
    orientation_score = 0;
else
    orientation_score = max(0, min(1, orientation_similarity));
end

% Length distribution similarity (already 0-1)
if isnan(length_distribution_similarity)
    length_score = 0;
else
    length_score = max(0, min(1, length_distribution_similarity));
end

%% Package Results
metrics = struct();
metrics.P21_truth = P21_truth;
metrics.P21_detected = P21_detected;
metrics.P21_ratio = P21_ratio;
metrics.P21_score = P21_score;

metrics.orientations_truth = orientations_truth;
metrics.orientations_detected = orientations_detected;
if exist('mean_orient_truth', 'var') && ~isnan(mean_orient_truth)
    metrics.mean_orient_truth = rad2deg(mean_orient_truth);
else
    metrics.mean_orient_truth = NaN;
end
if exist('mean_orient_detected', 'var') && ~isnan(mean_orient_detected)
    metrics.mean_orient_detected = rad2deg(mean_orient_detected);
else
    metrics.mean_orient_detected = NaN;
end
metrics.R_truth = R_truth;
metrics.R_detected = R_detected;
metrics.orientation_similarity = orientation_similarity;
metrics.orientation_score = orientation_score;

metrics.trace_lengths_truth = trace_lengths_truth;
metrics.trace_lengths_detected = trace_lengths_detected;
metrics.length_distribution_similarity = length_distribution_similarity;
metrics.length_score = length_score;

% Store new angular metrics (Angular Correlation, Bhattacharyya, JS Divergence)
if exist('angular_correlation', 'var')
    metrics.angular_correlation = angular_correlation;
else
    metrics.angular_correlation = NaN;
end
if exist('bhattacharyya_coeff', 'var')
    metrics.bhattacharyya_coeff = bhattacharyya_coeff;
else
    metrics.bhattacharyya_coeff = NaN;
end
if exist('js_divergence', 'var')
    metrics.js_divergence = js_divergence;
else
    metrics.js_divergence = NaN;
end

% Additional statistics
metrics.num_traces_truth = CC_truth.NumObjects;
metrics.num_traces_detected = CC_detected.NumObjects;
metrics.total_length_truth_pixels = total_length_truth_pixels;
metrics.total_length_detected_pixels = total_length_detected_pixels;
metrics.total_length_truth_arcsec = total_length_truth_arcsec;
metrics.total_length_detected_arcsec = total_length_detected_arcsec;
metrics.total_area_arcsec2 = total_area_arcsec2;

% Distribution data for plotting
if exist('len_axis', 'var') && ~isempty(len_axis)
    metrics.length_axis = len_axis;
    metrics.cumfreq_truth = cumfreq_truth;
    metrics.cumfreq_detected = cumfreq_detected;
else
    metrics.length_axis = [];
    metrics.cumfreq_truth = [];
    metrics.cumfreq_detected = [];
end

%% Display Results (only if verbose is true)
if verbose
    fprintf('\n=== Structural Validation Metrics ===\n');
    fprintf('Based on Prabhakaran et al. (2019) validation approach\n');
    fprintf('----------------------------------------\n');
    
    % Show skeletonization effect
    original_pixels_truth = sum(real_faults(:));
    original_pixels_detected = sum(detected_faults(:));
    skeleton_pixels_truth = sum(real_faults_skeleton(:));
    skeleton_pixels_detected = sum(detected_faults_skeleton(:));
    
    fprintf('\n0. Skeletonization (for fair P21 comparison):\n');
    fprintf('   Ground Truth:  %d pixels → %d skeleton (%.1fx reduction)\n', ...
        original_pixels_truth, skeleton_pixels_truth, original_pixels_truth/max(skeleton_pixels_truth,1));
    fprintf('   Detected:      %d pixels → %d skeleton (%.1fx reduction)\n', ...
        original_pixels_detected, skeleton_pixels_detected, original_pixels_detected/max(skeleton_pixels_detected,1));

    fprintf('\n1. P21 (Fracture Intensity) - using skeletonized traces:\n');
    fprintf('   Ground Truth:   %.6f arc-sec^-1 (%.2f m^-1)\n', P21_truth, P21_truth * arcsec_to_meters);
    fprintf('   Detected:        %.6f arc-sec^-1 (%.2f m^-1)\n', P21_detected, P21_detected * arcsec_to_meters);
    if ~isnan(P21_ratio)
        fprintf('   Ratio (Det/GT):  %.3f\n', P21_ratio);
        fprintf('   P21 Score:       %.4f (1.0 = perfect match)\n', P21_score);
    end

    fprintf('\n2. Orientation Statistics:\n');
    fprintf('   Number of traces (GT):   %d\n', CC_truth.NumObjects);
    fprintf('   Number of traces (Det):  %d\n', CC_detected.NumObjects);
    if ~isnan(mean_orient_truth)
        fprintf('   Mean orientation (GT):   %.1f°\n', rad2deg(mean_orient_truth));
        fprintf('   Mean orientation (Det):  %.1f°\n', rad2deg(mean_orient_detected));
        fprintf('   Concentration (GT):      %.3f\n', R_truth);
        fprintf('   Concentration (Det):     %.3f\n', R_detected);
        fprintf('   Orientation Similarity: %.4f\n', orientation_similarity);
    end

    fprintf('\n3. Trace Length Distribution:\n');
    if ~isempty(trace_lengths_truth) && ~isempty(trace_lengths_detected)
        fprintf('   Mean length (GT):   %.1f pixels (%.2f arc-sec)\n', ...
            mean(trace_lengths_truth), mean(trace_lengths_truth) * pixel_size_arcsec);
        fprintf('   Mean length (Det):  %.1f pixels (%.2f arc-sec)\n', ...
            mean(trace_lengths_detected), mean(trace_lengths_detected) * pixel_size_arcsec);
        fprintf('   Median length (GT):  %.1f pixels\n', median(trace_lengths_truth));
        fprintf('   Median length (Det): %.1f pixels\n', median(trace_lengths_detected));
        if ~isnan(length_distribution_similarity)
            fprintf('   Distribution Similarity: %.4f (KS-based, 1.0 = identical)\n', length_distribution_similarity);
        end
    end

    fprintf('\n4. Composite Validation Score:\n');
    fprintf('   P21 Score:              %.4f\n', P21_score);
    fprintf('   Orientation Score:      %.4f\n', orientation_score);
    fprintf('   Length Distribution:    %.4f\n', length_score);
    fprintf('========================================\n\n');
end

end

% Helper function for circular mean (if not available)
function mean_angle = circ_mean(angles)
    % Calculate circular mean of angles in radians
    if isempty(angles)
        mean_angle = NaN;
        return;
    end
    mean_angle = angle(mean(exp(1i * angles)));
    if mean_angle < 0
        mean_angle = mean_angle + 2*pi;
    end
end

