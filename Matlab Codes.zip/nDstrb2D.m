function ImD4 = nDstrb2D(ImD0)
%nDstrb2D Dynamic range adjustment, the operator L of Section 1.2.
%
% Description:
%   Brings a feature map to a common dynamic range so that the step filter and
%   the percentile thresholds downstream behave the same way on every map,
%   whatever its original amplitude. The map is centred, rescaled, log
%   transformed and histogram equalized, and the cycle repeats with a stronger
%   rescaling until the standard deviation of the valid nodes lands in
%   [0.25, 0.30], or until 50 iterations have been tried.
%
%   Nodes outside the survey polygon arrive as NaN and are excluded from every
%   statistic and transformation, then restored as NaN on output. They are only
%   set to zero later, immediately before the directional step filtering.
%
% Developed by:
%   Bahman Abbassi (bahman.abbassi@uqat.ca)
%   University of Quebec (UQAT)
%
% Input:
%   ImD0 - A 2D numerical matrix, which can include NaN values.
%
% Output:
%   ImD4 - The transformed 2D matrix with the same dimensions and NaN locations
%          as the input.
%
% Example:
%   % 1. Create a sample 2D matrix (e.g., using peaks)
%   sample_data = peaks(100);
%
%   % 2. Introduce some NaN values to simulate missing data
%   sample_data(20:40, 50:70) = NaN;
%
%   % 3. Apply the distribution adjustment
%   transformed_data = nDstrb2D(sample_data);
%
%   % 4. Visualize the results
%   figure;
%   subplot(1, 2, 1);
%   imagesc(sample_data);
%   title('Original Data');
%   axis image;
%   colorbar;
%
%   subplot(1, 2, 2);
%   imagesc(transformed_data);
%   title('Transformed Data');
%   axis image;
%   colorbar;


% --- Step 1: Input Validation and Initialization ---

    % Ensure the input is a 2D matrix, as the logic is tailored for it.
    if ndims(ImD0) ~= 2
        error('Input must be a 2D matrix.');
    end

    % Check for an all-NaN matrix, which cannot be processed.
    if all(isnan(ImD0(:)))
        error('The input image is all NaN; cannot proceed.');
    end

    % Create a logical mask to identify the locations of valid (non-NaN) numbers.
    % This mask is essential for all subsequent NaN-aware calculations.
    validMask = ~isnan(ImD0);

    % Extract only the valid values into a vector for initial analysis.
    validValues = ImD0(validMask);

    % Calculate initial statistics using only the non-NaN values.
    ImD0_STD = std(validValues);
    ImD0_Mean = mean(validValues);

    % --- Step 2: Control parameters ---
    % The target band is deliberately narrow: matching the spread across maps
    % is what lets one set of hyperparameters apply to all of them.
    max_iterations = 50;
    LT_STD = 0.25;
    HT_STD = 0.30;
    realmin_val = realmin; % Guards against log(0) below

    % --- Step 3: Prepare Data for Iteration ---

    % Center the data by subtracting the mean of valid values.
    ImD0_Centered = ImD0 - ImD0_Mean;
    % Temporarily set original NaN locations to zero in the centered data
    % to prevent NaN propagation in arithmetic operations.
    ImD0_Centered(~validMask) = 0;

    % Initialize the output matrix. If the loop finishes without success,
    % this version will be returned.
    ImD4 = ImD0;

    % Each successive iteration divides by a larger multiple of the original
    % spread, so the transform gets progressively more compressive.
    i = 1:max_iterations;
    weights = 1 ./ (i * ImD0_STD);

    % --- Step 4: Iterate until the spread falls inside the target band ---
    for iter = 1:max_iterations
        % 4a. Rescale by this iteration's weight.
        current_weight = weights(iter);
        ImD1 = ImD0_Centered * current_weight;

        % 4b. Shift everything positive, since the log below is undefined
        %     otherwise. The offset grows with the iteration, which softens
        %     the log compression as the loop proceeds.
        min_val = min(ImD1(validMask));
        std_val = std(ImD1(validMask));
        ImD2 = ImD1 - min_val + (iter * std_val);

        % 4c. Log transform, which pulls in the long tail that a few very
        %     strong anomalies would otherwise impose on the whole map.
        ImD3 = log10(max(ImD2, 0) + realmin_val);

        % 4d. Histogram equalization flattens the distribution, so weak and
        %     strong anomalies get comparable representation.
        ImD4(validMask) = histeq(real(ImD3(validMask))) + realmin_val;

        % 4e/4f. Stop as soon as the spread is inside the target band.
        ImD4_STD = std(ImD4(validMask));

        if (ImD4_STD > LT_STD) && (ImD4_STD < HT_STD)
            break;
        end
    end

    % --- Step 5: Finalize Output ---

    % Restore NaN values to the output matrix in their original locations.
    % This ensures the output has the same data mask as the input.
    ImD4(~validMask) = NaN;
end