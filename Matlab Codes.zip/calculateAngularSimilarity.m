function [js_divergence, hellinger_similarity, metrics] = calculateAngularSimilarity(orientations_extracted, orientations_target, binWidth)
% Calculate orientation distribution similarity metrics (optimized - no F-beta)
%
% Inputs:
%   orientations_extracted - Orientations from extracted lineaments (degrees, 0-180)
%   orientations_target    - Orientations from known faults (degrees, 0-180)
%   binWidth               - Bin width for histogram (default: 10 degrees)
%
% Outputs:
%   js_divergence          - Jensen-Shannon divergence (lower = better; nats)
%   hellinger_similarity   - Hellinger similarity HS = 1-H (higher = better, 0-1)
%   metrics                - Struct with additional info

if nargin < 3, binWidth = 10; end

%% Step 1: Create orientation histograms
edges = 0:binWidth:180;
numBins = length(edges) - 1;

% Count orientations in each bin
counts_extracted = histcounts(orientations_extracted, edges);
counts_target = histcounts(orientations_target, edges);

%% Step 2: Normalize to probabilities (density-independent)
prob_extracted = counts_extracted / sum(counts_extracted);
prob_target = counts_target / sum(counts_target);

%% Step 3: Calculate JS Divergence
epsilon = 1e-10;
prob_extracted_safe = prob_extracted + epsilon;
prob_target_safe = prob_target + epsilon;
prob_mean = (prob_extracted_safe + prob_target_safe) / 2;

js_divergence = 0.5 * sum(prob_extracted_safe .* log(prob_extracted_safe ./ prob_mean)) + ...
                0.5 * sum(prob_target_safe .* log(prob_target_safe ./ prob_mean));

%% Step 4: Hellinger similarity (HS), Eq. (24)
% Classical Bhattacharyya coefficient, kept for reference only:
% BC = sum(sqrt(p.*q)) = 1 - H^2. The paper reports HS = 1 - H instead.
bhattacharyya_coeff_traditional = sum(sqrt(prob_extracted .* prob_target));

% Hellinger distance H (0-1, lower = better)
hellinger_dist = sqrt(sum((sqrt(prob_extracted) - sqrt(prob_target)).^2)) / sqrt(2);

% Hellinger similarity HS = 1 - H (0-1, higher = better); this is the reported metric
hellinger_similarity = 1 - hellinger_dist;

%% Step 5: Package metrics (minimal)
metrics.js_divergence = js_divergence;
metrics.hellinger_similarity = hellinger_similarity;
metrics.bhattacharyya_traditional = bhattacharyya_coeff_traditional;
metrics.hellinger_dist = hellinger_dist;
metrics.binWidth = binWidth;
metrics.numBins = numBins;
metrics.bins_center = edges(1:end-1) + binWidth/2;
metrics.prob_extracted = prob_extracted;
metrics.prob_target = prob_target;

%% Display summary (concise)
fprintf('\n╔════════════════════════════════════════════════════════╗\n');
fprintf('║       ANGULAR SIMILARITY CALCULATION                  ║\n');
fprintf('╚════════════════════════════════════════════════════════╝\n');
fprintf('\n');
fprintf('Distribution Similarity Metrics:\n');
fprintf('  JS Divergence:          %.4f (lower=better, nats)\n', js_divergence);
fprintf('  Hellinger similarity:   %.4f (higher=better, 0-1)\n', hellinger_similarity);
fprintf('  Classical BC (ref.):    %.4f\n', bhattacharyya_coeff_traditional);
fprintf('\n');
fprintf('Note: Reported metric is HS = 1 - H, Eq. (24).\n');
fprintf('      Classical BC = 1 - H^2 saturates near identical roses.\n');
fprintf('\n');
fprintf('Interpretation:\n');
if js_divergence < 0.1 && hellinger_similarity > 0.9
    fprintf('  ✓ Excellent orientation match!\n');
elseif js_divergence < 0.2 && hellinger_similarity > 0.8
    fprintf('  ✓ Good orientation match\n');
elseif js_divergence < 0.3 || hellinger_similarity > 0.7
    fprintf('  ⚠ Moderate orientation match\n');
else
    fprintf('  ✗ Poor orientation match\n');
end
fprintf('════════════════════════════════════════════════════════\n\n');

end

