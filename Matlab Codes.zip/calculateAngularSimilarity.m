function [js_divergence, bhattacharyya_coeff, metrics] = calculateAngularSimilarity(orientations_extracted, orientations_target, binWidth)
% Calculate orientation distribution similarity metrics (optimized - no F-beta)
%
% Inputs:
%   orientations_extracted - Orientations from extracted lineaments (degrees, 0-180)
%   orientations_target    - Orientations from known faults (degrees, 0-180)
%   binWidth               - Bin width for histogram (default: 10 degrees)
%
% Outputs:
%   js_divergence       - Jensen-Shannon divergence (lower = better, 0-1 range)
%   bhattacharyya_coeff - Bhattacharyya coefficient (higher = better, 0-1 range)
%   metrics             - Struct with additional info

if nargin < 3, binWidth = 10; end

%% Step 1: Create orientation histograms
edges = 0:binWidth:180;
numBins = length(edges) - 1;

% Count orientations in each bin
counts_extracted = histcounts(orientations_extracted, edges);
counts_target = histcounts(orientations_target, edges);

%% Step 2: Normalize to probabilities (density-independent)
prob_extracted = counts_extracted / sum(counts_extracted);
prob_target = counts_target / sum(counts_target);

%% Step 3: Calculate JS Divergence
epsilon = 1e-10;
prob_extracted_safe = prob_extracted + epsilon;
prob_target_safe = prob_target + epsilon;
prob_mean = (prob_extracted_safe + prob_target_safe) / 2;

js_divergence = 0.5 * sum(prob_extracted_safe .* log(prob_extracted_safe ./ prob_mean)) + ...
                0.5 * sum(prob_target_safe .* log(prob_target_safe ./ prob_mean));

%% Step 4: Calculate Bhattacharyya Coefficient
% Traditional Bhattacharyya (0-1, higher=better)
bhattacharyya_coeff_traditional = sum(sqrt(prob_extracted .* prob_target));

% Hellinger Distance (0-1, lower=better) - more discriminative
hellinger_dist = sqrt(sum((sqrt(prob_extracted) - sqrt(prob_target)).^2)) / sqrt(2);

% Convert Hellinger to coefficient for consistency (0-1, higher=better)
% Hellinger Affinity = 1 - Hellinger Distance
bhattacharyya_coeff = 1 - hellinger_dist;

%% Step 5: Package metrics (minimal)
metrics.js_divergence = js_divergence;
metrics.bhattacharyya_coeff = bhattacharyya_coeff;
metrics.bhattacharyya_traditional = bhattacharyya_coeff_traditional;
metrics.hellinger_dist = hellinger_dist;
metrics.binWidth = binWidth;
metrics.numBins = numBins;
metrics.bins_center = edges(1:end-1) + binWidth/2;
metrics.prob_extracted = prob_extracted;
metrics.prob_target = prob_target;

%% Display summary (concise)
fprintf('\n╔════════════════════════════════════════════════════════╗\n');
fprintf('║       ANGULAR SIMILARITY CALCULATION                  ║\n');
fprintf('╚════════════════════════════════════════════════════════╝\n');
fprintf('\n');
fprintf('Distribution Similarity Metrics:\n');
fprintf('  JS Divergence:          %.4f (lower=better, 0-1)\n', js_divergence);
fprintf('  Bhattacharyya Coeff:    %.4f (higher=better, 0-1) [Hellinger-based]\n', bhattacharyya_coeff);
fprintf('  Traditional Bhatt:      %.4f (for reference)\n', bhattacharyya_coeff_traditional);
fprintf('\n');
fprintf('Note: Using Hellinger Distance-based metric (more discriminative)\n');
fprintf('      Traditional Bhattacharyya can remain high with uniform distributions.\n');
fprintf('\n');
fprintf('Interpretation:\n');
if js_divergence < 0.1 && bhattacharyya_coeff > 0.9
    fprintf('  ✓ Excellent orientation match!\n');
elseif js_divergence < 0.2 && bhattacharyya_coeff > 0.8
    fprintf('  ✓ Good orientation match\n');
elseif js_divergence < 0.3 || bhattacharyya_coeff > 0.7
    fprintf('  ⚠ Moderate orientation match\n');
else
    fprintf('  ✗ Poor orientation match\n');
end
fprintf('════════════════════════════════════════════════════════\n\n');

end

