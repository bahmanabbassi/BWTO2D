function F_Grid = FilterB(Grid,sigma2)
%FilterB Conditionally applies a Gaussian filter to a 2D grid.
%
% Description:
%   Optional Gaussian smoothing, used at two points in the pipeline: on the
%   kCWT coefficient maps, and on each feature map just before step filtering,
%   where the width is the sigma_I of Table 1.
%
%   A sigma of zero or less returns the grid untouched, which is what lets the
%   optimizer switch the smoothing off. The published runs use sigma_I = 0, so
%   that fine structure is left for the step filter to resolve rather than
%   being blurred away beforehand.
%
% Developed by:
%   Bahman Abbassi (bahman.abbassi@uqat.ca)
%   University of Quebec (UQAT)
%
% Inputs:
%   Grid   - A 2D numerical matrix, an image or data grid.
%   sigma2 - Gaussian standard deviation in pixels. Zero or less disables the
%            filter.
%
% Output:
%   F_Grid - The smoothed grid, or the original grid when sigma2 <= 0.
%
% Example:
%   % 1. Create a sample grid and add some noise
%   my_grid = peaks(100);
%   noisy_grid = my_grid + 0.5 * randn(100);
%
%   % 2. Apply the filter with a positive sigma
%   filtered_grid = FilterB(noisy_grid, 2.0); % Filtering will be applied
%
%   % 3. "Apply" the filter with a zero sigma
%   unfiltered_grid = FilterB(noisy_grid, 0); % Filtering will be skipped
%
%   % 4. Visualize the results
%   figure;
%   subplot(1,3,1); imagesc(noisy_grid); title('Noisy Grid'); axis image;
%   subplot(1,3,2); imagesc(filtered_grid); title('Filtered (Sigma=2)'); axis image;
%   subplot(1,3,3); imagesc(unfiltered_grid); title('Filtered (Sigma=0)'); axis image;


    if sigma2 > 0
        F_Grid  = imgaussfilt(Grid,sigma2);
    else
        F_Grid = Grid; % Smoothing disabled
    end
end