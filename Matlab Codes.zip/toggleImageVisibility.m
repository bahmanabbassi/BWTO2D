function toggleImageVisibility(checkbox_handle, iter_idx, image_type)
%toggleImageVisibility - Toggle density map or raster lineaments visibility for a specific tab
%
% This function finds the image object (density map or raster lineaments) in the specified axes
% and toggles its visibility based on the checkbox state.
% Uses the same colormap approach as "Lineaments (Auto)" and "Line Densities (Auto)".
%
% Inputs:
%   checkbox_handle (uicontrol handle): The checkbox control (contains axes and image handle in UserData)
%   iter_idx (integer): The iteration index (for tag matching)
%   image_type (string): Either 'DensityMap' or 'RasterLineaments'

    % Get UserData from checkbox
    user_data = get(checkbox_handle, 'UserData');
    if isempty(user_data) || ~isfield(user_data, 'ax') || ~isfield(user_data, 'handle')
        % Fallback: find axes in the checkbox's parent (tab)
        parent = get(checkbox_handle, 'Parent');
        ax = findobj(parent, 'Type', 'axes');
        if isempty(ax)
            return;  % Can't find axes, exit
        end
        ax = ax(1);  % Take first axes if multiple found
        
        % Try to find image by tag
        image_tag = [image_type, '_', num2str(iter_idx)];
        img_handle = findobj(ax, 'Tag', image_tag);
        if isempty(img_handle)
            return;  % Can't find image, exit
        end
    else
        ax = user_data.ax;
        img_handle = user_data.handle;
    end
    
    % Get checkbox value
    show_image = get(checkbox_handle, 'Value');
    
    % Toggle visibility
    if ~isempty(img_handle) && ishandle(img_handle)
        if show_image
            set(img_handle, 'Visible', 'on');
            % Update colormap based on which image is shown
            % Use same colormaps as "Lineaments (Auto)" and "Line Densities (Auto)"
            if strcmp(image_type, 'DensityMap')
                colormap(ax, flipud(hot));  % Same as "Line Densities (Auto)"
                caxis(ax, [0 1]);
            elseif strcmp(image_type, 'RasterLineaments')
                % Only set gray colormap if density map is not visible
                density_map_handle = findobj(ax, 'Tag', ['DensityMap_', num2str(iter_idx)]);
                if isempty(density_map_handle) || strcmp(get(density_map_handle, 'Visible'), 'off')
                    colormap(ax, flipud(gray));  % Same as "Lineaments (Auto)": flipud(gray)
                    caxis(ax, [0 1]);  % Same as "Lineaments (Auto)"
                end
            end
        else
            set(img_handle, 'Visible', 'off');
            % If hiding density map, check if raster lineaments should set colormap
            if strcmp(image_type, 'DensityMap')
                raster_handle = findobj(ax, 'Tag', ['RasterLineaments_', num2str(iter_idx)]);
                if ~isempty(raster_handle) && strcmp(get(raster_handle, 'Visible'), 'on')
                    colormap(ax, flipud(gray));  % Same as "Lineaments (Auto)"
                    caxis(ax, [0 1]);
                end
            end
        end
    end
end

