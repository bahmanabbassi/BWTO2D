function Fe_All = cwt2D_DerPoisson_BTO(CWT_Input_Features_Matrix, Scales, Angles, orderx, ordery, Sigma3, Z)
%--------------------------------------------------------------------------
% FUNCTION: cwt2D_DerPoisson_BTO
%
% PURPOSE:
%   Poisson kCWT decomposition, Section 1.1. Each input grid is transformed
%   with the Poisson Derivatives Mother Wavelet at every requested scale and
%   orientation, and the magnitude of the coefficients is returned.
%
%   The transform is carried out entirely in the frequency domain: the grid is
%   transformed once with fft2, and each scale and orientation then costs an
%   algebraic multiplication rather than a fresh convolution. That is what
%   makes a Bayesian loop of fifty iterations, each covering up to 72
%   orientations, affordable.
%
%   The wavelet itself is built by derpoisson2d, following Eq. (2).
%
% AUTHOR:
%   Bahman Abbassi
%   University of Quebec (UQAT)
%   Email: bahman.abbassi@uqat.ca
%   GitHub: https://github.com/bahmanabbassi
%   MathWorks: https://www.mathworks.com/matlabcentral/profile/authors/31336389
%
% INPUTS:
%   Paper symbols are given in brackets.
%
%   CWT_Input_Features_Matrix (double): Input grid, 2D (H x W), or a stack of
%                                       grids, 3D (H x W x F).
%   Scales (double array)        [a]  : Scale values. The paper uses a single
%                                       scale, so depth sensitivity is
%                                       controlled by Z alone.
%   Angles (double array)     [theta] : Orientations in radians.
%   orderx (integer)              [n] : Derivative order in x.
%   ordery (integer)              [m] : Derivative order in y.
%   Sigma3 (double)           [sigma] : kCWT filtering ratio. When positive, a
%                                       Gaussian smoothing is applied whose
%                                       width grows with the scale index. Zero
%                                       disables it.
%   Z (double)                    [Z] : Upward continuation of the Poisson
%                                       kernel, in grid cells. Larger values
%                                       attenuate short wavelengths more
%                                       strongly and so favour deeper sources.
%
% OUTPUTS:
%   Fe_All (double):  Coefficient magnitudes, H x W x N_Scales x N_Angles x
%                     N_Features. Magnitudes are used because the sign of a
%                     directional derivative only records which side of a
%                     contact the pixel lies on.
%--------------------------------------------------------------------------

%% --- 1. Pre-processing and Initialization ---

% Undefined nodes are set to zero, since the FFT cannot carry NaNs.
CWT_Input_Features_Matrix(isnan(CWT_Input_Features_Matrix)) = 0;

N_Scales = numel(Scales);
N_Angles = numel(Angles);

clear Feature cwtmor cwtout cwtout_abs WL WL2 WLFs Fe_All WLFs_allscales WLFs_allangles

if ndims(CWT_Input_Features_Matrix) == 2
    N_Fs = 1;
elseif ndims(CWT_Input_Features_Matrix) == 3
    N_Fs = size(CWT_Input_Features_Matrix, 3);
end

%% --- 2. Transform each input grid ---
for kkk = 1:N_Fs
    Feature = CWT_Input_Features_Matrix(:, :, kkk);
    
    % One forward transform serves every scale and orientation below.
    tX = fft2(double(Feature));
    
    % cwt2d multiplies the spectrum by the scaled and rotated wavelet of
    % Eq. (7) and inverts it, for each requested scale and orientation.
    cwtmor = cwt2d(tX, 'derpoisson2d', Scales, Angles, orderx, ordery, Z);
    
    cwtout = cwtmor.data; % H x W x N_Scales x N_Angles
    
    cwtout_abs = abs(cwtout);
    
    %% --- 3. Optional smoothing and assembly ---
    for jj = 1:N_Angles
        for jjj = 1:N_Scales
            WL = cwtout_abs(:, :, jjj, jj);
            
            % The smoothing width grows with the scale index, so coarser
            % scales are smoothed more, matching their lower resolution.
            if Sigma3 > 0
                WL2 = nDstrb2D(FilterB(WL, Sigma3 * jjj));
            else
                WL2 = nDstrb2D(WL);
            end
            
            WLFs_allscales(:, :, jjj) = WL2;
        end
        WLFs_allangles(:, :, :, jj) = WLFs_allscales;
    end
    
    Fe_All(:, :, :, :, kkk) = WLFs_allangles;
end

end