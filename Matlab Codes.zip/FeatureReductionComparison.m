%% FeatureReductionComparison.m
% ==========================================================================
% COMPARISON OF DIMENSIONALITY REDUCTION STRATEGIES FOR kCWT FEATURES
% ==========================================================================
%
% PURPOSE:
%   Compares three ways of reducing the kCWT coefficient stack before
%   lineament extraction, at FIXED hyperparameters (no Bayesian search):
%
%     (a) NONE : every kCWT coefficient map is passed to the extraction.
%     (b) PCA  : the stack is replaced by its first d principal components.
%     (c) FS   : the proposed saliency/dissimilarity feature selection.
%
%   Two families of evidence are produced:
%
%     1. Feature-level diagnostics computed on the raw kCWT stack, which
%        explain WHY the three strategies behave differently (redundancy
%        between coefficient maps, and the spread of principal component
%        loadings across orientations).
%
%     2. Extraction-level results obtained by running the identical
%        downstream pipeline on each reduced set, which show the
%        CONSEQUENCE (segment counts, trace length, GRM, F-beta, P21,
%        BC, JSD, runtime).
%
% STANDALONE:
%   The script needs no GUI session and no preloaded workspace. It reads the
%   dataset from disk and reproduces the four preparation steps of BWTO2D
%   (Polygonize, Point Data, Lineaments Shapefile, Merge) internally, using
%   the same formulas as the app.
%
% GLOBAL VARIABLES:
%   Exactly one is used, YI_Real_Ratio, because step_Filtering.m and
%   getFaultDetection.m read it directly and those files are left untouched.
%   Everything else is passed as ordinary arguments.
%
% DESIGN NOTE:
%   The extraction and scoring stages are transcribed from Lineaments_Auto7.m
%   so that all three arms receive identical treatment after the reduction
%   step. NOTHING in the BWTO2D pipeline is modified. The pipeline's own
%   functions (cwt2D_DerPoisson_BTO, CWTFeatureSelection, nDstrb2D, FilterB,
%   step_Filtering, getFaultDetection, plotNewColorMap0_, calculateFbetaScore,
%   calculateStructuralMetrics) are invoked unchanged.
%
% REQUIREMENTS:
%   Image Processing, Statistics and Machine Learning, and Mapping toolboxes.
%
% AUTHOR:
%   Bahman Abbassi (bahman.abbassi@uqat.ca), University of Quebec (UQAT)
% ==========================================================================

clc;

fprintf('===================================================================\n');
fprintf('  FEATURE REDUCTION COMPARISON  (standalone, fixed hyperparameters)\n');
fprintf('===================================================================\n\n');

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 1: USER CONFIGURATION
% ═══════════════════════════════════════════════════════════════════════

% -------------------------------------------------------------------------
% Dataset. If DATA_FOLDER does not exist but DATA_ZIP does, the archive is
% unpacked automatically.
% -------------------------------------------------------------------------
DATA_ZIP    = fullfile(pwd, 'Data 1 Synthetic.zip');
DATA_FOLDER = fullfile(pwd, 'Data 1 Synthetic');

FILE_COORDS = fullfile(DATA_FOLDER, 'Coordinates Rectangle.txt');
FILE_POINTS = fullfile(DATA_FOLDER, 'Without Noise', 'Run 1', 'Data_1.csv');
FILE_TRUTH  = fullfile(DATA_FOLDER, 'Expert_Digitized_Lines.shp');

% -------------------------------------------------------------------------
% Data preparation settings. These reproduce the GUI fields of the published
% synthetic run, read off the screenshots stored with it in
% D:\Cursor BWTO2D\Data 0 Synthetic\Without Noise\Run 1: Spacing 1.5
% arc-seconds and Data Filter 0, giving the 523 x 306 grid the GUI reports.
% -------------------------------------------------------------------------
SPC_DATA          = 1.5;               % Spacing (arc-seconds) for XI, YI
SPC_TARGETS       = 0.75;              % Spacing (arc-seconds) for the truth raster
DATA_FILTER_SIGMA = 0;                 % Data Filter field on the Data Sets tab
INTERP_METHOD     = 'Regular Interp';  % or 'Scattered Interp'
WAVELET           = 'derpoisson2d';    % mother wavelet set by Merge

% -------------------------------------------------------------------------
% Optimized hyperparameters of the published synthetic run.
%
% WARNING: BTO_Progress.xlsx in this folder is NOT that run. Its best row
% records GRM = 183, but replaying those ten values on this dataset returns
% GRM = 12, so it was produced from a different configuration. Leave
% USE_BEST_FROM_XLSX = false and enter the published values below.
% -------------------------------------------------------------------------
USE_BEST_FROM_XLSX = false;
PROGRESS_XLSX      = fullfile(pwd, 'BTO_Progress.xlsx');

% Best observed feasible point of the published synthetic run, iteration 40,
% GRM = 256. Transcribed from the optimizer log of that run,
% D:\Cursor BWTO2D\Data 0 Synthetic\Without Noise\Run 1\Log_without_noise.txt
MANUAL_HP.WSFR           = 0.069696;   % sigma   : wavelet smoothness filter ratio
MANUAL_HP.Z              = 1.6488;     % Z       : Poisson upward continuation
MANUAL_HP.VSFW           = 0.37924;    % upsilon : variability of step filter width
MANUAL_HP.FDissimilarity = 0.67773;    % gamma   : dissimilarity weight
MANUAL_HP.FSaliency      = 54.5685;    % lambda  : saliency percentile
MANUAL_HP.NAngles        = 19;         % Ntheta  : number of kCWT angles
MANUAL_HP.w              = 51;         % wbar    : average step filtering width
MANUAL_HP.NSFA           = 14;         % Nphi    : number of step filtering angles
MANUAL_HP.SLC            = 84;         % xi      : global confidence threshold (%)
MANUAL_HP.orderx         = 1;          % n,m     : n = 1, m = 0

% -------------------------------------------------------------------------
% Fixed parameters (as recorded in the published synthetic run)
% -------------------------------------------------------------------------
FIXED.N_SCALES = 1;    % Na     : number of kCWT scales
FIXED.SDF      = 1;    % delta  : scale dilation factor
FIXED.DR       = 3;    % d      : maps retained by PCA and by FS
FIXED.SIGMA2   = 0;    % sigmaI : global image filter

% R : resize factor, 2 as listed in Table 1. The optimizer log of the
% published run opens with a step-filter centre of 61.2, and the app forms
% that centre as 0.1 * min(X_Pix, Y_Pix) * R, which gives 0.1 x 306 x 2.
FIXED.LINE_RES = 2;

% -------------------------------------------------------------------------
% Validation settings
% -------------------------------------------------------------------------
TOLERANCE_VALUE = 0.0176;   % tau, in coordinate units (degrees)
BETA_FBETA      = 0.2;      % beta

% -------------------------------------------------------------------------
% Which arms to run, and output location
% -------------------------------------------------------------------------
ARMS_TO_RUN   = {'FS', 'PCA', 'NONE'};   % NONE is by far the slowest
OUTPUT_FOLDER = fullfile(pwd, 'FeatureReductionComparison_Results');
SAVE_FIGURES  = true;

if ~exist(OUTPUT_FOLDER, 'dir'); mkdir(OUTPUT_FOLDER); end

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 2: LOCATE THE DATASET
% ═══════════════════════════════════════════════════════════════════════

if ~exist(DATA_FOLDER, 'dir')
    if exist(DATA_ZIP, 'file')
        fprintf('Unpacking %s ...\n', DATA_ZIP);
        unzip(DATA_ZIP, pwd);
    else
        error('Neither the folder "%s" nor the archive "%s" was found.', ...
              DATA_FOLDER, DATA_ZIP);
    end
end

for f = {FILE_COORDS, FILE_POINTS, FILE_TRUTH}
    if ~exist(f{1}, 'file')
        error('Required input file not found:\n  %s', f{1});
    end
end

fprintf('Dataset located in %s\n\n', DATA_FOLDER);

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 3: STUDY AREA  (equivalent of the Polygonize button)
% ═══════════════════════════════════════════════════════════════════════

Coordinates = importdata(FILE_COORDS);   % [Xmin; Xmax; Ymin; Ymax]
Xmin = Coordinates(1);  Xmax = Coordinates(2);
Ymin = Coordinates(3);  Ymax = Coordinates(4);

% Corner points of the rectangular study area, closed into a polygon
xc = [Xmin; Xmin; Xmax; Xmax];
yc = [Ymin; Ymax; Ymin; Ymax];
bnd = boundary(xc, yc, 1);
xv  = xc(bnd);
yv  = yc(bnd);

% The one global the pipeline insists on: step_Filtering.m and
% getFaultDetection.m read YI_Real_Ratio directly to size their edge crops.
global YI_Real_Ratio %#ok<GVMIS>
YI_Real_Ratio = abs(1 / cos(deg2rad(mean(yc))));

Spacing = SPC_DATA / 3600;
[XI, YI] = meshgrid(Xmin:Spacing:Xmax, Ymin:Spacing:Ymax);

% The app selects between three inpolygon variants purely for speed; they
% return the same mask, so the direct form is used here.
inMask = inpolygon(XI, YI, xv, yv);

X_Pix = size(XI, 2);
Y_Pix = size(YI, 1);

fprintf('Study area\n');
fprintf('  longitude      : %.6f to %.6f\n', Xmin, Xmax);
fprintf('  latitude       : %.6f to %.6f\n', Ymin, Ymax);
fprintf('  grid           : %d rows x %d cols at %.2f arc-seconds\n', Y_Pix, X_Pix, SPC_DATA);
fprintf('  latitude ratio : %.4f\n', YI_Real_Ratio);
fprintf('  nodes inside   : %d (%.1f %%)\n\n', nnz(inMask), 100*nnz(inMask)/numel(inMask));

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 4: POINT DATA  (equivalent of the Point Data button)
% ═══════════════════════════════════════════════════════════════════════

fprintf('Reading point data ...\n');
Data1 = readmatrix(FILE_POINTS, 'FileType', 'text', 'CommentStyle', '/');
if size(Data1, 2) < 3
    error('Point data file must contain at least three columns (X, Y, Value).');
end

xp = Data1(:,1);  yp = Data1(:,2);  vp = Data1(:,3);

switch INTERP_METHOD
    case 'Regular Interp'
        ImD0 = griddata(xp, yp, vp, XI, YI, 'nearest');
    case 'Scattered Interp'
        Fint = scatteredInterpolant(xp, yp, vp, 'natural');
        ImD0 = Fint(XI, YI);
    otherwise
        error('INTERP_METHOD must be ''Regular Interp'' or ''Scattered Interp''.');
end

ImD1   = nDstrb2D(ImD0);
ImD1tr = inMask .* FilterB(ImD1, DATA_FILTER_SIGMA);
ImD1tr(ImD1tr == 0) = NaN;

All_Data_Matrix = ImD1tr;

fprintf('  %d points gridded onto %d x %d\n\n', numel(vp), size(All_Data_Matrix,1), size(All_Data_Matrix,2));

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 5: GROUND TRUTH  (equivalent of the Lineaments Shape File button)
% ═══════════════════════════════════════════════════════════════════════

fprintf('Reading and rasterizing the expert-digitized lines ...\n');

SpacingT = SPC_TARGETS / 3600;
[XI_, YI_] = meshgrid(Xmin:SpacingT:Xmax, Ymin:SpacingT:Ymax);

All_Trg_Matrix = rasterizeLineaments(FILE_TRUTH, XI_, YI_, Xmin, Xmax, Ymin, Ymax);

fprintf('  truth raster   : %d x %d, %d lit pixels\n\n', ...
    size(All_Trg_Matrix,1), size(All_Trg_Matrix,2), nnz(All_Trg_Matrix));

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 6: MERGE  (equivalent of the Merge button)
% ═══════════════════════════════════════════════════════════════════════

% The app forwards only the last loaded image, because the GRM is sensitive
% to pattern overlap between independent sources.
CWT_Input = All_Data_Matrix(:,:,end);

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 7: OPTIMIZED HYPERPARAMETERS
% ═══════════════════════════════════════════════════════════════════════

if USE_BEST_FROM_XLSX && exist(PROGRESS_XLSX, 'file')
    T = readtable(PROGRESS_XLSX); %#ok<UNRCH>  % reachable when the toggle is on
    if ~ismember('objectiveValues', T.Properties.VariableNames)
        error('BTO_Progress.xlsx does not contain an objectiveValues column.');
    end
    obj = T.objectiveValues;
    obj(~isfinite(obj)) = Inf;
    [bestObj, bestRow] = min(obj);          % bayesopt minimises -GRM

    HP.WSFR           = T.WSFR(bestRow);
    HP.Z              = T.Z(bestRow);
    HP.VSFW           = T.VSFW(bestRow);
    HP.FDissimilarity = T.FDissimilarity(bestRow);
    HP.FSaliency      = T.FSaliency(bestRow);
    HP.NAngles        = round(T.NAngles(bestRow));
    HP.w              = T.w(bestRow);
    HP.NSFA           = round(T.NSFA(bestRow));
    HP.SLC            = T.SLC(bestRow);

    ox = T.orderx(bestRow);
    if iscell(ox);  ox = str2double(ox{1});  end
    if ischar(ox);  ox = str2double(ox);     end
    HP.orderx = round(ox);

    fprintf('Hyperparameters from %s (row %d of %d, GRM = %.0f)\n', ...
        PROGRESS_XLSX, bestRow, height(T), -bestObj);
else
    HP = MANUAL_HP;
    fprintf('Hyperparameters from the MANUAL_HP block.\n');
end

fprintf('  sigma  (WSFR)           = %.4f\n', HP.WSFR);
fprintf('  Z                       = %.4f\n', HP.Z);
fprintf('  Ntheta (NAngles)        = %d\n',   HP.NAngles);
fprintf('  n,m    (orderx)         = %d\n',   HP.orderx);
fprintf('  wbar   (w)              = %.2f\n', HP.w);
fprintf('  upsilon(VSFW)           = %.4f\n', HP.VSFW);
fprintf('  Nphi   (NSFA)           = %d\n',   HP.NSFA);
fprintf('  xi     (SLC)            = %.2f\n', HP.SLC);
fprintf('  gamma  (FDissimilarity) = %.4f\n', HP.FDissimilarity);
fprintf('  lambda (FSaliency)      = %.4f\n\n', HP.FSaliency);

warning('off', 'all');   % suppress pipeline chatter from here on

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 8: kCWT STACK, COMPUTED ONCE
%  (transcribed from Lineaments_Auto7.m, Stage 1)
% ═══════════════════════════════════════════════════════════════════════

fprintf('Computing the kCWT stack ...\n');
tCWT = tic;

if HP.orderx == 1
    ordery = 0;
elseif HP.orderx == 0
    ordery = 1;
else
    error('orderx must be 0 or 1.');
end

if HP.orderx == ordery && HP.orderx ~= 0
    betad = 90;
else
    betad = 180;
end

Scales = 1:FIXED.SDF:(FIXED.N_SCALES * FIXED.SDF);
if HP.NAngles > 0
    angle_step = betad / HP.NAngles;
    Angless    = 0 : angle_step : (betad - angle_step);
else
    Angless = 0;
end
Angles = Angless * pi / 180;

switch WAVELET
    case 'gaus'
        Fe_All = cwt2D_DerGus_BTO(CWT_Input, Scales, Angles, HP.orderx, ordery, HP.WSFR);
    case 'derpoisson2d'
        Fe_All = cwt2D_DerPoisson_BTO(CWT_Input, Scales, Angles, HP.orderx, ordery, HP.WSFR, HP.Z);
    otherwise
        error('Unsupported wavelet: %s', WAVELET);
end

[XI_siz, YI_siz, nn, mm, kk] = size(Fe_All);
Result3D = reshape(Fe_All, XI_siz, YI_siz, nn*mm, kk);
clear Fe_All;

if ndims(Result3D) > 3 && size(Result3D,4) > 1
    error('This script supports a single input image only (found %d).', size(Result3D,4));
end
Result3D = squeeze(Result3D);

nMaps = size(Result3D, 3);
DR2   = max(1, min(FIXED.DR, nMaps));

fprintf('  stack: %d x %d x %d maps  (%.1f s)\n\n', ...
    size(Result3D,1), size(Result3D,2), nMaps, toc(tCWT));

% Fe_All is H x W x N_Scales x N_Angles, so with column-major reshape the
% map index i corresponds to angle index floor((i-1)/N_Scales) + 1.
mapAngleDeg = zeros(1, nMaps);
for i = 1:nMaps
    angleIdx       = floor((i-1) / FIXED.N_SCALES) + 1;
    mapAngleDeg(i) = Angless(min(angleIdx, numel(Angless)));
end

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 9: FEATURE-LEVEL DIAGNOSTICS ON THE RAW kCWT STACK
% ═══════════════════════════════════════════════════════════════════════

fprintf('Computing feature-level diagnostics ...\n');

D = struct();
D.nMaps       = nMaps;
D.mapAngleDeg = mapAngleDeg;

% --- 9.1 Pairwise absolute Pearson correlation between coefficient maps ----
Xflat     = reshape(Result3D, [], nMaps);
validRows = all(isfinite(Xflat), 2);
Xv        = Xflat(validRows, :);

Cmat = abs(corrcoef(Xv));
Cmat(1:nMaps+1:end) = NaN;                       % blank the diagonal
offDiag = Cmat(~isnan(Cmat));

D.corrMatrix       = Cmat;
D.meanAbsCorr      = mean(offDiag);
D.medianAbsCorr    = median(offDiag);
D.fracPairsAbove90 = mean(offDiag > 0.90);
D.fracPairsAbove95 = mean(offDiag > 0.95);

% --- 9.2 Effective number of independent maps ------------------------------
% Participation ratio of the eigenvalues of the correlation matrix.
lam = eig(corrcoef(Xv));
lam = lam(lam > 0);
D.effectiveNumMaps = (sum(lam)^2) / sum(lam.^2);

% --- 9.3 Pairwise Jaccard overlap of the rudimentary edge maps -------------
% Same percentile-positive edge definition as CWTFeatureSelection.m, at the
% saliency percentile the optimizer selected.
edgeStack = false(size(Result3D,1), size(Result3D,2), nMaps);
for i = 1:nMaps
    edgeStack(:,:,i) = extractRudimentaryEdges(Result3D(:,:,i), HP.FSaliency);
end

nPairs = nMaps*(nMaps-1)/2;
jac    = zeros(1, nPairs);
p      = 0;
for i = 1:nMaps
    Ei = edgeStack(:,:,i);
    for j = i+1:nMaps
        Ej = edgeStack(:,:,j);
        u  = sum(Ei | Ej, 'all');
        p  = p + 1;
        if u > 0
            jac(p) = sum(Ei & Ej, 'all') / u;
        end
    end
end
D.meanEdgeJaccard      = mean(jac);
D.fracEdgePairsAbove50 = mean(jac > 0.50);
clear edgeStack;

% --- 9.4 Principal component structure -------------------------------------
[coeff, ~, ~, ~, explained, mu] = pca(Xv, 'Centered', true);

D.pcaExplained = explained;
D.pcaCum       = cumsum(explained);
D.nPCsFor95    = find(D.pcaCum >= 95, 1, 'first');
D.pcaCoeff     = coeff;

% Spread of each component's loadings across orientations. Normalised Shannon
% entropy of the squared loadings: 0 means the component is carried by a
% single orientation, 1 means it is spread evenly over all of them.
nPCshow = min(DR2, size(coeff,2));
D.pcLoadingEntropy = zeros(1, nPCshow);
for k = 1:nPCshow
    pk = coeff(:,k).^2;
    pk = pk / sum(pk);
    pk = pk(pk > 0);
    D.pcLoadingEntropy(k) = -sum(pk .* log(pk)) / log(nMaps);
end

% --- 9.5 Which maps the proposed selection retains -------------------------
[~, fsIdx, fsDebug] = CWTFeatureSelection(Result3D, DR2, HP.FSaliency, HP.FDissimilarity);
D.fsSelectedIdx      = fsIdx;
D.fsSelectedAngleDeg = mapAngleDeg(fsIdx);
D.fsDebug            = fsDebug;
D.fsLoadingEntropy   = zeros(1, numel(fsIdx));   % one-hot by construction

fprintf('  mean |rho| between maps         : %.3f\n', D.meanAbsCorr);
fprintf('  pairs with |rho| > 0.90         : %.1f %%\n', 100*D.fracPairsAbove90);
fprintf('  mean edge Jaccard overlap       : %.3f\n', D.meanEdgeJaccard);
fprintf('  effective number of maps        : %.2f  (of %d)\n', D.effectiveNumMaps, nMaps);
fprintf('  components for 95 %% of variance : %d\n', D.nPCsFor95);
fprintf('  PC loading entropy (first %d)    : %s\n', nPCshow, mat2str(round(D.pcLoadingEntropy,3)));
fprintf('  selected map orientations (deg) : %s\n\n', mat2str(round(D.fsSelectedAngleDeg,1)));

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 10: BUILD THE THREE REDUCED FEATURE SETS
% ═══════════════════════════════════════════════════════════════════════

reduced = struct();

% (a) Proposed feature selection
reduced.FS = Result3D(:,:,fsIdx);

% (b) Principal component reduction to the same dimensionality
scoresAll = (Xflat - mu) * coeff(:, 1:DR2);
scoresAll(~isfinite(scoresAll)) = 0;
reduced.PCA = reshape(scoresAll, size(Result3D,1), size(Result3D,2), DR2);
clear scoresAll Xflat Xv;

% (c) No reduction
reduced.NONE = Result3D;

fprintf('Reduced sets: FS = %d maps, PCA = %d maps, NONE = %d maps\n\n', ...
    size(reduced.FS,3), size(reduced.PCA,3), size(reduced.NONE,3));

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 11: RUN THE IDENTICAL DOWNSTREAM PIPELINE ON EACH ARM
% ═══════════════════════════════════════════════════════════════════════

CTX.XI             = XI;
CTX.YI             = YI;
CTX.inMask         = inMask;
CTX.AllData        = All_Data_Matrix;
CTX.Truth          = All_Trg_Matrix;
CTX.YI_Real_Ratio  = YI_Real_Ratio;
CTX.X_Pix          = X_Pix;
CTX.Y_Pix          = Y_Pix;

results = struct([]);

for a = 1:numel(ARMS_TO_RUN)
    armName = ARMS_TO_RUN{a};
    fprintf('-------------------------------------------------------------\n');
    fprintf('ARM: %s   (%d maps entering extraction)\n', armName, size(reduced.(armName),3));
    fprintf('-------------------------------------------------------------\n');

    tArm = tic;
    R = runDownstream(reduced.(armName), HP, FIXED, TOLERANCE_VALUE, BETA_FBETA, CTX);
    R.arm        = armName;
    R.nInputMaps = size(reduced.(armName), 3);
    R.runtime_s  = toc(tArm);

    fprintf('  features extracted : %d\n',    R.nFeatures);
    fprintf('  px per feature     : %.0f mean, %d minimum\n', ...
                                             R.meanPixelsPerFeature, R.minPixelsPerFeature);
    fprintf('  px kept (consensus): %d\n',    R.intersectionPixels);
    fprintf('  segments           : %d\n',    R.nSegments);
    fprintf('  total trace length : %d px\n', R.totalLength);
    fprintf('  GRM                : %.0f\n',  R.GRM);
    fprintf('  F-beta             : %.4f\n',  R.fbeta);
    fprintf('  P21 ratio          : %.4f\n',  R.P21);
    fprintf('  BC                 : %.4f\n',  R.BC);
    fprintf('  JSD                : %.4f\n',  R.JSD);
    fprintf('  px under union     : %d   (diagnostic, not scored)\n', R.unionPixels);
    fprintf('  runtime            : %.1f s\n\n', R.runtime_s);

    if isempty(results); results = R; else; results(end+1) = R; end %#ok<SAGROW>
end

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 12: RESULTS TABLE
% ═══════════════════════════════════════════════════════════════════════

% Reported table. Metrics come from the consensus (intersection) map, which is
% what the GRM objective and the metrics in the paper are built on. UnionPx is
% carried as a diagnostic only: it measures how much raw detection each
% strategy produces before the consensus rule is applied.
Tres = table( ...
    {results.arm}', [results.nInputMaps]', [results.nFeatures]', ...
    round([results.meanPixelsPerFeature])', [results.intersectionPixels]', ...
    [results.nSegments]', [results.totalLength]', [results.GRM]', ...
    [results.fbeta]', [results.P21]', [results.BC]', [results.JSD]', ...
    [results.unionPixels]', [results.runtime_s]', ...
    'VariableNames', {'Strategy','MapsIn','FeaturesExtracted','MeanPxPerFeature', ...
                      'PixelsKept','Segments','TotalLengthPx','GRM', ...
                      'Fbeta','P21','BC','JSD','UnionPx_diag','Runtime_s'});

% Union scores are retained in the .mat for reference but are not reported,
% because the matching tolerance saturates them at F-beta ~ 1 for every arm.
Tunion = table( ...
    {results.arm}', [results.unionPixels]', [results.u_nSegments]', ...
    [results.u_GRM]', [results.u_fbeta]', [results.u_P21]', ...
    'VariableNames', {'Strategy','PixelsKept','Segments','GRM','Fbeta','P21'});

disp(' ');
disp('=========== COMPARISON SUMMARY (consensus stacking) ===========');
disp(Tres);

csvPath = fullfile(OUTPUT_FOLDER, 'feature_reduction_comparison.csv');
writetable(Tres, csvPath);
fprintf('Table written to %s\n', csvPath);

matPath = fullfile(OUTPUT_FOLDER, 'feature_reduction_diagnostics.mat');
save(matPath, 'D', 'Tres', 'Tunion', 'HP', 'FIXED', 'results', '-v7.3');
fprintf('Diagnostics written to %s\n\n', matPath);

%% ═══════════════════════════════════════════════════════════════════════
%  SECTION 13: FIGURES
% ═══════════════════════════════════════════════════════════════════════

if SAVE_FIGURES

    armIndex = @(name) find(strcmp({results.arm}, name), 1);

    % Panel letters, so that the manuscript captions can refer to (a) to (f).
    % Tiles are lettered left to right, top row first.
    panelLetter = @(n) sprintf('(%s)', char('a' + n - 1));

    % Figure numbers used in the manuscript. A second copy of each figure is
    % written under these names so the files and the captions stay in step.
    MS_NUMBER = struct('reducedMaps', 'Fig18', 'evaluation', 'Fig19');

    % Both figures are laid out at the journal's double-column width. One
    % type scale is used for every role: 8 pt body, 9 pt titles, 10 pt panel
    % letters. The previous 12 / 6.5 split made titles overflow their tiles
    % while ticks, legends and the scale bar vanished.
    FIG_WIDTH_CM = 19.0;
    FS_TITLE  = 9;
    FS_LABEL  = 8;
    FS_TICK   = 8;
    FS_LEGEND = 8;
    FIG_FONT  = 'Helvetica';

    setFigureDefaults = @(fh) set(fh, ...
        'Color','w', 'Units','centimeters', ...
        'DefaultAxesFontName', FIG_FONT, 'DefaultAxesFontSize', FS_TICK, ...
        'DefaultTextFontName', FIG_FONT, 'DefaultAxesLineWidth', 0.5);

    % Ground distance per grid column, used by the scale bars. The maps are
    % geographic, so the east-west span shrinks with the cosine of latitude.
    midLat     = 0.5 * (Ymin + Ymax);
    areaWidthKm = (Xmax - Xmin) * 111.320 * cosd(midLat);

    % ---------------------------------------------------------------------
    % Figure 18: the reduced feature maps themselves, FS above PCA, so that
    % column k contrasts the k-th map kept by each strategy. Titles carry the
    % physical quantity, the retained orientation for FS and the variance
    % share for PCA, so the "pure orientation versus statistical mixture"
    % claim can be checked against the panels.
    % ---------------------------------------------------------------------
    mapH = size(reduced.FS, 1);
    mapW = size(reduced.FS, 2);
    % Height follows the map aspect so the two rows sit together instead of
    % leaving a white band the height of the titles.
    fig18H = FIG_WIDTH_CM * (2/3) * (mapH/mapW) + 1.4;

    f1 = figure('Name','Fig18_Reduced_Feature_Maps');
    setFigureDefaults(f1);
    set(f1, 'Position', [2 2 FIG_WIDTH_CM fig18H]);
    t1 = tiledlayout(f1, 2, 3, 'TileSpacing','compact', 'Padding','compact');

    rowArms = {'FS', 'PCA'};

    for r = 1:2
        for k = 1:3
            tileNo = (r-1)*3 + k;
            ax = nexttile(t1, tileNo);
            if ~isfield(reduced, rowArms{r}) || size(reduced.(rowArms{r}), 3) < k
                axis(ax, 'off');
                continue
            end

            M = reduced.(rowArms{r})(:,:,k);

            % Each map carries its own units, kCWT coefficients in one row and
            % PCA scores in the other, so a shared colour scale would be
            % meaningless. Panels are clipped to their own 2nd and 98th
            % percentiles instead, which also stops a few extreme nodes from
            % washing out the structure.
            v  = M(isfinite(M));
            cl = prctile(v, [2 98]);
            if ~(cl(2) > cl(1)); cl = [min(v) max(v)]; end

            imagesc(ax, M, cl);
            axis(ax, 'image');
            colormap(ax, gray);
            set(ax, 'XTick', [], 'YTick', [], 'YDir', 'normal', 'Box', 'on');

            if r == 1
                lbl = sprintf('\\theta = %.1f^{\\circ}', D.fsSelectedAngleDeg(k));
            else
                lbl = sprintf('PC%d (%.0f%%)', k, D.pcaExplained(k));
            end
            title(ax, sprintf('%s  %s', panelLetter(tileNo), lbl), ...
                'FontWeight','normal', 'FontSize', FS_TITLE);

            % One scale bar and north arrow for the figure: every panel shares
            % the same extent, so repeating them would only add clutter.
            if tileNo == 1
                drawScaleBar(ax, areaWidthKm / size(M,2), FS_LABEL, 0.20, true);
                drawNorthArrow(ax, FS_LABEL);
            end
        end
    end

    % ---------------------------------------------------------------------
    % Figure 19: why reduction is needed (top row) and what each strategy
    % ends up extracting (bottom row). The rows hold different shapes, square
    % diagnostic plots above and wide map panels below, so a nested layout
    % gives the bottom row less height rather than padding it with white.
    % ---------------------------------------------------------------------
    f2 = figure('Name','Fig19_Comprehensive_Evaluation');
    setFigureDefaults(f2);
    set(f2, 'Position', [2 2 FIG_WIDTH_CM 13.0]);
    % Top row needs the square diagnostic plots; the maps are wide, so they
    % get two fifths of the height rather than an equal share that would sit
    % in a white band.
    outer = tiledlayout(f2, 5, 1, 'TileSpacing','compact', 'Padding','compact');

    tTop = tiledlayout(outer, 1, 3, 'TileSpacing','compact', 'Padding','tight');
    tTop.Layout.Tile     = 1;
    tTop.Layout.TileSpan = [3 1];

    tBot = tiledlayout(outer, 1, 3, 'TileSpacing','compact', 'Padding','tight');
    tBot.Layout.Tile     = 4;
    tBot.Layout.TileSpan = [2 1];

    % --- Tile a: pairwise redundancy of the raw kCWT stack ----------------
    ax = nexttile(tTop);
    % The diagonal is NaN rather than zero, and is made transparent so that it
    % reads as "not applicable" instead of "uncorrelated with itself".
    % Each of the Nθ maps occupies an equal slice of [0, 180). The last look
    % direction is 180 − 180/Nθ (180° would duplicate 0°), so cells must be
    % drawn from bin centre to bin centre (dθ/2 … 180 − dθ/2). That puts the
    % cell edges at 0 and 180 and fills the square; placing cells at the
    % raw map angles left an empty strip after the last map.
    nAng = size(D.corrMatrix, 1);
    dth  = 180 / nAng;
    imagesc(ax, [dth/2, 180 - dth/2], [dth/2, 180 - dth/2], D.corrMatrix, ...
        'AlphaData', ~isnan(D.corrMatrix));
    set(ax, 'CLim', [0 1], 'Color', 'w', 'YDir', 'reverse');
    axis(ax, 'square');
    colormap(ax, parula);
    xlim(ax, [0 180]);
    ylim(ax, [0 180]);
    xticks(ax, 0:60:180);
    yticks(ax, 0:60:180);
    xlabel(ax, 'orientation (\circ)', 'FontSize', FS_LABEL);
    ylabel(ax, 'orientation (\circ)', 'FontSize', FS_LABEL);
    % Horizontal colourbar above the square axes, matching the legends on
    % (b) and (c). Tick values and |ρ| sit under the bar. Panel name sits
    % under the plot.
    cb = colorbar(ax, 'northoutside');
    cb.AxisLocation = 'in';                 % ticks on the plot side of the bar
    cb.Ticks        = [0 0.5 1];
    cb.FontSize     = FS_TICK;
    cb.Label.String = '|\rho|';
    cb.Label.FontSize = FS_LABEL;
    cb.Label.Rotation = 0;
    cb.Label.HorizontalAlignment = 'center';
    cb.Label.VerticalAlignment   = 'top';
    cb.Label.Units    = 'normalized';
    cb.Label.Position = [0.5, -1.05, 0];   % under the ticks, close to the bar
    setPanelCaption(ax, sprintf('%s  Redundancy', panelLetter(1)), FS_TITLE);
    % Lift the bar (and |ρ|, which is parented to it) so they clear the heatmap.
    drawnow;
    p = cb.Position;
    cb.Position(2) = p(2) + 1.9*p(4);

    % --- Tile b: how much of the stack a few components account for -------
    % Both series are percentages, so they share one 0 to 100 axis. A dual
    % axis starting at 80 % would exaggerate the climb of the cumulative curve.
    ax = nexttile(tTop);
    nShow = min(15, numel(D.pcaExplained));
    hold(ax, 'on');
    bar(ax, 1:nShow, D.pcaExplained(1:nShow), 0.7, ...
        'FaceColor', [0.30 0.55 0.80], 'EdgeColor','none', ...
        'DisplayName', 'individual');
    plot(ax, 1:nShow, D.pcaCum(1:nShow), '-o', 'Color', [0.85 0.33 0.10], ...
        'LineWidth', 1.0, 'MarkerSize', 4, 'MarkerFaceColor', [0.85 0.33 0.10], ...
        'DisplayName', 'cumulative');
    hold(ax, 'off');
    grid(ax, 'on');
    xlim(ax, [0.4 nShow+0.6]); ylim(ax, [0 105]);
    xticks(ax, unique([1 5:5:nShow]));
    xlabel(ax, 'principal component', 'FontSize', FS_LABEL);
    ylabel(ax, 'variance (%)', 'FontSize', FS_LABEL);
    % Square like (a): the leftover band above the axes holds the legend.
    axis(ax, 'square');
    lgdB = legend(ax, 'Location','northoutside', 'FontSize', FS_LEGEND, ...
        'Box','off', 'Orientation','horizontal');
    lgdB.ItemTokenSize = [12 4];
    setPanelCaption(ax, sprintf('%s  Variance spectrum', panelLetter(2)), FS_TITLE);

    % --- Tile c: PCA smears loadings over all look directions, FS does not
    ax = nexttile(tTop);
    hold(ax, 'on');
    cols   = lines(nPCshow);
    maxLoad = 0;
    for k = 1:nPCshow
        lk = abs(D.pcaCoeff(:,k));
        maxLoad = max(maxLoad, max(lk));
        plot(ax, D.mapAngleDeg, lk, '-', 'Color', cols(k,:), 'LineWidth', 1.2, ...
             'DisplayName', sprintf('PC%d (H=%.2f)', k, D.pcLoadingEntropy(k)));
    end
    % Reference lines rather than stems: the earlier stems were drawn at a
    % height of one and could be misread as loadings of one.
    for s = 1:numel(D.fsSelectedAngleDeg)
        hSel = xline(ax, D.fsSelectedAngleDeg(s), '-', ...
            'Color', [0.15 0.15 0.15], 'LineWidth', 1.6);
        if s == 1
            hSel.DisplayName = 'FS';
        else
            hSel.HandleVisibility = 'off';
        end
    end
    hold(ax, 'off'); grid(ax, 'on');
    xlim(ax, [0 180]); xticks(ax, 0:60:180);
    ylim(ax, [0 max(0.05, maxLoad*1.12)]);
    xlabel(ax, 'orientation (\circ)', 'FontSize', FS_LABEL);
    ylabel(ax, '|PC loading|', 'FontSize', FS_LABEL);
    % Square like (a): the leftover band above the axes holds the legend, so
    % the y-axis no longer needs extra headroom.
    axis(ax, 'square');
    lgdC = legend(ax, 'Location','northoutside', 'FontSize', FS_LEGEND, ...
        'Box','off', 'NumColumns', 2);
    lgdC.ItemTokenSize = [12 4];
    setPanelCaption(ax, sprintf('%s  PC loadings', panelLetter(3)), FS_TITLE);

    % --- Tiles d to f: the network each strategy extracts ------------------
    netArms   = {'FS', 'PCA', 'NONE'};
    netLabels = {'FS', 'PCA', 'No reduction'};
    axFirstNet = [];
    for a = 1:numel(netArms)
        ax  = nexttile(tBot);
        idx = armIndex(netArms{a});
        if isempty(idx)
            axis(ax, 'off');
            continue
        end
        rgb = networkOverlayRGB(results(idx).lineaments, results(idx).u_lineaments, ...
                                CTX.Truth);
        image(ax, rgb);
        axis(ax, 'image');
        set(ax, 'XTick', [], 'YTick', [], 'YDir', 'normal', 'Box', 'on');
        % Two short lines under the map, so the metrics cannot run into the
        % next tile.
        setPanelCaption(ax, {sprintf('%s  %s', panelLetter(3 + a), netLabels{a}), ...
            sprintf('F_{\\beta} = %.2f,  GRM = %d', ...
            results(idx).fbeta, results(idx).GRM)}, FS_TITLE);
        if isempty(axFirstNet)
            axFirstNet = ax;
            drawScaleBar(ax, areaWidthKm / size(rgb,2), FS_LABEL);
            drawNorthArrow(ax, FS_LABEL);
        end
    end

    % One legend for the whole bottom row, so each map panel can be read
    % without going back to the caption.
    if ~isempty(axFirstNet)
        hold(axFirstNet, 'on');
        hT = patch(axFirstNet, 'XData', NaN, 'YData', NaN, ...
            'FaceColor', [0.42 0.68 0.94], 'EdgeColor','none', ...
            'DisplayName', 'expert traces');
        hU = patch(axFirstNet, 'XData', NaN, 'YData', NaN, ...
            'FaceColor', [0.90 0.90 0.90], 'EdgeColor', [0.70 0.70 0.70], ...
            'DisplayName', 'union (context)');
        hC = patch(axFirstNet, 'XData', NaN, 'YData', NaN, ...
            'FaceColor', [1 0 0], 'EdgeColor','none', ...
            'DisplayName', 'consensus (scored)');
        hold(axFirstNet, 'off');
        lgd = legend(axFirstNet, [hT hU hC], 'Orientation','horizontal', ...
            'FontSize', FS_TITLE, 'Box','off');
        lgd.Layout.Tile = 'south';
        lgd.ItemTokenSize = [12 8];
    end

    % --- Save both figures -------------------------------------------------
    % Each figure is written under a descriptive name and under the number it
    % carries in the manuscript, as a 600 dpi raster and as a vector PDF.
    toSave = { f1, 'Fig18_Reduced_Feature_Maps',    MS_NUMBER.reducedMaps
               f2, 'Fig19_Comprehensive_Evaluation', MS_NUMBER.evaluation };

    for s = 1:size(toSave, 1)
        fh = toSave{s,1};
        for name = toSave(s, 2:3)
            exportgraphics(fh, fullfile(OUTPUT_FOLDER, [name{1} '.png']), ...
                'Resolution', 600);
            exportgraphics(fh, fullfile(OUTPUT_FOLDER, [name{1} '.pdf']), ...
                'ContentType', 'vector');
            savefig(fh, fullfile(OUTPUT_FOLDER, [name{1} '.fig']));
            fprintf('  saved %s as .png (600 dpi), .pdf (vector) and .fig\n', name{1});
        end
    end

    fprintf('Figures written to %s\n', OUTPUT_FOLDER);
end

fprintf('\nDone.\n');


%% ═══════════════════════════════════════════════════════════════════════
%  LOCAL FUNCTIONS
% ═══════════════════════════════════════════════════════════════════════

function rgb = networkOverlayRGB(consensusMap, unionMap, truthMap)
% Renders one extracted network on a white background in three layers: the
% union of the per-feature detections in pale grey, the expert-digitized
% traces in blue, and on top the consensus pixels, those every feature
% agrees on, in red.
%
% Drawing the truth beneath the consensus makes the F-beta score legible:
% red sitting on blue is a hit, and blue left exposed is a miss.
%
% consensusMap and unionMap use the pipeline convention of lineament = 0,
% background = 1; truthMap is a binary raster with the traces set. The
% consensus network is only a few hundred pixels on a grid of this size and
% vanishes at figure resolution, so the layers are thickened here. The
% dilation is for display only; every reported number comes from the
% untouched maps.

    consensus = imdilate(~imbinarize(consensusMap), strel('disk', 3));
    unionPix  = imdilate(~imbinarize(unionMap),     strel('disk', 1));

    if nargin > 2 && ~isempty(truthMap)
        gt = truthMap;
        if ~isequal(size(gt), size(consensus))
            gt = imresize(gt, size(consensus));
        end
        truthPix = imdilate(imbinarize(gt), strel('disk', 1));
    else
        truthPix = false(size(consensus));
    end

    truthColour = [0.42 0.68 0.94];

    rgb = ones([size(consensus) 3]);
    for ch = 1:3
        layer = rgb(:,:,ch);
        layer(unionPix)  = 0.90;             % detected fabric, not scored
        layer(truthPix)  = truthColour(ch);  % what the expert digitized
        layer(consensus) = (ch == 1);        % red where every feature agrees
        rgb(:,:,ch) = layer;
    end
end

function setPanelCaption(ax, caption, fontSize)
% Puts the panel letter and name under the axes. If an xlabel is already
% present, the caption becomes a further line beneath it so tiledlayout
% reserves the space and the text is not clipped on export.

    if ischar(caption) || isstring(caption)
        capLines = cellstr(caption);
    else
        capLines = caption(:);
    end

    existing = get(ax.XLabel, 'String');
    if ischar(existing) || (isstring(existing) && isscalar(existing))
        if strlength(strtrim(string(existing))) == 0
            lines = capLines;
        else
            lines = [cellstr(existing); capLines];
        end
    elseif iscell(existing) && ~isempty(existing)
        lines = [existing(:); capLines];
    else
        lines = capLines;
    end

    xlabel(ax, lines, 'FontSize', fontSize, 'FontWeight', 'normal', ...
        'Interpreter', 'tex');
end

function drawScaleBar(ax, kmPerColumn, fontSize, yFrac, labelBelow)
% Horizontal scale bar in the lower-left corner of an image axes whose x-axis
% is in grid columns. The bar length is taken from a fixed ladder of round
% distances so that panels of different grid sizes still agree.
% yFrac is the bar's height above the bottom of the axes, as a fraction of
% the axes height (default 0.10). labelBelow puts the "N km" note under the
% bar instead of above it.

    if nargin < 4 || isempty(yFrac)
        yFrac = 0.10;
    end
    if nargin < 5 || isempty(labelBelow)
        labelBelow = false;
    end

    xl = xlim(ax);  yl = ylim(ax);
    xr = xl(2) - xl(1);  yr = yl(2) - yl(1);

    ladder = [0.5 1 2 5 10 20 50 100 200 500];
    barKm  = ladder(find(ladder <= xr * kmPerColumn / 4, 1, 'last'));
    if isempty(barKm); barKm = xr * kmPerColumn / 4; end
    barCols = barKm / kmPerColumn;

    x0 = xl(1) + 0.05*xr;
    y0 = yl(1) + yFrac*yr;
    h  = 0.030*yr;

    wasHeld = ishold(ax);  hold(ax, 'on');

    if labelBelow
        yBackLo = y0 - 3.4*h;
        yBackHi = y0 + 1.3*h;
        yTxt    = y0 - 0.30*h;
        vAlign  = 'top';
    else
        yBackLo = y0 - 0.9*h;
        yBackHi = y0 + 4.2*h;
        yTxt    = y0 + 2.4*h;
        vAlign  = 'bottom';
    end

    % White backing so the bar reads on dark imagery as well as on the white
    % background of the network panels.
    patch(ax, 'XData', [x0-0.06*barCols, x0+1.06*barCols, x0+1.06*barCols, x0-0.06*barCols], ...
              'YData', [yBackLo, yBackLo, yBackHi, yBackHi], ...
              'FaceColor','w', 'FaceAlpha',0.80, 'EdgeColor','none', ...
              'HandleVisibility','off');
    patch(ax, 'XData', [x0, x0+barCols, x0+barCols, x0], ...
              'YData', [y0, y0, y0+h, y0+h], ...
              'FaceColor','k', 'EdgeColor','k', 'LineWidth',0.4, ...
              'HandleVisibility','off');
    text(ax, x0 + barCols/2, yTxt, sprintf('%g km', barKm), ...
         'HorizontalAlignment','center', 'VerticalAlignment', vAlign, ...
         'FontSize', fontSize, 'FontWeight','normal', 'Color','k');

    if ~wasHeld; hold(ax, 'off'); end
end

function drawNorthArrow(ax, fontSize)
% North arrow for the upper-right corner of a map axes. It assumes the axes
% has YDir set to normal, which is how the rest of the pipeline draws its
% maps, so that increasing row index runs north.

    xl = xlim(ax);  yl = ylim(ax);
    xr = xl(2) - xl(1);  yr = yl(2) - yl(1);

    x  = xl(2) - 0.06*xr;
    yb = yl(2) - 0.34*yr;
    yt = yl(2) - 0.18*yr;
    hd = 0.25*(yt - yb);
    w  = 0.016*xr;

    wasHeld = ishold(ax);  hold(ax, 'on');

    patch(ax, 'XData', [x-2.6*w, x+2.6*w, x+2.6*w, x-2.6*w], ...
              'YData', [yb-0.12*(yt-yb), yb-0.12*(yt-yb), ...
                        yt+hd+0.85*(yt-yb), yt+hd+0.85*(yt-yb)], ...
              'FaceColor','w', 'FaceAlpha',0.80, 'EdgeColor','none', ...
              'HandleVisibility','off');
    plot(ax, [x x], [yb yt], 'k-', 'LineWidth', 0.9, 'HandleVisibility','off');
    patch(ax, 'XData', [x-w, x+w, x], 'YData', [yt, yt, yt+hd], ...
              'FaceColor','k', 'EdgeColor','k', 'LineWidth',0.4, ...
              'HandleVisibility','off');
    text(ax, x, yt+hd+0.08*(yt-yb), 'N', 'HorizontalAlignment','center', ...
         'VerticalAlignment','bottom', 'FontSize', fontSize, ...
         'FontWeight','bold', 'Color','k');

    if ~wasHeld; hold(ax, 'off'); end
end

function R = runDownstream(reducedMaps, HP, FIXED, tolerance, beta, CTX)
% Stages 2b, 3 and 4 of Lineaments_Auto7.m, transcribed without alteration so
% that every arm of the comparison is treated identically.

    % ---------- Stage 2b: mask and adjust dynamic range -------------------
    reducedMaps(reducedMaps == 0) = 1e-12;
    masked = bsxfun(@times, reducedMaps, CTX.inMask);
    masked(masked == 0) = NaN;

    Features = zeros(size(masked));
    for k = 1:size(masked,3)
        Features(:,:,k) = nDstrb2D(masked(:,:,k));
    end
    clear masked;

    % ---------- Stage 3: lineament extraction per feature -----------------
    arr = cat(3, Features, CTX.AllData);
    clear Features;

    if ndims(arr) == 3
        nanPages = all(all(isnan(arr), 1), 2);
        arr(:,:,squeeze(nanPages)) = [];
    end
    if isempty(arr) || all(isnan(arr(:)))
        error('All feature maps are NaN or empty after masking.');
    end
    if ismatrix(arr)
        tmp = arr; clear arr; arr(:,:,1) = tmp;
    end
    nF = size(arr, 3);

    resize_factor = FIXED.LINE_RES;
    if resize_factor <= 0; resize_factor = 1; end

    XI_line = imresize(CTX.XI, resize_factor);
    YI_line = imresize(CTX.YI, resize_factor);

    % Inverse-variance z-scores that drive the adaptive step filter width
    vari1 = zeros(nF, 1);
    for t = 1:nF
        G = FilterB(arr(:,:,t), FIXED.SIGMA2);
        G(isnan(G)) = 0;
        v = var(double(G(:)));
        if v == 0
            vari1(t) = 1;
        else
            vari1(t) = 1 / v;
        end
    end
    if numel(vari1) > 1
        vari1_std = zscore(vari1);
    else
        vari1_std = zeros(size(vari1));
    end

    plotH0 = zeros(size(XI_line,1), size(XI_line,2), nF);

    % Diagnostics for the stacking behaviour. The pipeline stores each feature
    % map complemented and then ORs the complements, so a pixel survives only
    % if it is detected in EVERY feature map. unionMap is recorded purely to
    % quantify that effect and takes no part in the GRM.
    perFeaturePixels = zeros(nF, 1);
    unionMap = false(size(XI_line,1), size(XI_line,2));

    for t = 1:nF
        G = FilterB(arr(:,:,t), FIXED.SIGMA2);
        G(isnan(G)) = 0;

        grm2 = round(HP.w + (HP.VSFW * HP.w) * vari1_std(t));
        if grm2 <= 1; grm2 = 1; end

        data1 = im2double(imresize(G, resize_factor));

        if HP.NSFA > 0
            stepAng = pi / HP.NSFA;
            DTheta  = 0 : stepAng : pi - stepAng;
        else
            DTheta = 0;
        end
        Dbw = [2 4 6];

        Y_filtered = step_Filtering(data1, grm2, DTheta, Dbw, 2);
        [BW_detected, ~] = getFaultDetection(Y_filtered, data1, HP.SLC);

        CC = bwconncomp(BW_detected);
        keep_indices = [];
        if CC.NumObjects > 0
            st        = regionprops(CC, Y_filtered, 'PixelValues');
            strengths = cellfun(@(x) sum(x(:)), {st.PixelValues});
            pct_cutoff = 100 - HP.SLC;
            if isempty(strengths)
                th = 0;
            else
                th = prctile(strengths, pct_cutoff);
            end
            keep_indices = find(strengths >= th);
            BW_strength  = ismember(labelmatrix(CC), keep_indices);
        else
            BW_strength = false(size(BW_detected));
        end

        if CC.NumObjects > 0 && ~isempty(keep_indices)
            MapLbl = bwlabel(BW_strength, 8);
            Labels = unique(MapLbl(MapLbl > 0))';
            if isempty(Labels)
                plotH_colored = zeros(size(data1,1), size(data1,2), 3);
            else
                plotH_colored = plotNewColorMap0_(Y_filtered, zeros(size(data1)), ...
                    MapLbl, Labels, 'Detected Lineaments', YI_line(:), XI_line(:));
            end
        else
            plotH_colored = zeros(size(data1,1), size(data1,2), 3);
        end

        gray_img = (plotH_colored(:,:,1) + plotH_colored(:,:,2) + plotH_colored(:,:,3)) / 3;
        bin_img  = imbinarize(gray_img);

        CCf = bwconncomp(bin_img);
        if CCf.NumObjects > 0
            stf   = regionprops(CCf, 'Area');
            valid = find([stf.Area] >= 50);
            final = ismember(labelmatrix(CCf), valid);
        else
            final = false(size(bin_img));
        end

        perFeaturePixels(t) = nnz(final);
        unionMap = unionMap | final;

        plotH0(:,:,t) = imcomplement(final);
    end

    % ---------- Stack ------------------------------------------------------
    % The codebase contains two stacking conventions, and both are evaluated
    % here because they answer different questions.
    %
    %   INTERSECTION : Lineaments_Auto7.m ORs the complemented maps, so a pixel
    %                  is kept only if every feature detects it. This is the map
    %                  the GRM objective and the reported metrics are built on.
    %
    %   UNION        : useBHO_BestOutputs.m ANDs the complemented maps, so a
    %                  pixel is kept if any feature detects it. This is the map
    %                  the published lineament figures are drawn from.
    %
    % Both use the convention lineaments = 0, background = 1.
    interStack = false(size(plotH0,1), size(plotH0,2));
    unionStack = true(size(plotH0,1), size(plotH0,2));
    for n = 1:nF
        interStack = interStack | plotH0(:,:,n);
        unionStack = unionStack & plotH0(:,:,n);
    end

    linInter = blankBorder(im2double(interStack), CTX.YI_Real_Ratio);
    linUnion = blankBorder(im2double(unionStack), CTX.YI_Real_Ratio);

    % ---------- Score both maps -------------------------------------------
    sInter = scoreMap(linInter, CTX, XI_line, YI_line, tolerance, beta);
    sUnion = scoreMap(linUnion, CTX, XI_line, YI_line, tolerance, beta);

    % ---------- Pack ------------------------------------------------------
    % Unprefixed fields keep the intersection values, so they remain directly
    % comparable with what Lineaments_Auto7 returns.
    R.nFeatures   = nF;
    R.nSegments   = sInter.nSegments;
    R.totalLength = sInter.totalLength;
    R.GRM         = sInter.GRM;
    R.fbeta       = sInter.fbeta;
    R.P21         = sInter.P21;
    R.BC          = sInter.BC;
    R.JSD         = sInter.JSD;
    R.lineaments  = linInter;

    R.u_nSegments   = sUnion.nSegments;
    R.u_totalLength = sUnion.totalLength;
    R.u_GRM         = sUnion.GRM;
    R.u_fbeta       = sUnion.fbeta;
    R.u_P21         = sUnion.P21;
    R.u_BC          = sUnion.BC;
    R.u_JSD         = sUnion.JSD;
    R.u_lineaments  = linUnion;

    % Stacking diagnostics
    R.meanPixelsPerFeature = mean(perFeaturePixels);
    R.minPixelsPerFeature  = min(perFeaturePixels);
    R.unionPixels          = nnz(unionMap);
    R.intersectionPixels   = nnz(imcomplement(imbinarize(linInter)));
end


function img = blankBorder(img, ratio)
% Border blanking applied identically in Lineaments_Auto7.m and
% useBHO_BestOutputs.m: a 2.5 % strip is set to background.
    c1 = round(0.025 * ratio * size(img,1));
    c2 = round(0.025 * size(img,2));
    c1 = max(0, min(c1, floor(size(img,1)/2) - 1));
    c2 = max(0, min(c2, floor(size(img,2)/2) - 1));
    if c1 > 0
        img(1:c1, :)         = 1.0;
        img(end-c1+1:end, :) = 1.0;
    end
    if c2 > 0
        img(:, 1:c2)         = 1.0;
        img(:, end-c2+1:end) = 1.0;
    end
end


function S = scoreMap(lineaments, CTX, XI_line, YI_line, tolerance, beta)
% Stage 4 of Lineaments_Auto7.m plus the supervised validation, applied to a
% stacked map in the convention lineaments = 0, background = 1.

    lineamentBinary = imbinarize(lineaments);
    CCs = bwconncomp(imcomplement(lineamentBinary));

    Segments = struct('startCoord', {}, 'endCoord', {}, 'pixelList', {});
    for s = 1:numel(CCs.PixelIdxList)
        pixList = CCs.PixelIdxList{s};
        if numel(pixList) < 2; continue; end
        [rs, cs] = ind2sub(size(lineamentBinary), pixList);
        [~, iMin] = min(rs);
        [~, iMax] = max(rs);
        seg.startCoord = [rs(iMin(1)), cs(iMin(1))];
        seg.endCoord   = [rs(iMax(1)), cs(iMax(1))];
        seg.pixelList  = pixList;
        Segments = [Segments; seg]; %#ok<AGROW>
    end

    N  = numel(Segments);
    ME = 0;
    totalLength = 0;

    if N > 0
        W    = zeros(N,1);
        cent = zeros(N,2);
        for i = 1:N
            W(i) = numel(Segments(i).pixelList);
            totalLength = totalLength + W(i);
            [ri, ci] = ind2sub(size(lineamentBinary), Segments(i).pixelList);
            cent(i,:) = [mean(ri), mean(ci)];
        end

        simMatrix = zeros(N, N);
        for i = 1:N
            for j = i+1:N
                sv = 1 / (1 + norm(cent(i,:) - cent(j,:)));
                simMatrix(i,j) = sv;
                simMatrix(j,i) = sv;
            end
        end

        for i = 1:N
            if N == 1
                hatS = 0;
            else
                row = simMatrix(i,:);
                row(i) = Inf;
                hatS = min(row);
                if isinf(hatS); hatS = 0; end
            end
            ME = ME + W(i) * (1 - hatS);
        end
    end

    detected = imbinarize(imcomplement(lineaments));
    gt = CTX.Truth;
    if ~isequal(size(gt), size(detected))
        gt = imresize(gt, size(detected));
    end
    gt = imbinarize(gt);

    [fbeta, ~, ~, ~, ~, ~] = calculateFbetaScore( ...
        gt, detected, XI_line, YI_line, beta, tolerance, true, false, false);

    sm = calculateStructuralMetrics(gt, detected, XI_line, YI_line, false);

    S.nSegments   = N;
    S.totalLength = totalLength;
    S.GRM         = round(ME);
    S.fbeta       = fbeta;
    S.P21         = getFieldOrNaN(sm, 'P21_ratio');
    S.BC          = getFieldOrNaN(sm, 'bhattacharyya_coeff');
    S.JSD         = getFieldOrNaN(sm, 'js_divergence');
end


function raster = rasterizeLineaments(shpPath, XI_, YI_, Xmin, Xmax, Ymin, Ymax)
% Equivalent of the rasterization performed by the Lineaments Shape File
% button: keep the lines that touch the study area, densify each one to about
% two samples per pixel, and burn the samples into a binary raster.

    LineamentData = shaperead(shpPath);
    if ~isfield(LineamentData, 'X') || ~isfield(LineamentData, 'Y')
        error('Shapefile must contain line geometry with X and Y coordinates.');
    end

    [rows, cols] = size(XI_);
    raster = false(rows, cols);

    dx = abs(XI_(1,2) - XI_(1,1));
    dy = abs(YI_(2,1) - YI_(1,1));
    x0 = XI_(1,1);
    y0 = YI_(1,1);

    kept = 0;
    for i = 1:numel(LineamentData)
        lx = LineamentData(i).X;
        ly = LineamentData(i).Y;

        ok = ~isnan(lx) & ~isnan(ly);
        lx = lx(ok);
        ly = ly(ok);
        if numel(lx) < 2; continue; end

        within = (lx >= Xmin) & (lx <= Xmax) & (ly >= Ymin) & (ly <= Ymax);
        if ~any(within); continue; end
        kept = kept + 1;

        dist_pix   = sum(sqrt(diff(lx/dx).^2 + diff(ly/dy).^2));
        num_points = max(2, ceil(dist_pix * 2));

        t_old = linspace(0, 1, numel(lx));
        t_new = linspace(0, 1, num_points);
        xd = interp1(t_old, lx, t_new);
        yd = interp1(t_old, ly, t_new);

        c_idx = round((xd - x0) / (XI_(1,2) - x0)) + 1;
        r_idx = round((yd - y0) / (YI_(2,1) - y0)) + 1;

        v = c_idx >= 1 & c_idx <= cols & r_idx >= 1 & r_idx <= rows;
        raster(sub2ind([rows, cols], r_idx(v), c_idx(v))) = true;
    end

    if kept == 0
        error('No lineaments fall within the study area bounds.');
    end
    fprintf('  vector features kept : %d of %d\n', kept, numel(LineamentData));

    raster = im2double(raster);
end


function v = getFieldOrNaN(s, name)
    if isstruct(s) && isfield(s, name)
        v = s.(name);
    else
        v = NaN;
    end
end


function edge_map = extractRudimentaryEdges(cwt_map, percentile_value)
% Identical to ExtractRudimentaryEdgesFixedInternal inside CWTFeatureSelection.m,
% reproduced here because that helper is local to its own file. Used only for
% the diagnostics; the selection itself still calls the original.

    [h, w] = size(cwt_map);
    edge_map = false(h, w);

    if sum(abs(cwt_map(:)), 'omitnan') < eps || all(isnan(cwt_map(:))); return; end

    positive_coeffs = cwt_map(cwt_map > 0 & ~isnan(cwt_map));
    if isempty(positive_coeffs); return; end

    threshold = prctile(positive_coeffs, percentile_value);

    if isempty(threshold) || ~isscalar(threshold) || isnan(threshold)
        threshold = median(positive_coeffs);
        if isempty(threshold) || threshold <= 0 || isnan(threshold); return; end
    end
    if threshold <= 1e-9 && any(positive_coeffs > 1e-9)
        mp = min(positive_coeffs(positive_coeffs > 1e-9));
        if ~isempty(mp); threshold = mp; else; return; end
    end

    edge_map = (cwt_map >= threshold) & (cwt_map > 0) & ~isnan(cwt_map);
end
