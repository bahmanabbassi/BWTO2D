function [Y] = step_Filtering(I, grammes, DTheta, DPaxos, typeOfFilter)
%
% =========================================================================
% FUNCTION: step_Filtering
% =========================================================================
%
% PURPOSE:
% Directional step filtering, Eqs. (13) and (15) of Section 1.3.
%
% The feature map is convolved with a zero-mean step filter G(w, phi) at every
% requested orientation and band width, and the largest response at each pixel
% is kept. Taking the maximum makes the result orientation independent, so a
% single output map carries structures running in any direction.
%
% The kernel is a positive central band flanked by negative bands, with the
% weights balanced so the filter sums to zero. It therefore responds to a
% locally linear contrast and ignores a uniform background, which is what makes
% it selective for elongated features rather than for amplitude alone.
%
% -------------------------------------------------------------------------
%
% AUTHOR:
% Bahman Abbassi, University of Quebec (UQAT)
% Email: bahman.abbassi@uqat.ca
%
% Step filter design follows:
% Panagiotakis, C., Kokinou, E., 2015. Linear pattern detection of geological
% faults via a topology and shape optimization method.
%
% -------------------------------------------------------------------------
%
% INPUTS:
%   I            (2D matrix): Feature map to filter, F_i(x,y).
%   grammes      (integer):   Kernel size in pixels, the locally adapted width
%                             w of Eq. (14).
%   DTheta       (vector):    Filter orientations phi in radians, spanning
%                             [0, pi). Its length is N_phi in Table 1.
%   DPaxos       (vector):    Band widths of the kernel. The pipeline passes
%                             [2 4 6], so each orientation is tried at three
%                             band widths and the best response is kept.
%   typeOfFilter (integer):   1 for the sharp step profile, any other value for
%                             the smooth parabolic profile. The pipeline uses
%                             the smooth profile.
%
% OUTPUTS:
%   Y (2D matrix): Maximum response over all orientations and band widths,
%                  the map D_i(x,y) of Eq. (15).
%
% =========================================================================


% --- Step 1: Initialization ---
gabors = length(DTheta);    % Number of orientations
gabors2 = length(DPaxos);   % Number of band widths

Y = zeros(size(I), 'like', I);

% --- Step 2: Sweep every band width and orientation, Eq. (13) ---
for j = 1:gabors2
    bw = DPaxos(j);
    
    for i = 1:gabors
        theta = DTheta(i);
        
        if typeOfFilter == 1
            gb = mask_fn(grammes, bw, theta, 0);          % Sharp profile
        else
            gb = mask_fn_smooth(grammes, bw, theta, 0);   % Smooth profile
        end
        
        % Unit energy, so that responses from kernels of different orientation
        % and band width can be compared on the same scale.
        gb = gb / sqrt(sum(sum(gb.^2)));
        
        G = conv2(I, gb, 'same');
        
        % Running maximum over orientations and widths, Eq. (15). This is what
        % makes the output orientation independent.
        Y = max(Y, G);
        
        clear gb G
    end
end

% --- Step 3: Suppress the convolution edge response ---
% A kernel overlapping the image border sees only part of its support, which
% produces a spurious rim. The outer 3 percent of each dimension is therefore
% zeroed before thresholding.
global YI_Real_Ratio
cropPixels1 = round(0.03 * YI_Real_Ratio * size(Y, 1), 0);
cropPixels2 = round(0.03 * size(Y, 2), 0);
Y(1:cropPixels1, :) = 0;                        % Top
Y(:, 1:cropPixels2) = 0;                        % Left
Y(size(I, 1)-[0:cropPixels1-1], :) = 0;         % Bottom
Y(:, size(I, 2)-[0:cropPixels2-1]) = 0;         % Right

% Clear remaining temporary variables.
clear gabors gabors2 cropPixels1 cropPixels2
end



function gb = mask_fn(grammes, bw, theta, toPlot)
% mask_fn - Step filter kernel with a sharp profile.
%
% A band of +1 runs through the centre along direction theta, flanked on both
% sides by bands of -1. The negative weights are then rescaled so the kernel
% sums to zero, which is the zero-mean condition required by Eq. (13).
%
% INPUTS:
%   grammes (integer): Kernel size in pixels.
%   bw      (double):  Half-width of the central positive band.
%   theta   (double):  Orientation in radians.
%   toPlot  (integer): Debug flag, unused in normal operation.
%
% OUTPUTS:
%   gb (2D matrix): The kernel, normalized to unit energy.

% --- Step 1: Rotated coordinate grid ---
sz = grammes;
if mod(sz, 2) == 0
    sz = sz + 1; % An odd size gives the kernel a well-defined centre pixel
end

[x, y] = meshgrid(-fix(sz/2):1:fix(sz/2), fix(sz/2):-1:fix(-sz/2));
x_theta = x * cos(theta) + y * sin(theta);
y_theta = -x * sin(theta) + y * cos(theta);

% --- Step 2: Profile across the band ---
% Only the distance perpendicular to the band matters, so the profile depends
% on the rotated x coordinate alone and the kernel is invariant along theta.
gb = zeros(size(x));
for i = 1:length(x)
    for j = 1:length(y)
        d = abs(x_theta(i, j));
        if d < bw
            gb(i, j) = 1;  % Central positive band
        elseif d <= 3 * bw
            gb(i, j) = -1; % Flanking negative bands
        end
    end
end

% --- Step 3: Balance so the weights sum to zero ---
% The flanks generally cover more pixels than the centre, so they are scaled
% down by the ratio of the two counts rather than left at -1.
[n1, n2] = find(gb == -1);
[p1, p2] = find(gb == 1);
nv_n1 = -length(p1) / length(n1);
for i = 1:length(n1)
    gb(n1(i), n2(i)) = nv_n1;
end

% --- Step 4: Unit energy ---
gb = gb / sqrt(sum(sum(gb.^2)));

if toPlot == 1
    mean(mean(gb));
end

clear x y x_theta y_theta n1 n2 p1 p2
end



function gb = mask_fn_smooth(grammes, bw, theta, toPlot)
% mask_fn_smooth - Step filter kernel with a smooth profile.
%
% Same geometry as mask_fn, but the abrupt +1 and -1 bands are replaced by
% parabolic arcs. The gradual transition avoids the ringing that a sharp
% kernel produces on continuous potential-field data, and it is the profile
% the pipeline uses.
%
% INPUTS:
%   grammes (integer): Kernel size in pixels.
%   bw      (double):  Half-width of the central positive region.
%   theta   (double):  Orientation in radians.
%   toPlot  (integer): Debug flag, unused in normal operation.
%
% OUTPUTS:
%   gb (2D matrix): The kernel, normalized to unit energy.

% --- Step 1: Rotated coordinate grid ---
sz = grammes;
if mod(sz, 2) == 0
    sz = sz + 1; % Odd size gives a well-defined centre pixel
end

[x, y] = meshgrid(-fix(sz/2):1:fix(sz/2), fix(sz/2):-1:fix(-sz/2));
x_theta = x * cos(theta) + y * sin(theta);
y_theta = -x * sin(theta) + y * cos(theta);

% --- Step 2: Parabolic profile across the band ---
gb = zeros(size(x));
for i = 1:length(x)
    for j = 1:length(y)
        d = abs(x_theta(i, j));
        if d < bw
            % Peaks at 1 on the centre line and falls to 0 at d = bw.
            gb(i, j) = 1 - ((d / bw)^2);
        elseif d <= 3 * bw
            % Dips to -0.5 at d = 2*bw and returns to 0 at the outer edge.
            gb(i, j) = 0.5 * (-1 + (((d / bw) - 2)^2));
        end
    end
end

% --- Step 3: Balance so the weights sum to zero ---
% With a graded profile the counts alone are not enough, so the negative side
% is scaled by the ratio of the two total weights.
[u1, v1] = find(gb > 0);
[u2, v2] = find(gb < 0);

m1 = 0; N1 = length(u1);
for i = 1:length(u1)
    m1 = m1 + gb(u1(i), v1(i));
end
m1 = m1 / N1;

m2 = 0; N2 = length(u2);
for i = 1:length(u2)
    m2 = m2 + gb(u2(i), v2(i));
end
m2 = m2 / N2;

c = -m1 * N1 / (m2 * N2);
for i = 1:length(u2)
    gb(u2(i), v2(i)) = c * gb(u2(i), v2(i));
end

% --- Step 4: Unit energy ---
gb = gb / sqrt(sum(sum(gb.^2)));

if toPlot == 1
    mean(mean(gb));
end

clear x y x_theta y_theta u1 v1 u2 v2 m1 m2 N1 N2
end